// src/GradoCerrado.Domain/Models/NivelDificultad.cs
namespace GradoCerrado.Domain.Models;

public enum NivelDificultad
{
    basico,
    intermedio,
    avanzado
}