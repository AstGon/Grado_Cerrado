// src/GradoCerrado.Domain/Models/PrioridadNotificacion.cs
namespace GradoCerrado.Domain.Models;

public enum PrioridadNotificacion
{
    baja,
    media,
    alta,
    urgente
}