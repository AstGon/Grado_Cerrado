﻿// 📁 Modelo para resultado de clasificación
namespace GradoCerrado.Domain.Entities
{
    public class ContentClassification
    {
        public int TemaId { get; set; }
        public string TemaNombre { get; set; } = string.Empty;
        public int? SubtemaId { get; set; }
        public string? SubtemaNombre { get; set; }
        public double Confidence { get; set; } // 0-1
        public List<string> MatchedKeywords { get; set; } = new();
    }
}