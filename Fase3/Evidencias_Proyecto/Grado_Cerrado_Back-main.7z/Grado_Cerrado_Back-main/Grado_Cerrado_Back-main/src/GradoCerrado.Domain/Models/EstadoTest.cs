// src/GradoCerrado.Domain/Models/EstadoTest.cs
namespace GradoCerrado.Domain.Models;

public enum EstadoTest
{
    pendiente,
    en_proceso,
    dominado,
    archivado
}