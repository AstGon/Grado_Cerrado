﻿// 📁 src/GradoCerrado.Domain/Entities/LegalDocument.cs
namespace GradoCerrado.Domain.Entities;

public class LegalDocument
{
    public Guid Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string OriginalFileName { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public LegalDocumentType DocumentType { get; set; }

    // ✅ JERARQUÍA COMPLETA
    public int? AreaId { get; set; }                      // ID del área (asignada manualmente)
    public string? AreaNombre { get; set; }               // Nombre del área
    public List<int> TemaIds { get; set; } = new();       // IDs de temas (clasificados por AI)
    public List<string> TemaNombres { get; set; } = new(); // Nombres de temas
    public List<int> SubtemaIds { get; set; } = new();    // IDs de subtemas (clasificados por AI)
    public List<string> SubtemaNombres { get; set; } = new(); // Nombres de subtemas

    public DifficultyLevel Difficulty { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public string Source { get; set; } = string.Empty;
    public bool IsProcessed { get; set; }
    public long FileSize { get; set; }
    public string MimeType { get; set; } = string.Empty;
    public List<DocumentChunk> Chunks { get; set; } = new();

    // Propiedades calculadas
    public bool HasBeenVectorized => Chunks.Any();
    public int ChunkCount => Chunks.Count;
    public DateTime? LastVectorizedAt => Chunks.Any() ? Chunks.Max(c => c.CreatedAt) : null;

    // Relación con preguntas generadas
    public List<StudyQuestion> GeneratedQuestions { get; set; } = new();
}