using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GradoCerrado.Domain.Models;
using GradoCerrado.Application.Interfaces;
using System.Security.Cryptography;
using System.Text;
using GradoCerrado.Application.DTOs;

namespace GradoCerrado.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly GradocerradoContext _context;
    private readonly ILogger<AuthController> _logger;
    private readonly IEmailService _emailService;

    public AuthController(GradocerradoContext context, ILogger<AuthController> logger, IEmailService emailService)
    {
        _context = context;
        _logger = logger;
        _emailService = emailService;
    }

    [HttpGet("test-connection")]
    public async Task<ActionResult> TestConnection()
    {
        try
        {
            var count = await _context.Estudiantes.CountAsync();
            var dbName = _context.Database.GetDbConnection().Database;

            return Ok(new
            {
                success = true,
                database = dbName,
                estudiantesCount = count,
                message = "ConexiÃ³n exitosa"
            });
        }
        catch (Exception ex)
        {
            return Ok(new
            {
                success = false,
                error = ex.Message
            });
        }
    }

    [HttpGet("connection-info")]
    public async Task<ActionResult> GetConnectionInfo()
    {
        try
        {
            var connection = _context.Database.GetDbConnection();
            var connectionString = connection.ConnectionString;

            // Parsear la cadena para extraer los componentes
            var parts = connectionString.Split(';')
                .Where(part => !string.IsNullOrEmpty(part))
                .Select(part => part.Split('='))
                .Where(split => split.Length == 2)
                .ToDictionary(split => split[0], split => split[1]);

            return Ok(new
            {
                host = parts.GetValueOrDefault("Host", "N/A"),
                port = parts.GetValueOrDefault("Port", "N/A"),
                database = parts.GetValueOrDefault("Database", "N/A"),
                username = parts.GetValueOrDefault("Username", "N/A"),
                // NO mostrar password por seguridad
                hasPassword = parts.ContainsKey("Password")
            });
        }
        catch (Exception ex)
        {
            return Ok(new { error = ex.Message });
        }
    }


    // Agregar al final de AuthController.cs, antes de los DTOs

    // DELETE: api/auth/delete-account/{estudianteId}
    [HttpDelete("delete-account/{estudianteId}")]
    public async Task<ActionResult> DeleteAccount(int estudianteId, [FromBody] DeleteAccountRequest request)
    {
        try
        {
            // Validar que se proporcionó la contraseña
            if (string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest(new
                {
                    success = false,
                    message = "La contraseña es obligatoria para eliminar la cuenta"
                });
            }

            // Buscar el estudiante (sin filtro de activo para poder eliminar cuentas desactivadas también)
            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Id == estudianteId);

            if (estudiante == null)
            {
                return NotFound(new
                {
                    success = false,
                    message = "Estudiante no encontrado"
                });
            }

            // Verificar que la contraseña es correcta
            if (!VerifyPassword(request.Password, estudiante.PasswordHash))
            {
                _logger.LogWarning("Intento de eliminación con contraseña incorrecta: {EstudianteId}", estudianteId);
                return BadRequest(new
                {
                    success = false,
                    message = "Contraseña incorrecta"
                });
            }

            var emailEliminado = estudiante.Email;

            // ELIMINACIÓN FÍSICA (HARD DELETE)
            // Las relaciones con DeleteBehavior.Cascade se eliminarán automáticamente:
            // - EstudianteNotificacionConfig
            // - Notificaciones
            // - Tests (y sus TestPreguntas en cascada)

            _context.Estudiantes.Remove(estudiante);
            await _context.SaveChangesAsync();

            _logger.LogInformation(
                "🗑️ Cuenta ELIMINADA PERMANENTEMENTE: {EstudianteId} - {Email}",
                estudianteId, emailEliminado);

            return Ok(new
            {
                success = true,
                message = "Cuenta eliminada permanentemente"
            });
        }
        catch (DbUpdateException dbEx)
        {
            _logger.LogError(dbEx, "❌ Error de base de datos eliminando cuenta: {EstudianteId}", estudianteId);

            return StatusCode(500, new
            {
                success = false,
                message = "Error al eliminar la cuenta. Es posible que tenga datos relacionados."
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error eliminando cuenta: {EstudianteId}", estudianteId);

            return StatusCode(500, new
            {
                success = false,
                message = "Error interno del servidor"
            });
        }
    }


    [HttpPost("register")]
    public async Task<ActionResult> Register([FromBody] AuthRegisterRequest request)
    {
        try
        {
            // Validar datos bÃ¡sicos
            if (string.IsNullOrWhiteSpace(request.Name) || string.IsNullOrWhiteSpace(request.Email))
            {
                return BadRequest(new { success = false, message = "Nombre y email son obligatorios" });
            }
            if (string.IsNullOrWhiteSpace(request.Password) || request.Password.Length < 6)
            {
                return BadRequest(new { success = false, message = "La contraseÃ±a debe tener al menos 6 caracteres" });
            }

            // Verificar si el email ya existe
            var emailExists = await _context.Estudiantes
                .AnyAsync(e => e.Email.ToLower() == request.Email.ToLower());

            if (emailExists)
            {
                return BadRequest(new { success = false, message = "El email ya estÃ¡ registrado" });
            }

            var currentTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);

            // Crear nuevo estudiante
            var estudiante = new Estudiante
            {
                Nombre = request.Name.Trim(),
                SegundoNombre = request.SegundoNombre?.Trim(),
                ApellidoPaterno = request.ApellidoPaterno?.Trim(),
                ApellidoMaterno = request.ApellidoMaterno?.Trim(),
                Email = request.Email.ToLower().Trim(),
                PasswordHash = HashPassword(request.Password),
                FechaRegistro = currentTime,
                UltimoAcceso = currentTime,
                Activo = true,
                Verificado = false
            };

            // Guardar en base de datos
            _context.Estudiantes.Add(estudiante);
            await _context.SaveChangesAsync();

            _logger.LogInformation("âœ… Usuario registrado exitosamente: {Email}", request.Email);

            // ðŸŽ‰ NUEVO: Crear configuraciÃ³n inicial de notificaciones
            var notifConfig = new EstudianteNotificacionConfig
            {
                EstudianteId = estudiante.Id,
                NotificacionesHabilitadas = true,
                TokenDispositivo = null!,
                FechaInicio = currentTime,
                FechaActualizacion = currentTime,
                FechaFin = null
            };

            _context.EstudianteNotificacionConfigs.Add(notifConfig);
            await _context.SaveChangesAsync();

            _logger.LogInformation("âœ… ConfiguraciÃ³n de notificaciones creada para estudiante {Id}", estudiante.Id);

            return Ok(new
            {
                success = true,
                message = "Usuario registrado exitosamente",
                user = new
                {
                    id = estudiante.Id,
                    name = estudiante.Nombre,
                    email = estudiante.Email,
                    fechaRegistro = estudiante.FechaRegistro
                }
            });
        }
        catch (DbUpdateException dbEx)
        {
            _logger.LogError(dbEx, "âŒ Error de base de datos al registrar usuario: {Email}", request.Email);
            return StatusCode(500, new { success = false, message = "Error en la base de datos" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "âŒ Error registrando usuario: {Email}", request.Email);
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    // POST: api/auth/login
    [HttpPost("login")]
    public async Task<ActionResult> Login([FromBody] AuthLoginRequest request)
    {
        try
        {
            // Validar datos
            if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Password))
            {
                return BadRequest(new { success = false, message = "Email y contraseÃ±a son obligatorios" });
            }

            // Buscar usuario - CORREGIDO para manejar bool?
            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Email.ToLower() == request.Email.ToLower() && e.Activo == true);

            if (estudiante == null)
            {
                return BadRequest(new { success = false, message = "Credenciales incorrectas" });
            }

            // Verificar contraseÃ±a
            if (!VerifyPassword(request.Password, estudiante.PasswordHash))
            {
                return BadRequest(new { success = false, message = "Credenciales incorrectas" });
            }

            // ACTUALIZAR ÃšLTIMO ACCESO SIN UTC
            estudiante.UltimoAcceso = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
            await _context.SaveChangesAsync();

            _logger.LogInformation("Login exitoso: {Email}", request.Email);

            return Ok(new
            {
                success = true,
                message = "Login exitoso",
                user = new
                {
                    id = estudiante.Id,
                    name = estudiante.Nombre,
                    email = estudiante.Email,
                    fechaRegistro = estudiante.FechaRegistro
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error en login: {Email}", request.Email);
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    // POST: api/auth/complete-diagnostic
    [HttpPost("complete-diagnostic")]
    public async Task<ActionResult> CompleteDiagnosticTest([FromBody] CompleteDiagnosticRequest request)
    {
        try
        {
            // Buscar el estudiante
            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Id == request.EstudianteId && e.Activo == true);

            if (estudiante == null)
            {
                return NotFound(new { success = false, message = "Estudiante no encontrado" });
            }

            // Verificar que no haya completado ya el test
            if (estudiante.TestDiagnosticoCompletado == true)
            {
                return BadRequest(new { success = false, message = "Test diagnÃ³stico ya completado" });
            }

            // Actualizar los campos del test diagnÃ³stico
            var currentTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);

            estudiante.TestDiagnosticoCompletado = true;
            estudiante.FechaTestDiagnostico = currentTime;
            estudiante.UltimoAcceso = currentTime;

            await _context.SaveChangesAsync();

            _logger.LogInformation("Test diagnÃ³stico completado para estudiante: {EstudianteId}", request.EstudianteId);

            return Ok(new
            {
                success = true,
                message = "Test diagnÃ³stico completado exitosamente",
                data = new
                {
                    estudianteId = estudiante.Id,
                    fechaCompletado = estudiante.FechaTestDiagnostico,
                    testCompletado = estudiante.TestDiagnosticoCompletado
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error completando test diagnÃ³stico para estudiante: {EstudianteId}", request.EstudianteId);
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    // GET: api/auth/diagnostic-status/{estudianteId}
    [HttpGet("diagnostic-status/{estudianteId}")]
    public async Task<ActionResult> GetDiagnosticStatus(int estudianteId)
    {
        try
        {
            var estudiante = await _context.Estudiantes
                .Where(e => e.Id == estudianteId && e.Activo == true)
                .Select(e => new {
                    e.Id,
                    e.TestDiagnosticoCompletado,
                    e.FechaTestDiagnostico
                })
                .FirstOrDefaultAsync();

            if (estudiante == null)
            {
                return NotFound(new { success = false, message = "Estudiante no encontrado" });
            }

            return Ok(new
            {
                success = true,
                data = new
                {
                    estudianteId = estudiante.Id,
                    testCompletado = estudiante.TestDiagnosticoCompletado ?? false,
                    fechaCompletado = estudiante.FechaTestDiagnostico,
                    requiereTest = estudiante.TestDiagnosticoCompletado != true
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo estado diagnÃ³stico: {EstudianteId}", estudianteId);
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    // GET: api/auth/current-user/{estudianteId}
    [HttpGet("current-user/{estudianteId}")]
    public async Task<ActionResult> GetCurrentUserComplete(int estudianteId)
    {
        try
        {
            var estudiante = await _context.Estudiantes
                .Where(e => e.Id == estudianteId && e.Activo == true)
                .FirstOrDefaultAsync();

            if (estudiante == null)
            {
                return NotFound(new { success = false, message = "Estudiante no encontrado" });
            }

            return Ok(new
            {
                success = true,
                data = new
                {
                    id = estudiante.Id,
                    nombre = estudiante.Nombre,
                    segundoNombre = estudiante.SegundoNombre,
                    apellidoPaterno = estudiante.ApellidoPaterno,
                    apellidoMaterno = estudiante.ApellidoMaterno,
                    nombreCompleto = estudiante.NombreCompleto,
                    email = estudiante.Email,
                    fechaRegistro = estudiante.FechaRegistro,
                    fechaModificacion = estudiante.FechaModificacion
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo usuario completo: {EstudianteId}", estudianteId);
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    // PUT: api/auth/update-profile/{estudianteId}
    [HttpPut("update-profile/{estudianteId}")]
    public async Task<ActionResult> UpdateProfile(int estudianteId, [FromBody] UpdateProfileRequest request)
    {
        try
        {
            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Id == estudianteId && e.Activo == true);

            if (estudiante == null)
            {
                return NotFound(new { success = false, message = "Estudiante no encontrado" });
            }

            // Si se estÃ¡ actualizando el email, validar formato y unicidad
            if (!string.IsNullOrWhiteSpace(request.Email))
            {
                var emailTrimmed = request.Email.Trim().ToLower();

                // Validar formato bÃ¡sico de email
                if (!emailTrimmed.Contains("@") || !emailTrimmed.Contains("."))
                {
                    return BadRequest(new { success = false, message = "Formato de email invÃ¡lido" });
                }

                // Verificar que el email no estÃ© siendo usado por otro usuario
                var emailExists = await _context.Estudiantes
                    .AnyAsync(e => e.Email.ToLower() == emailTrimmed && e.Id != estudianteId);

                if (emailExists)
                {
                    return BadRequest(new { success = false, message = "El email ya estÃ¡ registrado por otro usuario" });
                }

                // Actualizar email
                estudiante.Email = emailTrimmed;
            }

            // Validar campos obligatorios solo si se estÃ¡n enviando
            if (request.Nombre != null)
            {
                if (string.IsNullOrWhiteSpace(request.Nombre))
                {
                    return BadRequest(new { success = false, message = "El nombre no puede estar vacÃ­o" });
                }
                estudiante.Nombre = request.Nombre.Trim();
            }

            if (request.ApellidoPaterno != null)
            {
                if (string.IsNullOrWhiteSpace(request.ApellidoPaterno))
                {
                    return BadRequest(new { success = false, message = "El apellido paterno no puede estar vacÃ­o" });
                }
                estudiante.ApellidoPaterno = request.ApellidoPaterno.Trim();
            }

            // Actualizar campos opcionales
            if (request.SegundoNombre != null)
            {
                estudiante.SegundoNombre = string.IsNullOrWhiteSpace(request.SegundoNombre) ? null : request.SegundoNombre.Trim();
            }

            if (request.ApellidoMaterno != null)
            {
                estudiante.ApellidoMaterno = string.IsNullOrWhiteSpace(request.ApellidoMaterno) ? null : request.ApellidoMaterno.Trim();
            }

            // Reconstruir nombre completo
            var nombrePartes = new List<string>();
            if (!string.IsNullOrWhiteSpace(estudiante.Nombre))
                nombrePartes.Add(estudiante.Nombre);
            if (!string.IsNullOrWhiteSpace(estudiante.SegundoNombre))
                nombrePartes.Add(estudiante.SegundoNombre);
            if (!string.IsNullOrWhiteSpace(estudiante.ApellidoPaterno))
                nombrePartes.Add(estudiante.ApellidoPaterno);
            if (!string.IsNullOrWhiteSpace(estudiante.ApellidoMaterno))
                nombrePartes.Add(estudiante.ApellidoMaterno);

            estudiante.NombreCompleto = string.Join(" ", nombrePartes);
            estudiante.FechaModificacion = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);

            await _context.SaveChangesAsync();

            _logger.LogInformation("Perfil actualizado para estudiante: {EstudianteId}", estudianteId);

            return Ok(new
            {
                success = true,
                message = "Perfil actualizado exitosamente",
                data = new
                {
                    id = estudiante.Id,
                    nombre = estudiante.Nombre,
                    segundoNombre = estudiante.SegundoNombre,
                    apellidoPaterno = estudiante.ApellidoPaterno,
                    apellidoMaterno = estudiante.ApellidoMaterno,
                    nombreCompleto = estudiante.NombreCompleto,
                    email = estudiante.Email,
                    fechaModificacion = estudiante.FechaModificacion
                }
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error actualizando perfil: {EstudianteId}", estudianteId);
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    // POST: api/auth/request-password-reset
    [HttpPost("request-password-reset")]
    public async Task<ActionResult> RequestPasswordReset([FromBody] PasswordResetRequest request)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.Email))
            {
                return BadRequest(new { success = false, message = "El email es obligatorio" });
            }

            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Email.ToLower() == request.Email.ToLower() && e.Activo == true);

            // Por seguridad, siempre devolver success aunque el email no exista
            if (estudiante == null)
            {
                return Ok(new { success = true, message = "Si el email existe, recibirÃ¡s instrucciones para recuperar tu contraseÃ±a" });
            }

            // Invalidar tokens anteriores del usuario
            var oldTokens = await _context.PasswordResetTokens
                .Where(t => t.EstudianteId == estudiante.Id && !t.IsUsed)
                .ToListAsync();

            foreach (var token in oldTokens)
            {
                token.IsUsed = true;
            }

            // Generar token Ãºnico
            var resetToken = Guid.NewGuid().ToString() + Guid.NewGuid().ToString().Replace("-", "");
            var expirationDate = DateTime.UtcNow.AddHours(1); // Token vÃ¡lido por 1 hora

            var passwordResetToken = new PasswordResetToken
            {
                EstudianteId = estudiante.Id,
                Token = resetToken,
                ExpirationDate = expirationDate,
                IsUsed = false,
                CreatedAt = DateTime.UtcNow
            };

            _context.PasswordResetTokens.Add(passwordResetToken);
            await _context.SaveChangesAsync();

            // Enviar email con el código
            var emailSent = await _emailService.SendPasswordResetEmailAsync(estudiante.Email, resetToken);

            if (!emailSent)
            {
                _logger.LogWarning("No se pudo enviar el email de recuperación a: {Email}", request.Email);
            }

            _logger.LogInformation("Token de recuperación generado para: {Email}", request.Email);

            return Ok(new
            {
                success = true,
                message = "Si el email existe, recibirás un código de recuperación en tu correo"
            });
        }

        catch (Exception ex)
        {
            _logger.LogError(ex, "Error solicitando reset de contraseÃ±a");
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    // POST: api/auth/reset-password
    [HttpPost("reset-password")]
    public async Task<ActionResult> ResetPassword([FromBody] ResetPasswordRequest request)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.Token) || string.IsNullOrWhiteSpace(request.NewPassword))
            {
                return BadRequest(new { success = false, message = "Token y nueva contraseÃ±a son obligatorios" });
            }

            if (request.NewPassword.Length < 6)
            {
                return BadRequest(new { success = false, message = "La contraseÃ±a debe tener al menos 6 caracteres" });
            }

            var resetToken = await _context.PasswordResetTokens
                .Include(t => t.Estudiante)
                .FirstOrDefaultAsync(t => t.Token == request.Token);

            if (resetToken == null)
            {
                return BadRequest(new { success = false, message = "Token invÃ¡lido" });
            }

            if (resetToken.IsUsed)
            {
                return BadRequest(new { success = false, message = "Este token ya fue utilizado" });
            }

            if (resetToken.ExpirationDate < DateTime.UtcNow)
            {
                return BadRequest(new { success = false, message = "El token ha expirado" });
            }

            // Verificar que el estudiante existe
            if (resetToken.Estudiante == null)
            {
                return BadRequest(new { success = false, message = "Estudiante no encontrado" });
            }

            // Actualizar contraseÃ±a
            resetToken.Estudiante.PasswordHash = HashPassword(request.NewPassword);
            resetToken.Estudiante.FechaModificacion = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
            // Marcar token como usado
            resetToken.IsUsed = true;
            resetToken.UsedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("ContraseÃ±a reseteada exitosamente para estudiante: {EstudianteId}", resetToken.EstudianteId);

            return Ok(new
            {
                success = true,
                message = "ContraseÃ±a actualizada exitosamente"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error reseteando contraseÃ±a");
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    // MÃ©todos auxiliares para hash de contraseÃ±as
    private string HashPassword(string password)
    {
        using var sha256 = SHA256.Create();
        var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
        return Convert.ToBase64String(hashedBytes);
    }

    private bool VerifyPassword(string password, string hash)
    {
        var hashedPassword = HashPassword(password);
        return hashedPassword == hash;
    }

    // PUT: api/auth/change-password/{estudianteId}
    [HttpPut("change-password/{estudianteId}")]
    public async Task<ActionResult> ChangePassword(int estudianteId, [FromBody] ChangePasswordRequest request)
    {
        try
        {
            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Id == estudianteId && e.Activo == true);

            if (estudiante == null)
            {
                return NotFound(new { success = false, message = "Estudiante no encontrado" });
            }

            // Validar contraseÃ±a actual
            if (!VerifyPassword(request.CurrentPassword, estudiante.PasswordHash))
            {
                return BadRequest(new { success = false, message = "La contraseÃ±a actual es incorrecta" });
            }

            // Validar nueva contraseÃ±a
            if (string.IsNullOrWhiteSpace(request.NewPassword) || request.NewPassword.Length < 6)
            {
                return BadRequest(new { success = false, message = "La nueva contraseÃ±a debe tener al menos 6 caracteres" });
            }

            // Validar confirmaciÃ³n
            if (request.NewPassword != request.ConfirmPassword)
            {
                return BadRequest(new { success = false, message = "Las contraseÃ±as no coinciden" });
            }

            // Actualizar contraseÃ±a
            estudiante.PasswordHash = HashPassword(request.NewPassword);
            estudiante.FechaModificacion = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);

            await _context.SaveChangesAsync();

            _logger.LogInformation("ContraseÃ±a actualizada para estudiante: {EstudianteId}", estudianteId);

            return Ok(new
            {
                success = true,
                message = "ContraseÃ±a actualizada exitosamente"
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error cambiando contraseÃ±a: {EstudianteId}", estudianteId);
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    // DTOs para AuthController
    public class AuthRegisterRequest
    {
        public string Name { get; set; } = string.Empty;
        public string? SegundoNombre { get; set; }
        public string? ApellidoPaterno { get; set; }
        public string? ApellidoMaterno { get; set; }
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    public class AuthLoginRequest
    {
        public string Email { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }

    // DTO para completar test diagnÃ³stico
    public class CompleteDiagnosticRequest
    {
        public int EstudianteId { get; set; }
        // PodrÃ­as agregar mÃ¡s campos como resultados del test, nivel asignado, etc.
        public string? ResultadoNivel { get; set; }
        public int? PuntajeObtenido { get; set; }
    }

    // DTO para actualizar perfil
    public class UpdateProfileRequest
    {
        public string? Nombre { get; set; }
        public string? SegundoNombre { get; set; }
        public string? ApellidoPaterno { get; set; }
        public string? ApellidoMaterno { get; set; }
        public string? Email { get; set; }
    }

    // DTO para cambio de contraseÃ±a
    public class ChangePasswordRequest
    {
        public string CurrentPassword { get; set; } = string.Empty;
        public string NewPassword { get; set; } = string.Empty;
        public string ConfirmPassword { get; set; } = string.Empty;
    }

    // DTO para solicitar reset de contraseÃ±a
    public class PasswordResetRequest
    {
        public string Email { get; set; } = string.Empty;
    }

    // DTO para resetear contraseÃ±a
    public class ResetPasswordRequest
    {
        public string Token { get; set; } = string.Empty;
        public string NewPassword { get; set; } = string.Empty;
    }
}