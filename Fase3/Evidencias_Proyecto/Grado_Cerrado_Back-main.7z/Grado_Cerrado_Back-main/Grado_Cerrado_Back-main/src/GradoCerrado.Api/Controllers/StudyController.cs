using Microsoft.AspNetCore.Mvc;
using GradoCerrado.Application.Interfaces;
using GradoCerrado.Domain.Entities;
using GradoCerrado.Infrastructure.DTOs;
using GradoCerrado.Infrastructure.Services;
using GradoCerrado.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using Microsoft.Extensions.Logging;
using System.Linq;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace GradoCerrado.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class StudyController : ControllerBase
{
    private readonly ILogger<StudyController> _logger;
    private readonly IAIService _aiService;
    private readonly IVectorService _vectorService;
    private readonly IQuestionPersistenceService _questionPersistence;
    private readonly GradocerradoContext _context;
    private readonly IQuestionGenerationService _questionGeneration;

    public StudyController(
        ILogger<StudyController> logger,
        IAIService aiService,
        IVectorService vectorService,
        IQuestionPersistenceService questionPersistence,
        GradocerradoContext context,
        IQuestionGenerationService questionGeneration)
    {
        _logger = logger;
        _aiService = aiService;
        _vectorService = vectorService;
        _questionPersistence = questionPersistence;
        _context = context;
        _questionGeneration = questionGeneration;
    }

    [HttpGet("registered-users")]
    public ActionResult GetRegisteredUsers()
    {
        try
        {
            var users = new[]
            {
                new
                {
                    id = "2a5f109f-37da-41a6-91f1-d8df4b7ba02a",
                    name = "Coni",
                    email = "coni@gmail.com",
                    createdAt = "2025-09-25T03:00:10.427677Z"
                },
                new
                {
                    id = "9971d353-41e7-4a5c-a7c5-a6f620386ed5",
                    name = "alumno1",
                    email = "alumno1@gmail.com",
                    createdAt = "2025-09-24T23:26:28.101947Z"
                }
            };

            return Ok(new
            {
                success = true,
                totalUsers = users.Length,
                users
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo usuarios registrados");
            return StatusCode(500, new { success = false, message = "Error consultando usuarios" });
        }
    }

    [HttpPost("login")]
    public ActionResult Login([FromBody] LoginRequest request)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(request.Email))
                return BadRequest(new { success = false, message = "Email es obligatorio" });

            var user = new
            {
                id = Guid.NewGuid(),
                name = "Usuario de prueba",
                email = request.Email.Trim()
            };

            return Ok(new
            {
                success = true,
                message = "Login exitoso",
                user
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error en login: {Email}", request.Email);
            return StatusCode(500, new { success = false, message = "Error interno del servidor" });
        }
    }

    [HttpPost("start-session")]
    public async Task<ActionResult> StartSession([FromBody] StudySessionRequest request)
    {
        try
        {
            if (request.StudentId <= 0)
            {
                return BadRequest(new { success = false, message = "StudentId es obligatorio" });
            }

            _logger.LogInformation("📚 Iniciando sesión para estudiante ID: {StudentId}", request.StudentId);
            _logger.LogInformation("🎯 Modo adaptativo: {AdaptiveMode}", request.AdaptiveMode ?? false);

            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Id == request.StudentId && e.Activo == true);

            if (estudiante == null)
            {
                return BadRequest(new
                {
                    success = false,
                    message = $"Estudiante con ID {request.StudentId} no encontrado"
                });
            }

            _logger.LogInformation("✅ Estudiante encontrado: {Id} - {Nombre}", estudiante.Id, estudiante.Nombre);

            // 🆕 OBTENER AREA_ID desde LegalAreas
            int? areaId = null;
            if (request.LegalAreas != null && request.LegalAreas.Any())
            {
                var firstArea = request.LegalAreas.FirstOrDefault(a => !string.IsNullOrWhiteSpace(a));
                if (!string.IsNullOrWhiteSpace(firstArea))
                {
                    var normalized = firstArea.Trim();
                    var areaEntity = await _context.Areas
                        .FirstOrDefaultAsync(a => a.Nombre == normalized);

                    if (areaEntity != null)
                    {
                        areaId = areaEntity.Id;
                        _logger.LogInformation("🔍 Área identificada: {AreaId} - {AreaNombre}", areaId, areaEntity.Nombre);
                    }
                    else
                    {
                        _logger.LogWarning("⚠️ No se encontró el área: {AreaNombre}", normalized);
                    }
                }
            }

            var utcNow = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Unspecified);
            int testId;

            using (var testCommand = connection.CreateCommand())
            {
                try
                {
                    testCommand.CommandText = @"
                        INSERT INTO tests 
                        (estudiante_id, tipo_test_id, numero_preguntas_total, 
                         hora_inicio, completado, fecha_creacion, modo_adaptativo, area_id)
                        VALUES 
                        ($1, $2, $3, $4, $5, $6, $7, $8)
                        RETURNING id";

                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = estudiante.Id });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = 1 });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = request.QuestionCount ?? 5 });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = utcNow });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = false });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = utcNow });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = request.AdaptiveMode ?? false });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = (object?)areaId ?? DBNull.Value });

                    testId = Convert.ToInt32(await testCommand.ExecuteScalarAsync());
                }
                catch (Exception ex)
                {
                    _logger.LogWarning("⚠️ Columna modo_adaptativo no existe: {Message}", ex.Message);

                    testCommand.Parameters.Clear();
                    testCommand.CommandText = @"
                        INSERT INTO tests 
                        (estudiante_id, tipo_test_id, numero_preguntas_total, 
                         hora_inicio, completado, fecha_creacion, area_id)
                        VALUES 
                        ($1, $2, $3, $4, $5, $6, $7)
                        RETURNING id";

                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = estudiante.Id });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = 1 });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = request.QuestionCount ?? 5 });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = utcNow });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = false });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = utcNow });
                    testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = (object?)areaId ?? DBNull.Value });

                    testId = Convert.ToInt32(await testCommand.ExecuteScalarAsync());
                }
            }

            _logger.LogInformation("🆕 Test creado con ID: {TestId}, Area: {AreaId}", testId, areaId);

            var difficulty = string.IsNullOrWhiteSpace(request.Difficulty)
            ? "mixto"
            : request.Difficulty.ToLower();   // basico | intermedio | avanzado | mixto

            var legalAreas = request.LegalAreas ?? new List<string>();
            int count = (request.QuestionCount.HasValue && request.QuestionCount.Value > 0)
            ? request.QuestionCount.Value
            : 5;
            int? temaId = request.TemaId;
            int? subtemaId = request.SubtemaId;
            bool adaptive = request.AdaptiveMode ?? false;


            var questions = await GetQuestionsFromDatabase(
                legalAreas,
                difficulty,          // ← ahora sí existe
                count,
                temaId,
                subtemaId,
                connection,
                request.StudentId,
                adaptive
            );

            difficulty = string.IsNullOrWhiteSpace(difficulty) ? "mixto" : difficulty;

            bool autoGenerated = false;
            if (!questions.Any())
            {
                _logger.LogWarning("⚠️ No hay preguntas sin responder. Generando 20 nuevas desde Qdrant...");

                try
                {
                    var scopeContext = await BuildScopeContextAsync(request);

                    questions = await GenerateQuestionsFromVectorDatabase(
                        legalAreas: request.LegalAreas,
                        difficulty: request.Difficulty,
                        count: 20,
                        modalidadId: 1,
                        scopeContext: scopeContext
                    );

                    if (questions.Any())
                    {
                        autoGenerated = true;
                        _logger.LogInformation("✅ {Count} preguntas auto-generadas y guardadas en BD", questions.Count);
                        questions = questions.Take(request.QuestionCount ?? 5).ToList();
                    }
                    else
                    {
                        return BadRequest(new
                        {
                            success = false,
                            message = "No hay preguntas disponibles y no se pudieron generar nuevas. " +
                                      "Asegúrate de haber subido documentos para el área seleccionada.",
                            needsDocuments = true
                        });
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "❌ Error generando preguntas automáticamente");
                    return StatusCode(500, new
                    {
                        success = false,
                        message = "Error al generar preguntas automáticamente",
                        error = ex.Message
                    });
                }
            }

            _logger.LogInformation("✅ {Count} preguntas recuperadas {Source}",
                questions.Count,
                autoGenerated ? "(auto-generadas)" : "(de BD)");

            return Ok(new
            {
                success = true,
                testId = testId,
                session = new
                {
                    sessionId = Guid.NewGuid(),
                    studentId = request.StudentId,
                    realStudentId = estudiante.Id,
                    startTime = DateTime.UtcNow,
                    difficulty = request.Difficulty,
                    legalAreas = request.LegalAreas,
                    adaptiveMode = request.AdaptiveMode ?? false,
                    status = "Active"
                },
                questions = questions,
                totalQuestions = questions.Count,
                generatedWithAI = autoGenerated,
                source = autoGenerated ? "auto-generated" : "database",
                adaptiveEnabled = request.AdaptiveMode ?? false,
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error iniciando sesión");
            return StatusCode(500, new
            {
                success = false,
                message = "Error interno del servidor",
                error = ex.Message
            });
        }
    }
    
    [HttpPost("start-reinforcement-session")]
    public async Task<ActionResult> StartReinforcementSession([FromBody] ReinforcementSessionRequest request)
    {
        try
        {
            if (request.StudentId <= 0)
            {
                return BadRequest(new { success = false, message = "StudentId es obligatorio" });
            }

            _logger.LogInformation("🔁 Iniciando sesión de REFORZAMIENTO para estudiante ID: {StudentId}", request.StudentId);

            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Id == request.StudentId && e.Activo == true);

            if (estudiante == null)
            {
                return BadRequest(new { success = false, message = $"Estudiante no encontrado" });
            }

            var utcNow = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Unspecified);
            int testId;

            using (var testCommand = connection.CreateCommand())
            {
                testCommand.CommandText = @"
                INSERT INTO tests 
                (estudiante_id, tipo_test_id, numero_preguntas_total, 
                 hora_inicio, completado, fecha_creacion)
                VALUES 
                ($1, $2, $3, $4, $5, $6)
                RETURNING id";

                testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = estudiante.Id });
                testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = 3 }); // Tipo 3 = Reforzamiento
                testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = request.QuestionCount ?? 5 });
                testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = utcNow });
                testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = false });
                testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = utcNow });

                testId = Convert.ToInt32(await testCommand.ExecuteScalarAsync());
            }

            var questions = await GetReinforcementQuestions(
                studentId: estudiante.Id,
                count: request.QuestionCount ?? 5,
                temaId: request.TemaId,
                subtemaId: request.SubtemaId,
                connection: connection
            );

            if (!questions.Any())
            {
                return Ok(new
                {
                    success = true,
                    testId = testId,
                    questions = new List<object>(),
                    message = "¡Excelente! No tienes preguntas para reforzar en este tema.",
                    noQuestionsToReinforce = true
                });
            }

            return Ok(new
            {
                success = true,
                testId = testId,
                session = new
                {
                    sessionId = Guid.NewGuid(),
                    studentId = request.StudentId,
                    mode = "REINFORCEMENT",
                    status = "Active"
                },
                questions = questions,
                totalQuestions = questions.Count,
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error en sesión de reforzamiento");
            return StatusCode(500, new { success = false, message = "Error interno", error = ex.Message });
        }
    }

    public class ReinforcementSessionRequest
    {
        public int StudentId { get; set; }
        public int? QuestionCount { get; set; } = 5;
        public int? TemaId { get; set; }
        public int? SubtemaId { get; set; }
    }


    private async Task<List<object>> GetQuestionsFromDatabase(
      List<string> legalAreas,
      string difficulty,
      int count,
      int? temaId,
      int? subtemaId,
      System.Data.Common.DbConnection connection,
      int? studentId = null,
      bool adaptiveMode = false)
    {
        var questions = new List<object>();
        using var command = connection.CreateCommand();

        // 1) Resolver nombres de área -> IDs (INT)
        var areaIds = new List<int>();
        if (legalAreas != null && legalAreas.Any())
        {
            var names = legalAreas
                .Where(a => !string.IsNullOrWhiteSpace(a))
                .Select(a => a.Trim().ToLower())
                .ToList();

            areaIds = await _context.Areas
                .Where(a => names.Contains(a.Nombre.ToLower()))
                .Select(a => a.Id)
                .ToListAsync();
        }

        // 2) WHERE base
        var whereClauses = new List<string>
    {
        "pg.activa = true",
        "pg.tipo != 'desarrollo'"
    };

        int paramIndex = 1;

        // Filtro por nivel (si no es mixto)
        if (!string.Equals(difficulty, "mixto", StringComparison.OrdinalIgnoreCase))
        {
            whereClauses.Add($"pg.nivel = ${paramIndex}::nivel_dificultad");
            paramIndex++;
        }

        // Filtro por áreas (SIEMPRE por IDs)
        if (areaIds.Any())
        {
            whereClauses.Add($"a.id = ANY(${paramIndex}::int[])");
            paramIndex++;
        }

        // Filtro por subtema/tema
        if (subtemaId.HasValue)
        {
            whereClauses.Add($"pg.subtema_id = ${paramIndex}");
            paramIndex++;
        }
        else if (temaId.HasValue)
        {
            whereClauses.Add($"t.id = ${paramIndex}");
            paramIndex++;
        }

        // 3) SQL según modo
        if (adaptiveMode && studentId.HasValue)
        {
            command.CommandText = $@"
WITH temas_debiles AS (
    SELECT 
        r.tema_id,
        ROUND((CAST(r.total_incorrectas AS DECIMAL) / NULLIF(r.total_intentos, 0)) * 100, 1) AS tasa_error
    FROM estudiante_rendimiento_temas r
    WHERE r.estudiante_id = ${paramIndex}
      AND r.total_intentos >= 3
      AND (CAST(r.total_incorrectas AS DECIMAL) / NULLIF(r.total_intentos, 0)) > 0.3
),
preguntas_unicas AS (
    SELECT 
        pg.id,
        pg.texto_pregunta,
        pg.tipo,
        pg.nivel,
        t.nombre AS tema,
        t.id AS tema_id,
        pg.respuesta_correcta_boolean,
        pg.respuesta_correcta_opcion,
        pg.explicacion,
        COALESCE(pg.veces_utilizada, 0) AS veces_utilizada,
        CASE WHEN td.tema_id IS NOT NULL THEN 1 ELSE 2 END AS prioridad,
        td.tasa_error,
        (SELECT COUNT(*) 
           FROM test_preguntas tp 
           INNER JOIN tests tt ON tp.test_id = tt.id 
          WHERE tp.pregunta_generada_id = pg.id 
            AND tt.estudiante_id = ${paramIndex + 1}
        ) AS veces_respondida_estudiante
    FROM preguntas_generadas pg
    INNER JOIN temas  t ON pg.tema_id = t.id
    INNER JOIN areas a ON t.area_id = a.id
    LEFT  JOIN temas_debiles td ON t.id = td.tema_id
    WHERE {string.Join(" AND ", whereClauses)}
    ORDER BY 
        prioridad ASC,
        tasa_error DESC NULLS LAST,
        veces_respondida_estudiante ASC,
        COALESCE(pg.veces_utilizada, 0) ASC,
        RANDOM()
    LIMIT ${paramIndex + 2}
)
SELECT 
    pu.id, pu.texto_pregunta, pu.tipo, pu.nivel, pu.tema, pu.tema_id,
    pu.respuesta_correcta_boolean, pu.respuesta_correcta_opcion, pu.explicacion,
    po.opcion, po.texto_opcion, po.es_correcta
FROM preguntas_unicas pu
LEFT JOIN pregunta_opciones po ON pu.id = po.pregunta_generada_id
ORDER BY pu.id, po.opcion";

            if (!string.Equals(difficulty, "mixto", StringComparison.OrdinalIgnoreCase))
                command.Parameters.Add(new NpgsqlParameter { Value = difficulty.ToLower() });

            if (areaIds.Any())
                command.Parameters.Add(new NpgsqlParameter
                {
                    Value = areaIds.ToArray(),
                    NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Array | NpgsqlTypes.NpgsqlDbType.Integer
                });

            if (subtemaId.HasValue) command.Parameters.Add(new NpgsqlParameter { Value = subtemaId.Value });
            else if (temaId.HasValue) command.Parameters.Add(new NpgsqlParameter { Value = temaId.Value });

            command.Parameters.Add(new NpgsqlParameter { Value = studentId.Value }); // ${paramIndex}
            command.Parameters.Add(new NpgsqlParameter { Value = studentId.Value }); // ${paramIndex + 1}
            command.Parameters.Add(new NpgsqlParameter { Value = count });           // ${paramIndex + 2}
        }
        else
        {
            if (studentId.HasValue)
            {
                // ✅ CORREGIDO: Con CTE para separar LIMIT de JOIN con opciones
                command.CommandText = $@"
WITH preguntas_seleccionadas AS (
    SELECT 
        pg.id,
        pg.texto_pregunta,
        pg.tipo,
        pg.nivel,
        t.nombre AS tema,
        t.id     AS tema_id,
        pg.respuesta_correcta_boolean,
        pg.respuesta_correcta_opcion,
        pg.explicacion,
        (SELECT COUNT(*) 
           FROM test_preguntas tp 
           INNER JOIN tests tt ON tp.test_id = tt.id 
          WHERE tp.pregunta_generada_id = pg.id 
            AND tt.estudiante_id = ${paramIndex}
        ) AS veces_respondida_estudiante
    FROM preguntas_generadas pg
    INNER JOIN temas  t ON pg.tema_id = t.id
    INNER JOIN areas a ON t.area_id = a.id
    WHERE {string.Join(" AND ", whereClauses)}
    ORDER BY 
        veces_respondida_estudiante ASC,
        COALESCE(pg.veces_utilizada, 0) ASC,
        RANDOM()
    LIMIT ${paramIndex + 1}
)
SELECT 
    ps.id,
    ps.texto_pregunta,
    ps.tipo,
    ps.nivel,
    ps.tema,
    ps.tema_id,
    ps.respuesta_correcta_boolean,
    ps.respuesta_correcta_opcion,
    ps.explicacion,
    po.opcion,
    po.texto_opcion,
    po.es_correcta,
    ps.veces_respondida_estudiante
FROM preguntas_seleccionadas ps
LEFT JOIN pregunta_opciones po ON ps.id = po.pregunta_generada_id
ORDER BY ps.id, po.opcion";

                if (!string.Equals(difficulty, "mixto", StringComparison.OrdinalIgnoreCase))
                    command.Parameters.Add(new NpgsqlParameter { Value = difficulty.ToLower() });

                if (areaIds.Any())
                    command.Parameters.Add(new NpgsqlParameter
                    {
                        Value = areaIds.ToArray(),
                        NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Array | NpgsqlTypes.NpgsqlDbType.Integer
                    });

                if (subtemaId.HasValue) command.Parameters.Add(new NpgsqlParameter { Value = subtemaId.Value });
                else if (temaId.HasValue) command.Parameters.Add(new NpgsqlParameter { Value = temaId.Value });

                command.Parameters.Add(new NpgsqlParameter { Value = studentId.Value }); // ${paramIndex}
                command.Parameters.Add(new NpgsqlParameter { Value = count });           // ${paramIndex + 1}
            }
            else
            {
                // ✅ CORREGIDO: Sin studentId, con CTE para separar LIMIT de JOIN
                command.CommandText = $@"
WITH preguntas_seleccionadas AS (
    SELECT 
        pg.id,
        pg.texto_pregunta,
        pg.tipo,
        pg.nivel,
        t.nombre AS tema,
        t.id     AS tema_id,
        pg.respuesta_correcta_boolean,
        pg.respuesta_correcta_opcion,
        pg.explicacion
    FROM preguntas_generadas pg
    INNER JOIN temas  t ON pg.tema_id = t.id
    INNER JOIN areas a ON t.area_id = a.id
    WHERE {string.Join(" AND ", whereClauses)}
    ORDER BY 
        COALESCE(pg.veces_utilizada, 0) ASC,
        RANDOM()
    LIMIT ${paramIndex}
)
SELECT 
    ps.id,
    ps.texto_pregunta,
    ps.tipo,
    ps.nivel,
    ps.tema,
    ps.tema_id,
    ps.respuesta_correcta_boolean,
    ps.respuesta_correcta_opcion,
    ps.explicacion,
    po.opcion,
    po.texto_opcion,
    po.es_correcta
FROM preguntas_seleccionadas ps
LEFT JOIN pregunta_opciones po ON ps.id = po.pregunta_generada_id
ORDER BY ps.id, po.opcion";

                if (!string.Equals(difficulty, "mixto", StringComparison.OrdinalIgnoreCase))
                    command.Parameters.Add(new NpgsqlParameter { Value = difficulty.ToLower() });

                if (areaIds.Any())
                    command.Parameters.Add(new NpgsqlParameter
                    {
                        Value = areaIds.ToArray(),
                        NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Array | NpgsqlTypes.NpgsqlDbType.Integer
                    });

                if (subtemaId.HasValue) command.Parameters.Add(new NpgsqlParameter { Value = subtemaId.Value });
                else if (temaId.HasValue) command.Parameters.Add(new NpgsqlParameter { Value = temaId.Value });

                command.Parameters.Add(new NpgsqlParameter { Value = count }); // ${paramIndex}
            }
        }

        // ✅ LOG del SQL ejecutado
        _logger.LogInformation("🔍 SQL Query ejecutado");

        // 4) Ejecutar y armar resultado
        using var reader = await command.ExecuteReaderAsync();

        var preguntasDict = new Dictionary<int, PreguntaConOpciones>();
        int totalRowsRead = 0;

        while (await reader.ReadAsync())
        {
            totalRowsRead++;
            var preguntaId = reader.GetInt32(0);
            var opcion = reader.IsDBNull(9) ? "NULL" : reader.GetChar(9).ToString();

            // ✅ LOG: Ver cada fila leída
            _logger.LogInformation("📖 Fila {Row}: Pregunta {Id}, Opción: {Opcion}",
                totalRowsRead, preguntaId, opcion);

            if (!preguntasDict.ContainsKey(preguntaId))
            {
                preguntasDict[preguntaId] = new PreguntaConOpciones
                {
                    Id = preguntaId,
                    TextoPregunta = reader.GetString(1),
                    Tipo = reader.GetString(2),
                    Nivel = reader.GetString(3),
                    Tema = reader.GetString(4),
                    TemaId = reader.GetInt32(5),
                    RespuestaBoolean = reader.IsDBNull(6) ? (bool?)null : reader.GetBoolean(6),
                    RespuestaOpcion = reader.IsDBNull(7) ? (char?)null : reader.GetChar(7),
                    Explicacion = reader.IsDBNull(8) ? "" : reader.GetString(8),
                    Opciones = new List<OpcionDTO>()
                };
            }

            if (!reader.IsDBNull(9))
            {
                preguntasDict[preguntaId].Opciones.Add(new OpcionDTO
                {
                    Id = reader.GetChar(9).ToString(),
                    Text = reader.GetString(10),
                    IsCorrect = reader.GetBoolean(11)
                });
            }
        }

        // ✅ LOG: Resumen de lectura
        _logger.LogInformation("📊 Total filas leídas: {Rows}, Preguntas únicas: {Questions}",
            totalRowsRead, preguntasDict.Count);

        // ✅ LOG: Detalle de opciones por pregunta
        foreach (var p in preguntasDict.Values)
        {
            _logger.LogInformation("📝 Pregunta {Id} ({Tipo}): {Count} opciones",
                p.Id, p.Tipo, p.Opciones.Count);
        }

        var todasPreguntas = preguntasDict.Values.ToList();
        List<PreguntaConOpciones> preguntasFinales;

        if (!adaptiveMode && todasPreguntas.Count > 1)
        {
            var porTema = todasPreguntas
                .GroupBy(p => p.TemaId)
                .Select(g => g.OrderBy(_ => Guid.NewGuid()).ToList())
                .OrderBy(_ => Guid.NewGuid())
                .ToList();

            preguntasFinales = new List<PreguntaConOpciones>();

            // ✅ Rotación dinámica hasta completar 'count'
            int ronda = 0;
            while (preguntasFinales.Count < count && porTema.Any(g => g.Count > ronda))
            {
                foreach (var grupoTema in porTema)
                {
                    if (ronda < grupoTema.Count && preguntasFinales.Count < count)
                    {
                        preguntasFinales.Add(grupoTema[ronda]);
                    }
                }
                ronda++;
            }

            _logger.LogInformation("🔄 Round-Robin: {Count} preguntas de {Temas} temas ({Rondas} rondas)",
                preguntasFinales.Count,
                preguntasFinales.Select(p => p.TemaId).Distinct().Count(),
                ronda);
        }
        else
        {
            preguntasFinales = todasPreguntas.Take(count).ToList();
        }

        foreach (var p in preguntasFinales)
        {
            questions.Add(new
            {
                id = p.Id,
                questionText = p.TextoPregunta,
                type = p.Tipo,
                level = p.Nivel,
                tema = p.Tema,
                options = p.Tipo == "seleccion_multiple"
                    ? p.Opciones.ToArray()
                    : p.Tipo == "verdadero_falso"
                        ? new[]
                        {
                        new OpcionDTO { Id = "A", Text = "Verdadero", IsCorrect = p.RespuestaBoolean == true },
                        new OpcionDTO { Id = "B", Text = "Falso",     IsCorrect = p.RespuestaBoolean == false }
                        }
                        : null,
                correctAnswer = p.Tipo == "seleccion_multiple"
                    ? p.RespuestaOpcion?.ToString()
                    : p.RespuestaBoolean?.ToString().ToLower(),
                explanation = p.Explicacion
            });
        }

        var secuencia = string.Join(" → ", questions.Select(q => ((dynamic)q).tema.Substring(0, Math.Min(12, ((dynamic)q).tema.Length))));
        var dist = questions.GroupBy(q => ((dynamic)q).tema).Select(g => $"{g.Key}={g.Count()}");
        _logger.LogInformation(adaptiveMode ? "🎯 ADAPTATIVO: {Dist}" : "🎲 NORMAL: {Dist} | {Sec}", string.Join(", ", dist), secuencia);

        return questions;
    }







    private async Task<List<object>> GenerateQuestionsFromVectorDatabase(
        List<string> legalAreas,
        string difficulty,
        int count,
        int modalidadId,
        StudyScopeContext? scopeContext = null)
    {
        try
        {
            var providedAreas = legalAreas ?? new List<string>();
            var searchTerms = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            if (scopeContext?.SearchTerms.Any() == true)
            {
                foreach (var term in scopeContext.SearchTerms.Where(t => !string.IsNullOrWhiteSpace(t)))
                {
                    searchTerms.Add(term.Trim());
                }
            }

            foreach (var area in providedAreas.Where(a => !string.IsNullOrWhiteSpace(a)))
            {
                searchTerms.Add(area.Trim());
            }

            var searchDescription = searchTerms.Any()
                ? string.Join(", ", searchTerms)
                : "todas las áreas";

            _logger.LogInformation("🔍 Buscando documentos en Qdrant para {Areas}", searchDescription);

            string searchQuery = searchTerms.Any()
                ? string.Join(" ", searchTerms)
                : "derecho civil código civil chileno";

            var relevantDocs = await _vectorService.SearchSimilarAsync(searchQuery, limit: 5);

            if (!relevantDocs.Any())
            {
                _logger.LogWarning("⚠️ No se encontraron documentos en Qdrant para '{Query}'", searchQuery);
                return new List<object>();
            }

            _logger.LogInformation("✅ {Count} fragmentos encontrados en Qdrant", relevantDocs.Count);

            var combinedContent = string.Join("\n\n", relevantDocs.Select(d => d.Content));

            if (combinedContent.Length > 8000)
            {
                combinedContent = combinedContent.Substring(0, 8000);
                _logger.LogInformation("⚠️ Contenido truncado a 8000 caracteres");
            }

            var contextTitleParts = new List<string>();
            if (!string.IsNullOrWhiteSpace(scopeContext?.AreaName))
                contextTitleParts.Add(scopeContext!.AreaName!);
            if (!string.IsNullOrWhiteSpace(scopeContext?.TemaName))
                contextTitleParts.Add(scopeContext!.TemaName!);
            if (!string.IsNullOrWhiteSpace(scopeContext?.SubtemaName))
                contextTitleParts.Add(scopeContext!.SubtemaName!);

            var autoGeneratedTitle = contextTitleParts.Any()
                ? string.Join(" / ", contextTitleParts)
                : (searchTerms.Any() ? string.Join(", ", searchTerms) : "General");

            var legalAreasForDocument = searchTerms.Any()
                ? searchTerms.ToList()
                : new List<string> { "Derecho General" };

            var tempDocument = new LegalDocument
            {
                Id = Guid.NewGuid(),
                Title = $"Auto-generado: {autoGeneratedTitle}",
                Content = combinedContent + "\n\n[INSTRUCCIÓN CRÍTICA]: Generar SOLAMENTE preguntas de selección múltiple (con 3 opciones A, B, C) y verdadero/falso. NUNCA generar preguntas de desarrollo, preguntas abiertas, o preguntas que requieran respuestas largas. Cada pregunta debe tener exactamente una respuesta correcta que se pueda identificar con una letra o true/false.",
                TemaNombres = legalAreasForDocument,
                Difficulty = ParseDifficulty(difficulty),
                DocumentType = LegalDocumentType.StudyMaterial,
                CreatedAt = DateTime.UtcNow
            };

            _logger.LogInformation("📝 Generando {Count} preguntas con IA (modalidad {Mode})...",
                count, modalidadId == 2 ? "ORAL" : "ESCRITA");

            var studyQuestions = await _questionGeneration.GenerateQuestionsWithMixedTypesAndDifficulty(
                tempDocument,
                count,
                allowedTypes: new[] { QuestionType.TrueFalse, QuestionType.MultipleChoice }
            );

            if (!studyQuestions.Any())
            {
                _logger.LogWarning("⚠️ No se pudieron generar preguntas");
                return new List<object>();
            }

            _logger.LogInformation("✅ {Count} preguntas generadas con IA", studyQuestions.Count);

            string areaNameForPersistence = scopeContext?.AreaName
                ?? providedAreas.FirstOrDefault(a => !string.IsNullOrWhiteSpace(a))
                ?? searchTerms.FirstOrDefault()
                ?? "General";

            var areaId = scopeContext?.AreaId
                ?? await _questionPersistence.GetAreaIdByName(areaNameForPersistence);

            string temaNameForPersistence = scopeContext?.TemaName
                ?? $"Auto-generado: {areaNameForPersistence}";

            var temaId = scopeContext?.TemaId
                ?? await _questionPersistence.GetOrCreateTemaId(
                    temaNameForPersistence,
                    areaId
                );

            int? subtemaId = scopeContext?.SubtemaId;

            var savedIds = await _questionPersistence.SaveQuestionsToDatabase(
                studyQuestions,
                areaId: areaId,
                defaultTemaId: temaId,
                defaultSubtemaId: subtemaId,
                modalidadId: modalidadId,
                creadaPor: "AI-AutoGenerated"
            );

            _logger.LogInformation("💾 {Count} preguntas guardadas en BD con IDs: {Ids}",
                savedIds.Count,
                string.Join(", ", savedIds.Take(3)) + (savedIds.Count > 3 ? "..." : ""));

            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            using var command = connection.CreateCommand();

            command.CommandText = @"
                SELECT 
                    pg.id,
                    pg.texto_pregunta,
                    pg.tipo,
                    pg.nivel,
                    t.nombre as tema,
                    pg.respuesta_correcta_boolean,
                    pg.respuesta_correcta_opcion,
                    pg.explicacion,
                    po.opcion,
                    po.texto_opcion,
                    po.es_correcta
                FROM preguntas_generadas pg
                INNER JOIN temas t ON pg.tema_id = t.id
                LEFT JOIN pregunta_opciones po ON pg.id = po.pregunta_generada_id
                WHERE pg.id = ANY($1)
                ORDER BY pg.id, po.opcion";

            command.Parameters.Add(new NpgsqlParameter
            {
                Value = savedIds.ToArray(),
                NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Array | NpgsqlTypes.NpgsqlDbType.Integer
            });

            using var reader = await command.ExecuteReaderAsync();

            var preguntasDict = new Dictionary<int, PreguntaConOpciones>();

            while (await reader.ReadAsync())
            {
                var preguntaId = reader.GetInt32(0);

                if (!preguntasDict.ContainsKey(preguntaId))
                {
                    preguntasDict[preguntaId] = new PreguntaConOpciones
                    {
                        Id = preguntaId,
                        TextoPregunta = reader.GetString(1),
                        Tipo = reader.GetString(2),
                        Nivel = reader.GetString(3),
                        Tema = reader.GetString(4),
                        RespuestaBoolean = reader.IsDBNull(5) ? (bool?)null : reader.GetBoolean(5),
                        RespuestaOpcion = reader.IsDBNull(6) ? (char?)null : reader.GetChar(6),
                        Explicacion = reader.IsDBNull(7) ? "" : reader.GetString(7),
                        Opciones = new List<OpcionDTO>()
                    };
                }

                if (!reader.IsDBNull(8))
                {
                    preguntasDict[preguntaId].Opciones.Add(new OpcionDTO
                    {
                        Id = reader.GetChar(8).ToString(),
                        Text = reader.GetString(9),
                        IsCorrect = reader.GetBoolean(10)
                    });
                }
            }

            var formattedQuestions = new List<object>();

            foreach (var pregunta in preguntasDict.Values)
            {
                var questionObj = new
                {
                    id = pregunta.Id,
                    questionText = pregunta.TextoPregunta,
                    type = pregunta.Tipo,
                    level = pregunta.Nivel,
                    tema = pregunta.Tema,
                    options = pregunta.Tipo == "seleccion_multiple"
                        ? pregunta.Opciones.ToArray()
                        : pregunta.Tipo == "verdadero_falso"
                            ? new[]
                            {
                                new OpcionDTO { Id = "A", Text = "Verdadero", IsCorrect = pregunta.RespuestaBoolean == true },
                                new OpcionDTO { Id = "B", Text = "Falso", IsCorrect = pregunta.RespuestaBoolean == false }
                            }
                            : null,
                    correctAnswer = pregunta.Tipo == "seleccion_multiple"
                        ? pregunta.RespuestaOpcion?.ToString()
                        : pregunta.Tipo == "verdadero_falso"
                            ? pregunta.RespuestaBoolean?.ToString().ToLower()
                            : null,
                    explanation = pregunta.Explicacion,
                    autoGenerated = true
                };

                formattedQuestions.Add(questionObj);
            }

            return formattedQuestions;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error generando preguntas desde Qdrant");
            return new List<object>();
        }
    }

    private async Task<StudyScopeContext> BuildScopeContextAsync(StudySessionRequest request)
    {
        var scope = new StudyScopeContext();
        var searchTerms = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        if (request.LegalAreas != null)
        {
            foreach (var areaName in request.LegalAreas.Where(a => !string.IsNullOrWhiteSpace(a)))
            {
                searchTerms.Add(areaName.Trim());
            }
        }

        if (request.SubtemaId.HasValue)
        {
            var subtema = await _context.Subtemas
                .Include(s => s.Tema)
                .ThenInclude(t => t.Area)
                .FirstOrDefaultAsync(s => s.Id == request.SubtemaId.Value);

            if (subtema != null)
            {
                scope.SubtemaId = subtema.Id;
                scope.SubtemaName = subtema.Nombre;
                scope.TemaId = subtema.TemaId;
                scope.TemaName = subtema.Tema.Nombre;
                scope.AreaId = subtema.Tema.AreaId;
                scope.AreaName = subtema.Tema.Area.Nombre;

                searchTerms.Add(subtema.Nombre);
                searchTerms.Add(subtema.Tema.Nombre);
                searchTerms.Add(subtema.Tema.Area.Nombre);
            }
        }
        else if (request.TemaId.HasValue)
        {
            var tema = await _context.Temas
                .Include(t => t.Area)
                .FirstOrDefaultAsync(t => t.Id == request.TemaId.Value);

            if (tema != null)
            {
                scope.TemaId = tema.Id;
                scope.TemaName = tema.Nombre;
                scope.AreaId = tema.AreaId;
                scope.AreaName = tema.Area.Nombre;

                searchTerms.Add(tema.Nombre);
                searchTerms.Add(tema.Area.Nombre);
            }
        }

        if (scope.AreaId == null && request.LegalAreas?.Any() == true)
        {
            var firstArea = request.LegalAreas.FirstOrDefault(a => !string.IsNullOrWhiteSpace(a));
            if (!string.IsNullOrWhiteSpace(firstArea))
            {
                var normalized = firstArea.Trim().ToLower();
                var areaEntity = await _context.Areas
                    .FirstOrDefaultAsync(a => a.Nombre.ToLower() == normalized);

                if (areaEntity != null)
                {
                    scope.AreaId = areaEntity.Id;
                    scope.AreaName = areaEntity.Nombre;
                }
            }
        }

        scope.SearchTerms.AddRange(searchTerms);

        return scope;
    }

    // REFORZAMIENTO (con fallback a random por alcance)
    private async Task<List<object>> GetReinforcementQuestions(
        int studentId,
        int count,
        int? temaId = null,
        int? subtemaId = null,
        int? areaId = null,
        System.Data.Common.DbConnection? connection = null)
    {
        bool shouldClose = false;
        if (connection == null)
        {
            connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
            {
                await connection.OpenAsync();
                shouldClose = true;
            }
        }

        try
        {
            var questions = new List<object>();
            using var command = connection.CreateCommand();

            var whereClauses = new List<string>
            {
                "pg.activa = true",
                "pg.tipo != 'desarrollo'",
            };

            int paramIndex = 1;

            if (subtemaId.HasValue)
            {
                whereClauses.Add($"pg.subtema_id = ${paramIndex}");
                paramIndex++;
            }
            else if (temaId.HasValue)
            {
                whereClauses.Add($"t.id = ${paramIndex}");
                paramIndex++;
            }
            else if (areaId.HasValue)
            {
                whereClauses.Add($"a.id = ${paramIndex}");
                paramIndex++;
            }

            command.CommandText = $@"
        WITH preguntas_con_errores AS (
            SELECT 
                pg.id,
                pg.texto_pregunta,
                pg.tipo,
                pg.nivel,
                t.nombre as tema,
                t.id as tema_id,
                pg.respuesta_correcta_boolean,
                pg.respuesta_correcta_opcion,
                pg.explicacion,
                COUNT(CASE WHEN tp.es_correcta = false THEN 1 END) as total_errores,
                COUNT(*) as total_intentos,
                MAX(tp.fecha_respuesta) as ultimo_error,
                COALESCE(pg.veces_utilizada, 0) as veces_usada
            FROM preguntas_generadas pg
            INNER JOIN temas t  ON pg.tema_id = t.id
            INNER JOIN areas a ON t.area_id = a.id
            INNER JOIN test_preguntas tp ON pg.id = tp.pregunta_generada_id
            INNER JOIN tests te ON tp.test_id = te.id
            WHERE te.estudiante_id = ${paramIndex}
              AND te.completado = true
              AND {string.Join(" AND ", whereClauses)}
            GROUP BY pg.id, t.nombre, t.id
            HAVING COUNT(CASE WHEN tp.es_correcta = false THEN 1 END) > 0
            ORDER BY 
                COUNT(CASE WHEN tp.es_correcta = false THEN 1 END) DESC,
                COALESCE(pg.veces_utilizada, 0) ASC,
                MAX(tp.fecha_respuesta) DESC
            LIMIT ${paramIndex + 1}
        )
        SELECT 
            pce.id,
            pce.texto_pregunta,
            pce.tipo,
            pce.nivel,
            pce.tema,
            pce.tema_id,
            pce.respuesta_correcta_boolean,
            pce.respuesta_correcta_opcion,
            pce.explicacion,
            pce.total_errores,
            po.opcion,
            po.texto_opcion,
            po.es_correcta
        FROM preguntas_con_errores pce
        LEFT JOIN pregunta_opciones po ON pce.id = po.pregunta_generada_id
        ORDER BY pce.id, po.opcion";

            if (subtemaId.HasValue) command.Parameters.Add(new NpgsqlParameter { Value = subtemaId.Value });
            else if (temaId.HasValue) command.Parameters.Add(new NpgsqlParameter { Value = temaId.Value });
            else if (areaId.HasValue) command.Parameters.Add(new NpgsqlParameter { Value = areaId.Value });

            command.Parameters.Add(new NpgsqlParameter { Value = studentId });
            command.Parameters.Add(new NpgsqlParameter { Value = count });

            var preguntasDict = new Dictionary<int, PreguntaConOpciones>();

            using (var reader = await command.ExecuteReaderAsync())
            {
                while (await reader.ReadAsync())
                {
                    var preguntaId = reader.GetInt32(0);

                    if (!preguntasDict.ContainsKey(preguntaId))
                    {
                        preguntasDict[preguntaId] = new PreguntaConOpciones
                        {
                            Id = preguntaId,
                            TextoPregunta = reader.GetString(1),
                            Tipo = reader.GetString(2),
                            Nivel = reader.GetString(3),
                            Tema = reader.GetString(4),
                            TemaId = reader.GetInt32(5),
                            RespuestaBoolean = reader.IsDBNull(6) ? (bool?)null : reader.GetBoolean(6),
                            RespuestaOpcion = reader.IsDBNull(7) ? (char?)null : reader.GetChar(7),
                            Explicacion = reader.IsDBNull(8) ? "" : reader.GetString(8),
                            Opciones = new List<OpcionDTO>()
                        };
                    }

                    if (!reader.IsDBNull(10))
                    {
                        preguntasDict[preguntaId].Opciones.Add(new OpcionDTO
                        {
                            Id = reader.GetChar(10).ToString(),
                            Text = reader.GetString(11),
                            IsCorrect = reader.GetBoolean(12)
                        });
                    }
                }
            }

            foreach (var p in preguntasDict.Values)
            {
                questions.Add(new
                {
                    id = p.Id,
                    questionText = p.TextoPregunta,
                    type = p.Tipo,
                    level = p.Nivel,
                    tema = p.Tema,
                    options = p.Tipo == "seleccion_multiple"
                        ? p.Opciones.ToArray()
                        : p.Tipo == "verdadero_falso"
                            ? new[]
                            {
                                new OpcionDTO { Id = "A", Text = "Verdadero", IsCorrect = p.RespuestaBoolean == true },
                                new OpcionDTO { Id = "B", Text = "Falso", IsCorrect = p.RespuestaBoolean == false }
                            }
                            : null,
                    correctAnswer = p.Tipo == "seleccion_multiple"
                        ? p.RespuestaOpcion?.ToString()
                        : p.RespuestaBoolean?.ToString().ToLower(),
                    explanation = p.Explicacion
                });
            }

            var faltantes = count - questions.Count;
            if (faltantes > 0)
            {
                var yaTomadas = preguntasDict.Keys.ToArray();

                using var fallbackCmd = connection.CreateCommand();
                var fbWhere = new List<string>
                {
                    "pg.activa = true",
                    "pg.tipo != 'desarrollo'",
                    "(pg.veces_utilizada IS NULL OR pg.veces_utilizada < 5)"
                };

                int idx = 1;

                if (subtemaId.HasValue)
                {
                    fbWhere.Add($"pg.subtema_id = ${idx}"); idx++;
                }
                else if (temaId.HasValue)
                {
                    fbWhere.Add($"t.id = ${idx}"); idx++;
                }
                else if (areaId.HasValue)
                {
                    fbWhere.Add($"a.id = ${idx}"); idx++;
                }

                if (yaTomadas.Length > 0)
                {
                    fbWhere.Add($"pg.id <> ALL(${idx})");
                }

                fallbackCmd.CommandText = $@"
            SELECT 
                pg.id,
                pg.texto_pregunta,
                pg.tipo,
                pg.nivel,
                t.nombre as tema,
                t.id as tema_id,
                pg.respuesta_correcta_boolean,
                pg.respuesta_correcta_opcion,
                pg.explicacion,
                po.opcion,
                po.texto_opcion,
                po.es_correcta
            FROM preguntas_generadas pg
            INNER JOIN temas t  ON pg.tema_id = t.id
            INNER JOIN areas a ON t.area_id = a.id
            LEFT JOIN pregunta_opciones po ON pg.id = po.pregunta_generada_id
            WHERE {string.Join(" AND ", fbWhere)}
            ORDER BY COALESCE(pg.veces_utilizada, 0) ASC, RANDOM()
            LIMIT {faltantes}";

                if (subtemaId.HasValue) fallbackCmd.Parameters.Add(new NpgsqlParameter { Value = subtemaId.Value });
                else if (temaId.HasValue) fallbackCmd.Parameters.Add(new NpgsqlParameter { Value = temaId.Value });
                else if (areaId.HasValue) fallbackCmd.Parameters.Add(new NpgsqlParameter { Value = areaId.Value });

                if (yaTomadas.Length > 0)
                {
                    fallbackCmd.Parameters.Add(new NpgsqlParameter
                    {
                        Value = yaTomadas,
                        NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Array | NpgsqlTypes.NpgsqlDbType.Integer
                    });
                }

                var extraDict = new Dictionary<int, PreguntaConOpciones>();
                using (var r = await fallbackCmd.ExecuteReaderAsync())
                {
                    while (await r.ReadAsync())
                    {
                        var id = r.GetInt32(0);
                        if (!extraDict.ContainsKey(id))
                        {
                            extraDict[id] = new PreguntaConOpciones
                            {
                                Id = id,
                                TextoPregunta = r.GetString(1),
                                Tipo = r.GetString(2),
                                Nivel = r.GetString(3),
                                Tema = r.GetString(4),
                                TemaId = r.GetInt32(5),
                                RespuestaBoolean = r.IsDBNull(6) ? (bool?)null : r.GetBoolean(6),
                                RespuestaOpcion = r.IsDBNull(7) ? (char?)null : r.GetChar(7),
                                Explicacion = r.IsDBNull(8) ? "" : r.GetString(8),
                                Opciones = new List<OpcionDTO>()
                            };
                        }

                        if (!r.IsDBNull(9))
                        {
                            extraDict[id].Opciones.Add(new OpcionDTO
                            {
                                Id = r.GetChar(9).ToString(),
                                Text = r.GetString(10),
                                IsCorrect = r.GetBoolean(11)
                            });
                        }
                    }
                }

                foreach (var p in extraDict.Values)
                {
                    questions.Add(new
                    {
                        id = p.Id,
                        questionText = p.TextoPregunta,
                        type = p.Tipo,
                        level = p.Nivel,
                        tema = p.Tema,
                        options = p.Tipo == "seleccion_multiple"
                            ? p.Opciones.ToArray()
                            : p.Tipo == "verdadero_falso"
                                ? new[]
                                {
                                    new OpcionDTO { Id = "A", Text = "Verdadero", IsCorrect = p.RespuestaBoolean == true },
                                    new OpcionDTO { Id = "B", Text = "Falso", IsCorrect = p.RespuestaBoolean == false }
                                }
                                : null,
                        correctAnswer = p.Tipo == "seleccion_multiple"
                            ? p.RespuestaOpcion?.ToString()
                            : p.RespuestaBoolean?.ToString().ToLower(),
                        explanation = p.Explicacion
                    });
                }
            }

            _logger.LogInformation("🔁 Reforzamiento: {Tomadas} con errores + {Extra} aleatorias (alcance: {Scope})",
                Math.Min(count, preguntasDict.Count),
                Math.Max(0, questions.Count - preguntasDict.Count),
                subtemaId.HasValue ? $"subtema {subtemaId}" :
                temaId.HasValue ? $"tema {temaId}" :
                areaId.HasValue ? $"area {areaId}" : "sin filtro");

            return questions.Take(count).ToList();
        }
        finally
        {
            if (shouldClose && connection.State == System.Data.ConnectionState.Open)
                await connection.CloseAsync();
        }
    }

    public sealed class UpdateAvatarRequest
    {
        public int? AvatarId { get; set; }
        public string? AvatarUrl { get; set; }
    }

    private static string? MapAvatarIdToUrl(int? avatarId)
    {
        return avatarId switch
        {
            1 => "/assets/avatars/kawaii_raccoon_smile.svg",
            2 => "/assets/avatars/kawaii_raccoon_wink.svg",
            3 => "/assets/avatars/kawaii_raccoon_glasses.svg",
            _ => null
        };
    }

    // DTO tipado para evitar dynamic/anonymous en perfil
    private sealed class PerfilDTO
    {
        public int Id { get; set; }
        public string? Nombre { get; set; }
        public string? Email { get; set; }
        public string? FotoPerfil { get; set; }
        // 🔁 Ahora string?, no int?
        public string? IdAvatarSeleccionado { get; set; }
        public DateTime? FechaModificacion { get; set; }
    }

    // Mapea catálogo -> URL a partir de string? ("1","2","3")
    private static string? MapAvatarIdToUrl(string? avatarId)
    {
        if (string.IsNullOrWhiteSpace(avatarId)) return null;

        return avatarId.Trim() switch
        {
            "1" => "/assets/avatars/kawaii_raccoon_smile.svg",
            "2" => "/assets/avatars/kawaii_raccoon_wink.svg",
            "3" => "/assets/avatars/kawaii_raccoon_glasses.svg",
            _ => null
        };
    }

    private static string? BuildAvatarUrl(PerfilDTO est)
    {
        // Prioriza foto_perfil; si es null, usa el avatar del catálogo
        return !string.IsNullOrWhiteSpace(est.FotoPerfil)
            ? est.FotoPerfil
            : MapAvatarIdToUrl(est.IdAvatarSeleccionado);
    }


    [HttpPut("users/{id:int}/avatar")]
    public async Task<IActionResult> UpdateAvatar(int id, [FromBody] UpdateAvatarRequest req)
    {
        var est = await _context.Estudiantes.FirstOrDefaultAsync(e => e.Id == id && e.Activo == true);
        if (est == null)
            return NotFound(new { success = false, message = "Estudiante no encontrado" });

        if (req.AvatarId.HasValue)
        {
            // 🔁 Guardar como string ("1","2","3")
            est.IdAvatarSeleccionado = req.AvatarId.Value.ToString();
            est.FotoPerfil = null; // prioriza catálogo
        }
        else
        {
            est.IdAvatarSeleccionado = null;
            est.FotoPerfil = string.IsNullOrWhiteSpace(req.AvatarUrl) ? null : req.AvatarUrl;
        }

        est.FechaModificacion = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        var avatarUrl = BuildAvatarUrl(new PerfilDTO
        {
            FotoPerfil = est.FotoPerfil,
            // 🔁 ahora es string?
            IdAvatarSeleccionado = est.IdAvatarSeleccionado
        });

        return Ok(new { success = true, data = new { avatarUrl } });
    }


    [HttpPost("users/{id:int}/avatar/upload")]
    [Consumes("multipart/form-data")]
    [RequestSizeLimit(2_000_000)]
    public async Task<IActionResult> UploadAvatar(
       int id,
       IFormFile file,
       [FromServices] IWebHostEnvironment env)
    {
        var est = await _context.Estudiantes.FirstOrDefaultAsync(e => e.Id == id && e.Activo == true);
        if (est == null)
            return NotFound(new { success = false, message = "Estudiante no encontrado" });

        if (file == null || file.Length == 0)
            return BadRequest(new { success = false, message = "Archivo vacío" });

        if (file.Length > 2_000_000)
            return BadRequest(new { success = false, message = "Máximo 2MB" });

        var root = env.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
        var folder = Path.Combine(root, "avatars");
        Directory.CreateDirectory(folder);

        var safeExt = Path.GetExtension(file.FileName);
        var name = $"{Guid.NewGuid()}{safeExt}";
        var path = Path.Combine(folder, name);

        await using (var fs = System.IO.File.Create(path))
            await file.CopyToAsync(fs);

        var publicUrl = $"/avatars/{name}";

        est.IdAvatarSeleccionado = null;
        est.FotoPerfil = publicUrl;
        est.FechaModificacion = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        return Ok(new { success = true, data = new { url = publicUrl } });
    }



    [HttpGet("users/{id:int}/profile")]
    public async Task<IActionResult> GetUserProfile(int id)
    {
        var est = await _context.Estudiantes
            .Where(e => e.Id == id && e.Activo == true)
            .Select(e => new PerfilDTO
            {
                Id = e.Id,
                Nombre = e.Nombre,
                Email = e.Email,
                FotoPerfil = e.FotoPerfil,
                // 🔁 string?
                IdAvatarSeleccionado = e.IdAvatarSeleccionado,
                FechaModificacion = e.FechaModificacion
            })
            .FirstOrDefaultAsync();

        if (est == null)
            return NotFound(new { success = false });

        var avatarUrl = BuildAvatarUrl(est);

        return Ok(new
        {
            success = true,
            data = new
            {
                id = est.Id,
                nombre = est.Nombre,
                email = est.Email,
                avatarUrl,
                fechaModificacion = est.FechaModificacion
            }
        });
    }


    private sealed class StudyScopeContext
    {
        public int? AreaId { get; set; }
        public string? AreaName { get; set; }
        public int? TemaId { get; set; }
        public string? TemaName { get; set; }
        public int? SubtemaId { get; set; }
        public string? SubtemaName { get; set; }
        public List<string> SearchTerms { get; } = new();
    }

    private DifficultyLevel ParseDifficulty(string difficulty)
    {
        return difficulty.ToLower() switch
        {
            "basico" => DifficultyLevel.Basic,
            "intermedio" => DifficultyLevel.Intermediate,
            "avanzado" => DifficultyLevel.Advanced,
            _ => DifficultyLevel.Basic
        };
    }

    [HttpPost("submit-answer")]
    public async Task<ActionResult> SubmitAnswer([FromBody] SubmitAnswerRequest request)
    {
        try
        {
            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            var pregunta = await _context.PreguntasGeneradas
                .FirstOrDefaultAsync(p => p.Id == request.PreguntaId && p.Activa == true);

            if (pregunta == null)
            {
                return NotFound(new { success = false, message = "Pregunta no encontrada o inactiva" });
            }

            bool esCorrecta;
            string correctAnswer;

            if (pregunta.Tipo == "seleccion_multiple")
            {
                correctAnswer = pregunta.RespuestaCorrectaOpcion?.ToString() ?? "";
                esCorrecta = request.UserAnswer?.ToUpper() == correctAnswer.ToUpper();
            }
            else if (pregunta.Tipo == "verdadero_falso")
            {
                correctAnswer = pregunta.RespuestaCorrectaBoolean?.ToString().ToLower() ?? "";
                esCorrecta = request.UserAnswer?.ToLower() == correctAnswer;
            }
            else
            {
                correctAnswer = request.CorrectAnswer ?? "";
                esCorrecta = request.IsCorrect;
            }

            string feedback = FeedbackHelper.BuildStudentFeedback(
                isCorrect: esCorrecta,
                studentAnswer: request.UserAnswer ?? "",
                correctAnswer: correctAnswer,
                baseExplanation: pregunta.Explicacion ?? "Sin explicación disponible",
                questionType: pregunta.Tipo ?? "seleccion_multiple"
            );

            char? respuestaOpcion = null;
            bool? respuestaBoolean = null;

            if (pregunta.Tipo == "verdadero_falso")
            {
                if (bool.TryParse(request.UserAnswer, out bool boolValue))
                {
                    respuestaBoolean = boolValue;
                }
            }
            else if (pregunta.Tipo == "seleccion_multiple")
            {
                respuestaOpcion = ExtractAnswerLetter(request.UserAnswer);
                if (!respuestaOpcion.HasValue)
                {
                    _logger.LogWarning("No se pudo extraer letra de respuesta de: {UserAnswer}", request.UserAnswer);
                    return BadRequest(new { success = false, message = "Formato de respuesta inválido" });
                }
            }

            int timeSpentSeconds = ParseTimeSpanToSeconds(request.TimeSpent);
            var utcNow = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Unspecified);

            using (var updateCommand = connection.CreateCommand())
            {
                updateCommand.CommandText = @"
                UPDATE preguntas_generadas 
                SET veces_utilizada = COALESCE(veces_utilizada, 0) + 1,
                    ultimo_uso = $2
                WHERE id = $1";

                updateCommand.Parameters.Add(new NpgsqlParameter { Value = request.PreguntaId });
                updateCommand.Parameters.Add(new NpgsqlParameter { Value = utcNow });

                await updateCommand.ExecuteNonQueryAsync();
            }

            using (var command = connection.CreateCommand())
            {
                try
                {
                    command.CommandText = @"
                    INSERT INTO test_preguntas 
                    (test_id, pregunta_generada_id, respuesta_opcion, respuesta_boolean, es_correcta, 
                     tiempo_respuesta_segundos, fecha_respuesta, numero_orden)
                    VALUES 
                    ($1, $2, $3, $4, $5, $6, $7, $8)
                    RETURNING id";

                    command.Parameters.Add(new NpgsqlParameter { Value = request.TestId });
                    command.Parameters.Add(new NpgsqlParameter { Value = request.PreguntaId });
                    command.Parameters.Add(new NpgsqlParameter
                    {
                        Value = respuestaOpcion.HasValue ? (object)respuestaOpcion.Value : DBNull.Value
                    });
                    command.Parameters.Add(new NpgsqlParameter
                    {
                        Value = respuestaBoolean.HasValue ? (object)respuestaBoolean.Value : DBNull.Value
                    });
                    command.Parameters.Add(new NpgsqlParameter { Value = esCorrecta });
                    command.Parameters.Add(new NpgsqlParameter { Value = timeSpentSeconds });
                    command.Parameters.Add(new NpgsqlParameter { Value = utcNow });
                    command.Parameters.Add(new NpgsqlParameter { Value = request.NumeroOrden });

                    var respuestaId = Convert.ToInt32(await command.ExecuteScalarAsync());

                    _logger.LogInformation(
                        "✅ Respuesta guardada - TestId: {TestId}, PreguntaId: {PreguntaId}, " +
                        "Opción: {Opcion}, Boolean: {Boolean}, Correcta: {Correcta}",
                        request.TestId, request.PreguntaId,
                        respuestaOpcion?.ToString() ?? "null",
                        respuestaBoolean?.ToString() ?? "null",
                        esCorrecta);

                    return Ok(new
                    {
                        success = true,
                        isCorrect = esCorrecta,
                        correctAnswer = correctAnswer,
                        feedback = feedback,
                        explanation = pregunta.Explicacion,
                        respuestaId = respuestaId,
                        timestamp = DateTime.UtcNow
                    });
                }
                catch (Exception ex)
                {
                    _logger.LogWarning("⚠️ Columna respuesta_boolean no existe: {Message}", ex.Message);

                    command.Parameters.Clear();
                    command.CommandText = @"
                    INSERT INTO test_preguntas 
                    (test_id, pregunta_generada_id, respuesta_opcion, es_correcta, 
                     tiempo_respuesta_segundos, fecha_respuesta, numero_orden)
                    VALUES 
                    ($1, $2, $3, $4, $5, $6, $7)
                    RETURNING id";

                    command.Parameters.Add(new NpgsqlParameter { Value = request.TestId });
                    command.Parameters.Add(new NpgsqlParameter { Value = request.PreguntaId });
                    command.Parameters.Add(new NpgsqlParameter
                    {
                        Value = respuestaOpcion.HasValue ? (object)respuestaOpcion.Value :
                                (respuestaBoolean.HasValue ? (object)(respuestaBoolean.Value ? 'V' : 'F') : DBNull.Value)
                    });
                    command.Parameters.Add(new NpgsqlParameter { Value = esCorrecta });
                    command.Parameters.Add(new NpgsqlParameter { Value = timeSpentSeconds });
                    command.Parameters.Add(new NpgsqlParameter { Value = utcNow });
                    command.Parameters.Add(new NpgsqlParameter { Value = request.NumeroOrden });

                    var respuestaId = Convert.ToInt32(await command.ExecuteScalarAsync());

                    return Ok(new
                    {
                        success = true,
                        isCorrect = esCorrecta,
                        correctAnswer = correctAnswer,
                        feedback = feedback,
                        explanation = pregunta.Explicacion,
                        respuestaId = respuestaId,
                        timestamp = DateTime.UtcNow
                    });
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error guardando respuesta");
            return StatusCode(500, new
            {
                success = false,
                message = "Error guardando respuesta",
                error = ex.Message
            });
        }
    }

    [HttpGet("weak-topics/{studentId}")]
    public async Task<ActionResult> GetWeakTopics(int studentId)
    {
        try
        {
            _logger.LogInformation("📊 Obteniendo temas débiles para estudiante {StudentId}", studentId);

            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            using var command = connection.CreateCommand();

            command.CommandText = @"
            SELECT 
                t.nombre as tema,
                a.nombre as area,
                r.tema_id,
                r.total_intentos,
                r.total_incorrectas as total_errores,
                r.total_correctas as total_aciertos,
                ROUND((CAST(r.total_incorrectas AS DECIMAL) / r.total_intentos) * 100, 1) as tasa_error,
                r.racha_aciertos_consecutivos,
                r.tiempo_promedio_respuesta,
                r.ultima_practica
            FROM estudiante_rendimiento_temas r
            INNER JOIN temas t ON r.tema_id = t.id
            INNER JOIN areas a ON t.area_id = a.id
            WHERE r.estudiante_id = $1
              AND r.total_intentos >= 3
              AND (CAST(r.total_incorrectas AS DECIMAL) / r.total_intentos) > 0.3
            ORDER BY tasa_error DESC
            LIMIT 10";

            command.Parameters.Add(new NpgsqlParameter { Value = studentId });

            var weakTopics = new List<object>();

            using var reader = await command.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                weakTopics.Add(new
                {
                    nombre = reader.GetString(0),
                    area = reader.GetString(1),
                    temaId = reader.GetInt32(2),
                    totalIntentos = reader.GetInt32(3),
                    totalErrores = reader.GetInt32(4),
                    totalAciertos = reader.GetInt32(5),
                    tasaError = reader.GetFieldValue<double>(6),
                    rachaAciertos = reader.GetInt32(7),
                    tiempoPromedio = reader.GetInt32(8),
                    ultimaPractica = reader.GetDateTime(9)
                });
            }

            _logger.LogInformation("✅ {Count} temas débiles encontrados", weakTopics.Count);

            return Ok(new
            {
                success = true,
                data = weakTopics,
                totalWeakTopics = weakTopics.Count,
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error obteniendo temas débiles");
            return StatusCode(500, new
            {
                success = false,
                message = "Error obteniendo temas débiles",
                error = ex.Message
            });
        }
    }

    [HttpGet("adaptive-mode/{studentId}")]
    public async Task<ActionResult> GetAdaptiveMode(int studentId)
    {
        try
        {
            _logger.LogInformation("📊 Obteniendo configuración adaptativa para estudiante {StudentId}", studentId);

            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Id == studentId && e.Activo == true);

            if (estudiante == null)
            {
                return NotFound(new
                {
                    success = false,
                    message = $"Estudiante con ID {studentId} no encontrado"
                });
            }

            return Ok(new
            {
                success = true,
                data = new
                {
                    studentId = estudiante.Id,
                    adaptiveModeEnabled = estudiante.ModoAdaptativoActivo
                },
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error obteniendo configuración adaptativa");
            return StatusCode(500, new
            {
                success = false,
                message = "Error obteniendo configuración",
                error = ex.Message
            });
        }
    }

    [HttpPut("adaptive-mode/{studentId}")]
    public async Task<ActionResult> UpdateAdaptiveMode(int studentId, [FromBody] AdaptiveModeRequest request)
    {
        try
        {
            _logger.LogInformation("💾 Actualizando modo adaptativo para estudiante {StudentId}: {Enabled}",
                studentId, request.Enabled);

            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Id == studentId && e.Activo == true);

            if (estudiante == null)
            {
                return NotFound(new
                {
                    success = false,
                    message = $"Estudiante con ID {studentId} no encontrado"
                });
            }

            estudiante.ModoAdaptativoActivo = request.Enabled;
            estudiante.FechaModificacion = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            _logger.LogInformation("✅ Modo adaptativo actualizado correctamente");

            return Ok(new
            {
                success = true,
                message = request.Enabled ? "Modo adaptativo activado" : "Modo adaptativo desactivado",
                data = new
                {
                    studentId = estudiante.Id,
                    adaptiveModeEnabled = estudiante.ModoAdaptativoActivo
                },
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error actualizando modo adaptativo");
            return StatusCode(500, new
            {
                success = false,
                message = "Error actualizando configuración",
                error = ex.Message
            });
        }
    }

    [HttpPost("start-oral-session")]
    public async Task<ActionResult> StartOralSession([FromBody] StudySessionRequest request)
    {
        try
        {
            if (request.StudentId <= 0)
            {
                return BadRequest(new { success = false, message = "StudentId es obligatorio" });
            }

            _logger.LogInformation("🎤 Iniciando sesión ORAL para estudiante ID: {StudentId}", request.StudentId);

            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            var estudiante = await _context.Estudiantes
                .FirstOrDefaultAsync(e => e.Id == request.StudentId && e.Activo == true);

            if (estudiante == null)
            {
                return BadRequest(new
                {
                    success = false,
                    message = $"Estudiante con ID {request.StudentId} no encontrado"
                });
            }

            using var testCommand = connection.CreateCommand();
            testCommand.CommandText = @"
                INSERT INTO tests 
                (estudiante_id, modalidad_id, tipo_test_id, numero_preguntas_total, 
                 hora_inicio, completado, fecha_creacion)
                VALUES 
                ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id";

            var utcNow = DateTime.SpecifyKind(DateTime.UtcNow, DateTimeKind.Unspecified);

            testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = estudiante.Id });
            testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = 2 });
            testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = 1 });
            testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = request.QuestionCount ?? 5 });
            testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = utcNow });
            testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = false });
            testCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = utcNow });

            var testId = Convert.ToInt32(await testCommand.ExecuteScalarAsync());

            _logger.LogInformation("✅ Test ORAL creado con ID: {TestId}", testId);

            var questions = await GetOralQuestionsFromDatabase(
                legalAreas: request.LegalAreas,
                difficulty: request.Difficulty,
                count: request.QuestionCount ?? 5,
                connection: connection,
                studentId: estudiante.Id
            );


            // ✅ Si no hay suficientes preguntas, repetir las existentes
            int requestedCount = request.QuestionCount ?? 5;
            if (questions.Count < requestedCount && questions.Count > 0)
            {
                _logger.LogWarning("⚠️ Solo hay {Available} preguntas, se necesitan {Required}. Repitiendo...", 
                    questions.Count, requestedCount);
                
                var originalQuestions = questions.ToList();
                var random = new Random();
                
                while (questions.Count < requestedCount)
                {
                    var randomQuestion = originalQuestions[random.Next(originalQuestions.Count)];
                    questions.Add(randomQuestion);
                }
                
                _logger.LogInformation("✅ Completado: {Total} preguntas (con repeticiones)", questions.Count);
            }

            if (!questions.Any())
            {
                _logger.LogWarning("⚠️ No hay preguntas orales. Generando desde Qdrant...");

                var scopeContext = await BuildScopeContextAsync(request);

                questions = await GenerateQuestionsFromVectorDatabase(
                    legalAreas: request.LegalAreas,
                    difficulty: request.Difficulty,
                    count: 20,
                    modalidadId: 2,
                    scopeContext: scopeContext
                );

                questions = questions.Take(request.QuestionCount ?? 5).ToList();
            }

            if (!questions.Any())
            {
                return BadRequest(new
                {
                    success = false,
                    message = "No hay preguntas orales disponibles. Sube documentos con modo oral primero."
                });
            }

            _logger.LogInformation("✅ {Count} preguntas ORALES recuperadas", questions.Count);

            return Ok(new
            {
                success = true,
                testId = testId,
                session = new
                {
                    sessionId = Guid.NewGuid(),
                    studentId = request.StudentId,
                    realStudentId = estudiante.Id,
                    startTime = DateTime.UtcNow,
                    difficulty = request.Difficulty,
                    legalAreas = request.LegalAreas,
                    mode = "ORAL",
                    status = "Active"
                },
                questions = questions,
                totalQuestions = questions.Count,
                generatedWithAI = false,
                evaluationMode = "AI-Powered",
                source = "database",
                timestamp = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error generando sesión ORAL");
            return StatusCode(500, new
            {
                success = false,
                message = "Error interno del servidor",
                error = ex.Message
            });
        }
    }

    private async Task<List<object>> GetOralQuestionsFromDatabase(
        List<string> legalAreas,
        string difficulty,
        int count,
        System.Data.Common.DbConnection connection,
        int? studentId = null,
        bool adaptiveMode = false)
    {
        var questions = new List<object>();
        using var command = connection.CreateCommand();

        var whereClauses = new List<string>
        {
            "pg.activa = true",
            "pg.tipo = 'desarrollo'"
        };

        int paramIndex = 1;

        if (difficulty.ToLower() != "mixto")
        {
            whereClauses.Add($"pg.nivel = ${paramIndex}::nivel_dificultad");
            paramIndex++;
        }

        if (legalAreas != null && legalAreas.Any())
        {
            whereClauses.Add($"a.nombre = ANY(${paramIndex}::text[])");
            paramIndex++;

        }

        if (studentId.HasValue)
        {
            whereClauses.Add($@"
            pg.id NOT IN (
                SELECT DISTINCT tp.pregunta_generada_id 
                FROM test_preguntas tp
                INNER JOIN tests t ON tp.test_id = t.id
                WHERE t.estudiante_id = ${paramIndex}
                AND tp.pregunta_generada_id IS NOT NULL
            )");
            paramIndex++;
        }

        if (adaptiveMode && studentId.HasValue)
        {
            command.CommandText = $@"
        WITH temas_debiles AS (
            SELECT 
                r.tema_id,
                ROUND((CAST(r.total_incorrectas AS DECIMAL) / NULLIF(r.total_intentos, 0)) * 100, 1) as tasa_error
            FROM estudiante_rendimiento_temas r
            WHERE r.estudiante_id = ${paramIndex}
              AND r.total_intentos >= 3
              AND (CAST(r.total_incorrectas AS DECIMAL) / NULLIF(r.total_intentos, 0)) > 0.3
        )
        SELECT 
            pg.id,
            pg.texto_pregunta,
            pg.tipo,
            pg.nivel,
            t.nombre as tema,
            pg.respuesta_modelo,
            pg.explicacion,
            CASE 
                WHEN td.tema_id IS NOT NULL THEN 1
                ELSE 2
            END as prioridad,
            td.tasa_error
        FROM preguntas_generadas pg
        INNER JOIN temas t ON pg.tema_id = t.id
        INNER JOIN areas a ON t.area_id = a.id
        LEFT JOIN temas_debiles td ON t.id = td.tema_id
        WHERE {string.Join(" AND ", whereClauses)}
        ORDER BY 
            prioridad ASC,
            tasa_error DESC NULLS LAST,
            RANDOM()
        LIMIT ${paramIndex + 1}";

            command.Parameters.Add(new NpgsqlParameter { Value = studentId.Value });
            paramIndex++;
        }
        else
        {
            command.CommandText = $@"
        SELECT 
            pg.id,
            pg.texto_pregunta,
            pg.tipo,
            pg.nivel,
            t.nombre as tema,
            pg.respuesta_modelo,
            pg.explicacion
        FROM preguntas_generadas pg
        INNER JOIN temas t ON pg.tema_id = t.id
        INNER JOIN areas a ON t.area_id = a.id
        WHERE {string.Join(" AND ", whereClauses)}
        ORDER BY RANDOM()
        LIMIT ${paramIndex}";
        }

        if (difficulty.ToLower() != "mixto")
        {
            command.Parameters.Add(new NpgsqlParameter { Value = difficulty.ToLower() });
        }

        if (legalAreas != null && legalAreas.Any())
        {
            command.Parameters.Add(new NpgsqlParameter
            {
                Value = legalAreas.ToArray(),
                NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Array | NpgsqlTypes.NpgsqlDbType.Text
            });
        }

        if (studentId.HasValue && !adaptiveMode)
        {
            command.Parameters.Add(new NpgsqlParameter { Value = studentId.Value });
        }

        command.Parameters.Add(new NpgsqlParameter { Value = count });

        using var reader = await command.ExecuteReaderAsync();

        while (await reader.ReadAsync())
        {
            questions.Add(new
            {
                id = reader.GetInt32(0),
                questionText = reader.GetString(1),
                type = "oral",
                level = reader.GetString(3),
                tema = reader.GetString(4),
                expectedAnswer = reader.IsDBNull(5) ? "" : reader.GetString(5),
                explanation = reader.IsDBNull(6) ? "" : reader.GetString(6),
                evaluationCriteria = new
                {
                    allowPartialCredit = true,
                    flexibility = "high"
                }
            });
        }

        _logger.LogInformation(
            adaptiveMode
                ? "🎯 Modo adaptativo ORAL: {Count} preguntas priorizadas"
                : "🎲 Modo normal ORAL: {Count} preguntas aleatorias",
            questions.Count);

        return questions;
    }

    private char? ExtractAnswerLetter(string? userAnswer)
    {
        if (string.IsNullOrWhiteSpace(userAnswer))
            return null;

        if (userAnswer.Length == 1 && char.IsLetter(userAnswer[0]))
        {
            return char.ToUpper(userAnswer[0]);
        }

        var validLetters = new[] { 'A', 'B', 'C', 'D' };
        var foundLetter = userAnswer.FirstOrDefault(c => validLetters.Contains(char.ToUpper(c)));

        if (foundLetter != default(char))
        {
            return char.ToUpper(foundLetter);
        }

        return char.ToUpper(userAnswer[0]);
    }

    private int ParseTimeSpanToSeconds(string? timeSpanString)
    {
        if (string.IsNullOrWhiteSpace(timeSpanString))
            return 0;

        try
        {
            var duration = System.Xml.XmlConvert.ToTimeSpan(timeSpanString);
            return (int)duration.TotalSeconds;
        }
        catch
        {
            var numbers = System.Text.RegularExpressions.Regex.Matches(timeSpanString, @"\d+");
            if (numbers.Count > 0)
            {
                return int.Parse(numbers[numbers.Count - 1].Value);
            }
            return 0;
        }
    }

    [HttpPut("finish-test/{testId}")]
    public async Task<ActionResult> FinishTest(int testId)
    {
        try
        {
            _logger.LogInformation("🏁 Intentando finalizar test {TestId}", testId);

            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            using var command = connection.CreateCommand();
            command.CommandText = @"
                UPDATE tests 
                SET completado = true, 
                    hora_fin = $2
                WHERE id = $1
                RETURNING id, completado";

            command.Parameters.Add(new Npgsql.NpgsqlParameter { Value = testId });
            command.Parameters.Add(new Npgsql.NpgsqlParameter { Value = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified) });

            var result = await command.ExecuteScalarAsync();

            if (result == null)
            {
                _logger.LogWarning("⚠️ Test {TestId} no encontrado", testId);
                return NotFound(new { success = false, message = "Test no encontrado" });
            }

            _logger.LogInformation("✅ Test {TestId} marcado como completado", testId);

            return Ok(new { success = true, message = "Test completado exitosamente" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error finalizando test {TestId}", testId);
            return StatusCode(500, new
            {
                success = false,
                message = "Error al finalizar el test",
                error = ex.Message
            });
        }
    }

    private class PreguntaConOpciones
    {
        public int Id { get; set; }
        public string TextoPregunta { get; set; } = "";
        public string Tipo { get; set; } = "";
        public string Nivel { get; set; } = "";
        public string Tema { get; set; } = "";
        public int TemaId { get; set; }
        public bool? RespuestaBoolean { get; set; }
        public char? RespuestaOpcion { get; set; }
        public string Explicacion { get; set; } = "";
        public List<OpcionDTO> Opciones { get; set; } = new();
    }

    private class OpcionDTO
    {
        public string Id { get; set; } = "";
        public string Text { get; set; } = "";
        public bool IsCorrect { get; set; }
    }

    public class StudySessionRequest
    {
        public int StudentId { get; set; }
        public string Difficulty { get; set; } = "basico";
        public List<string> LegalAreas { get; set; } = new();
        public int? QuestionCount { get; set; } = 5;
        public int? TemaId { get; set; } = null;
        public int? SubtemaId { get; set; } = null;
        public bool? AdaptiveMode { get; set; } = false;
    }

    public class RegisterStudentRequest
    {
        public string Name { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
    }

    public class LoginRequest
    {
        public string Email { get; set; } = string.Empty;
    }

    public class SubmitAnswerRequest
    {
        public int TestId { get; set; }
        public int PreguntaId { get; set; }
        public string? UserAnswer { get; set; }
        public string? CorrectAnswer { get; set; }
        public string? Explanation { get; set; }
        public string? TimeSpent { get; set; }
        public int NumeroOrden { get; set; } = 1;
        public bool IsCorrect { get; set; }
    }

    public class AdaptiveModeRequest
    {
        public bool Enabled { get; set; }
    }

    public static class FeedbackHelper
    {
        public static string BuildStudentFeedback(
            bool isCorrect,
            string studentAnswer,
            string correctAnswer,
            string baseExplanation,
            string questionType)
        {
            if (isCorrect)
            {
                return $"✅ ¡Correcto! {baseExplanation}";
            }

            string wrongContext;

            switch (questionType.ToLower())
            {
                case "seleccion_multiple":
                    wrongContext = $"Seleccionaste la opción {studentAnswer?.ToUpper()}, pero la respuesta correcta es la opción {correctAnswer?.ToUpper()}. ";
                    break;

                case "verdadero_falso":
                    var studentBool = studentAnswer?.ToLower() == "true";
                    var correctBool = correctAnswer?.ToLower() == "true";
                    wrongContext = $"Tu respuesta ({(studentBool ? "Verdadero" : "Falso")}) no es correcta. La afirmación es {(correctBool ? "Verdadera" : "Falsa")}. ";
                    break;

                case "desarrollo":
                case "oral":
                    wrongContext = "Tu respuesta no capturó todos los elementos clave. ";
                    break;

                default:
                    wrongContext = "Tu respuesta no es correcta. ";
                    break;
            }

            return $"❌ {wrongContext}{baseExplanation}";
        }
    }
}
