using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using GradoCerrado.Domain.Models;

namespace GradoCerrado.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DashboardController : ControllerBase
{
    private readonly GradocerradoContext _context;
    private readonly ILogger<DashboardController> _logger;

    public DashboardController(GradocerradoContext context, ILogger<DashboardController> logger)
    {
        _context = context;
        _logger = logger;
    }

    // ============================================
    // ESTADÍSTICAS GENERALES
    // ============================================
    [HttpGet("stats/{studentId}")]
    public async Task<ActionResult> GetStudentStats(int studentId)
    {
        try
        {
            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            using var statsCommand = connection.CreateCommand();

            statsCommand.CommandText = @"
            SELECT 
                COUNT(DISTINCT t.id) as total_tests,
                COUNT(tp.id) as total_questions,
                SUM(CASE WHEN tp.es_correcta = true THEN 1 ELSE 0 END) as correct_answers,
                ROUND(
                    CASE 
                        WHEN COUNT(tp.id) > 0 
                        THEN (SUM(CASE WHEN tp.es_correcta = true THEN 1 ELSE 0 END)::numeric / COUNT(tp.id)::numeric) * 100
                        ELSE 0 
                    END, 2
                ) as success_rate
            FROM tests t
            LEFT JOIN test_preguntas tp ON t.id = tp.test_id
            WHERE t.estudiante_id = $1 AND t.completado = true";

            statsCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = studentId });

            var stats = new Dictionary<string, object>
            {
                ["totalTests"] = 0,
                ["totalQuestions"] = 0,
                ["correctAnswers"] = 0,
                ["successRate"] = 0.0m,
                ["streak"] = 0
            };

            using (var reader = await statsCommand.ExecuteReaderAsync())
            {
                if (await reader.ReadAsync())
                {
                    stats["totalTests"] = reader.IsDBNull(0) ? 0 : reader.GetInt64(0);
                    stats["totalQuestions"] = reader.IsDBNull(1) ? 0 : reader.GetInt64(1);
                    stats["correctAnswers"] = reader.IsDBNull(2) ? 0 : reader.GetInt64(2);
                    stats["successRate"] = reader.IsDBNull(3) ? 0.0m : reader.GetDecimal(3);
                }
            }

            // CALCULAR RACHA


            // CALCULAR RACHA
            using var streakCommand = connection.CreateCommand();
            streakCommand.CommandText = @"
            WITH dias_estudio AS (
                SELECT DISTINCT DATE(t.fecha_creacion AT TIME ZONE 'UTC' AT TIME ZONE 'America/Santiago') as dia
                FROM tests t
                WHERE t.estudiante_id = $1 AND t.completado = true
            ),
            hoy AS (
                SELECT (CURRENT_TIMESTAMP AT TIME ZONE 'America/Santiago')::date as fecha
            ),
            ultimo_dia AS (
                SELECT MAX(dia) as ultimo FROM dias_estudio
            )
            SELECT 
                CASE 
                    WHEN ultimo IS NULL THEN 0
                    WHEN ultimo < (SELECT fecha FROM hoy) - INTERVAL '1 day' THEN 0
                    ELSE (
                        WITH RECURSIVE racha_recursiva AS (
                            SELECT ultimo as dia, 1 as contador
                            FROM ultimo_dia
                            UNION ALL
                            SELECT de.dia, r.contador + 1
                            FROM racha_recursiva r
                            INNER JOIN dias_estudio de ON de.dia = r.dia - INTERVAL '1 day'
                            WHERE r.contador < 365
                        )
                        SELECT MAX(contador) FROM racha_recursiva
                    )
                END as streak
            FROM hoy, ultimo_dia";

            streakCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = studentId });

            try
            {
                var streakResult = await streakCommand.ExecuteScalarAsync();
                stats["streak"] = streakResult != null && streakResult != DBNull.Value ?
                    Convert.ToInt32(streakResult) : 0;
            }
            catch (Exception streakEx)
            {
                _logger.LogWarning(streakEx, "No se pudo calcular la racha, usando 0");
                stats["streak"] = 0;
            }

            try
            {
                var streakResult = await streakCommand.ExecuteScalarAsync();
                stats["streak"] = streakResult != null && streakResult != DBNull.Value ?
                    Convert.ToInt32(streakResult) : 0;
            }
            catch (Exception streakEx)
            {
                _logger.LogWarning(streakEx, "No se pudo calcular la racha, usando 0");
                stats["streak"] = 0;
            }



            return Ok(new { success = true, data = stats });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo estadísticas");
            return Ok(new { success = true, data = new { totalTests = 0, totalQuestions = 0, correctAnswers = 0, successRate = 0.0m, streak = 0 } });
        }
    }

    // ============================================
    // SESIONES RECIENTES
    // ============================================
    [HttpGet("recent-sessions/{studentId}")]
    public async Task<ActionResult> GetRecentSessions(int studentId, [FromQuery] int limit = 10)
    {
        try
        {
            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            using var command = connection.CreateCommand();

            command.CommandText = @"
                SELECT 
                    t.id,
                    t.fecha_creacion as date,
                    COALESCE(a.nombre, 'General') as area,
                    COALESCE(EXTRACT(EPOCH FROM (t.hora_fin - t.hora_inicio))::int, 0) as duration_seconds,
                    COUNT(tp.id) as total_questions,
                    SUM(CASE WHEN tp.es_correcta = true THEN 1 ELSE 0 END) as correct_answers,
                    ROUND(
                        CASE 
                            WHEN COUNT(tp.id) > 0 
                            THEN (SUM(CASE WHEN tp.es_correcta = true THEN 1 ELSE 0 END)::numeric / COUNT(tp.id)::numeric) * 100
                            ELSE 0 
                        END, 2
                    ) as success_rate
                FROM tests t
                LEFT JOIN areas a ON t.area_id = a.id
                LEFT JOIN test_preguntas tp ON t.id = tp.test_id
                WHERE t.estudiante_id = $1 AND t.completado = true
                GROUP BY t.id, t.fecha_creacion, a.nombre, t.hora_inicio, t.hora_fin
                ORDER BY t.fecha_creacion DESC
                LIMIT $2";

            command.Parameters.Add(new Npgsql.NpgsqlParameter { Value = studentId });
            command.Parameters.Add(new Npgsql.NpgsqlParameter { Value = limit });

            var sessions = new List<object>();

            using (var reader = await command.ExecuteReaderAsync())
            {
                while (await reader.ReadAsync())
                {
                    sessions.Add(new
                    {
                        testId = reader.GetInt32(0),
                        date = reader.GetDateTime(1),
                        area = reader.GetString(2),
                        durationSeconds = reader.IsDBNull(3) ? 0 : reader.GetInt32(3),
                        totalQuestions = reader.IsDBNull(4) ? 0 : reader.GetInt64(4),
                        correctAnswers = reader.IsDBNull(5) ? 0 : reader.GetInt64(5),
                        successRate = reader.IsDBNull(6) ? 0.0m : reader.GetDecimal(6)
                    });
                }
            }

            return Ok(new { success = true, data = sessions });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo sesiones recientes");
            return Ok(new { success = true, data = new List<object>() });
        }
    }

    // ============================================
    // DETALLE DE TEST ESPECÍFICO
    // ============================================
    [HttpGet("test-detail/{testId}")]
    public async Task<ActionResult> GetTestDetail(int testId)
    {
        try
        {
            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            using var command = connection.CreateCommand();

command.CommandText = @"
                SELECT 
                    t.id as test_id,
                    t.fecha_creacion,
                    t.hora_inicio,
                    t.hora_fin,
                    COALESCE(a.nombre, 'General') as area,
                    COALESCE(EXTRACT(EPOCH FROM (t.hora_fin - t.hora_inicio))::int, 0) as duration_seconds,
                    
                    tp.id as test_pregunta_id,
                    tp.numero_orden,
                    tp.es_correcta,
                    tp.tiempo_respuesta_segundos,
                    
                    pg.id as pregunta_id,
                    pg.texto_pregunta,
                    pg.tipo as pregunta_tipo,
                    pg.explicacion,
                    
                    tp.respuesta_opcion as respuesta_seleccionada,
                    
                    po.id as opcion_id,
                    po.opcion as letra_opcion,
                    po.texto_opcion,
                    po.es_correcta as opcion_es_correcta,
                    
                    tema.nombre as tema_nombre,
                    subtema.nombre as subtema_nombre
                    
                FROM tests t
                LEFT JOIN areas a ON t.area_id = a.id
                INNER JOIN test_preguntas tp ON t.id = tp.test_id
                INNER JOIN preguntas_generadas pg ON tp.pregunta_generada_id = pg.id
                LEFT JOIN pregunta_opciones po ON pg.id = po.pregunta_generada_id
                LEFT JOIN subtemas subtema ON pg.subtema_id = subtema.id
                LEFT JOIN temas tema ON subtema.tema_id = tema.id
                
                WHERE t.id = $1
                ORDER BY tp.numero_orden, po.opcion";

            command.Parameters.Add(new Npgsql.NpgsqlParameter { Value = testId });

            var testInfo = new Dictionary<string, object>();
            var questionsList = new List<object>();
            var currentQuestionId = -1;
            Dictionary<string, object>? currentQuestion = null;
            var currentAnswers = new List<object>();

            using (var reader = await command.ExecuteReaderAsync())
            {
                while (await reader.ReadAsync())
                {
                    // Info del test (solo la primera vez)
                    if (testInfo.Count == 0)
                    {
                        var durationSeconds = reader.GetInt32(5);
                        var minutes = Math.Max(1, durationSeconds / 60);

                        testInfo["testId"] = reader.GetInt32(0);
                        testInfo["date"] = reader.GetDateTime(1);
                        testInfo["startTime"] = reader.IsDBNull(2) ? (object?)null : reader.GetDateTime(2);
                        testInfo["endTime"] = reader.IsDBNull(3) ? (object?)null : reader.GetDateTime(3);
                        testInfo["area"] = reader.IsDBNull(4) ? "General" : reader.GetString(4);                        testInfo["duration"] = $"{minutes} min";
                        testInfo["duration"] = minutes > 0 ? $"{minutes} min" : "0 min";                    }

                    var preguntaId = reader.GetInt32(10);

                    // Si es una nueva pregunta
                    if (preguntaId != currentQuestionId)
                    {
                        // Guardar la pregunta anterior si existe
                        if (currentQuestion != null)
                        {
                            currentQuestion["answers"] = currentAnswers;
                            questionsList.Add(currentQuestion);
                        }

                        // Crear nueva pregunta
                        currentQuestionId = preguntaId;
                        currentAnswers = new List<object>();

                        var respuestaSeleccionada = reader.IsDBNull(14) ? (string?)null : reader.GetString(14);
                        var explicacion = reader.IsDBNull(13) ? "No hay explicación disponible" : reader.GetString(13);

                        currentQuestion = new Dictionary<string, object>
                        {
                            ["questionNumber"] = reader.GetInt16(7),
                            ["isCorrect"] = reader.GetBoolean(8),
                            ["timeSpent"] = reader.IsDBNull(9) ? 0 : reader.GetInt32(9),
                            ["preguntaId"] = preguntaId,
                            ["questionText"] = reader.GetString(11),
                            ["questionType"] = reader.GetString(12),
                            ["explanation"] = explicacion,
                            ["selectedAnswer"] = (object?)respuestaSeleccionada,
                            ["tema"] = reader.IsDBNull(19) ? "Sin tema" : reader.GetString(19),
                            ["subtema"] = reader.IsDBNull(20) ? "Sin subtema" : reader.GetString(20)                        };
                    }

                // Agregar opciÃ³n a la pregunta actual
                    if (!reader.IsDBNull(15)) // Si hay opciÃ³n
                    {
                        currentAnswers.Add(new
                        {
                            id = reader.GetInt32(15),
                            letter = reader.GetString(16),
                            text = reader.GetString(17),
                            isCorrect = reader.GetBoolean(18)
                        });
                    }
                }

                // Guardar la última pregunta
                if (currentQuestion != null)
                {
                    currentQuestion["answers"] = currentAnswers;
                    questionsList.Add(currentQuestion);
                }
            }

            // Calcular estadísticas
            var totalQuestions = questionsList.Count;
            var correctAnswers = questionsList.Count(q => (bool)((Dictionary<string, object>)q)["isCorrect"]);
            var successRate = totalQuestions > 0 ? Math.Round((decimal)correctAnswers / totalQuestions * 100, 2) : 0;

            var result = new
            {
                testInfo = testInfo,
                stats = new
                {
                    totalQuestions = totalQuestions,
                    correctAnswers = correctAnswers,
                    incorrectAnswers = totalQuestions - correctAnswers,
                    successRate = successRate
                },
                questions = questionsList
            };

            return Ok(new { success = true, data = result });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo detalle del test");
            return StatusCode(500, new { success = false, message = "Error obteniendo detalle del test" });
        }
    }

    // ============================================
    // GRÁFICO SEMANAL
    // ============================================
        [HttpGet("weekly-progress/{studentId}")]
        public async Task<ActionResult> GetWeeklyProgress(int studentId)
        {
            try
            {
                var connection = _context.Database.GetDbConnection();
                if (connection.State != System.Data.ConnectionState.Open)
                    await connection.OpenAsync();

                using var command = connection.CreateCommand();

                command.CommandText = @"
                WITH chile_now AS (
                    SELECT CURRENT_TIMESTAMP AT TIME ZONE 'America/Santiago' as ahora_chile
                ),
                chile_dates AS (
                    SELECT 
                        DATE(t.fecha_creacion AT TIME ZONE 'UTC' AT TIME ZONE 'America/Santiago') as test_date,
                        EXTRACT(DOW FROM (t.fecha_creacion AT TIME ZONE 'UTC' AT TIME ZONE 'America/Santiago')) as day_of_week,
                        COUNT(tp.id) as question_count,
                        COALESCE(a.nombre, 'General') as area
                    FROM tests t
                    CROSS JOIN chile_now
                    LEFT JOIN areas a ON t.area_id = a.id
                    INNER JOIN test_preguntas tp ON t.id = tp.test_id
                    WHERE t.estudiante_id = $1
                    AND DATE(t.fecha_creacion AT TIME ZONE 'UTC' AT TIME ZONE 'America/Santiago') >= 
                        DATE(chile_now.ahora_chile - INTERVAL '6 days')
                    AND DATE(t.fecha_creacion AT TIME ZONE 'UTC' AT TIME ZONE 'America/Santiago') <= 
                        DATE(chile_now.ahora_chile)
                    GROUP BY test_date, day_of_week, a.nombre
                )
                SELECT 
                    day_of_week,
                    area,
                    SUM(question_count) as total_questions
                FROM chile_dates
                GROUP BY day_of_week, area
                ORDER BY day_of_week";

                command.Parameters.Add(new Npgsql.NpgsqlParameter { Value = studentId });

                var weeklyData = new Dictionary<int, Dictionary<string, int>>();
                
                // Inicializar TODOS los días en 0
                for (int i = 0; i <= 6; i++)
                {
                    weeklyData[i] = new Dictionary<string, int> { ["Civil"] = 0, ["Procesal"] = 0 };
                }

                using (var reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        int dayOfWeek = Convert.ToInt32(reader.GetDouble(0));
                        string area = reader.GetString(1);
                        int count = Convert.ToInt32(reader.GetInt64(2));

                        if (area.Contains("Civil") || area == "General")
                            weeklyData[dayOfWeek]["Civil"] += count;
                        else if (area.Contains("Procesal"))
                            weeklyData[dayOfWeek]["Procesal"] += count;
                    }
                }

                var daysOfWeek = new[] { "Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb" };
                var result = weeklyData.Select(kvp => new
                {
                    date = daysOfWeek[kvp.Key],
                    civil = kvp.Value["Civil"],
                    procesal = kvp.Value["Procesal"]
                }).ToList();

                return Ok(new { success = true, data = result });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error obteniendo progreso semanal");
                return StatusCode(500, new { success = false, message = "Error obteniendo progreso semanal" });
            }
        }
    // ============================================
    // GRÁFICO MENSUAL - 12 MESES DEL AÑO
    // ============================================
    [HttpGet("monthly-progress/{studentId}/{semester}")]
    public async Task<ActionResult> GetMonthlyProgress(int studentId, int semester = 0)
    {
        try
        {
            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            using var command = connection.CreateCommand();

            // Determinar rango de meses según el semestre (0 = Ene-Jun, 1 = Jul-Dic)
            int startMonth = semester == 0 ? 1 : 7;
            int endMonth = semester == 0 ? 6 : 12;

            command.CommandText = @"
            WITH monthly_data AS (
                SELECT 
                    EXTRACT(MONTH FROM (t.fecha_creacion AT TIME ZONE 'UTC' AT TIME ZONE 'America/Santiago'))::int as month_num,
                    COUNT(tp.id) as question_count,
                    COALESCE(a.nombre, 'General') as area
                FROM tests t
                LEFT JOIN areas a ON t.area_id = a.id
                INNER JOIN test_preguntas tp ON t.id = tp.test_id
                WHERE t.estudiante_id = $1
                AND EXTRACT(YEAR FROM (t.fecha_creacion AT TIME ZONE 'UTC' AT TIME ZONE 'America/Santiago')) = EXTRACT(YEAR FROM CURRENT_TIMESTAMP AT TIME ZONE 'America/Santiago')
                GROUP BY month_num, a.nombre
            ),
            month_range AS (
                SELECT generate_series($2, $3) as month_num
            )
            SELECT 
                mr.month_num,
                COALESCE(SUM(CASE WHEN md.area LIKE '%Civil%' OR md.area = 'General' THEN md.question_count ELSE 0 END), 0) as civil_count,
                COALESCE(SUM(CASE WHEN md.area LIKE '%Procesal%' THEN md.question_count ELSE 0 END), 0) as procesal_count
            FROM month_range mr
            LEFT JOIN monthly_data md ON md.month_num = mr.month_num
            GROUP BY mr.month_num
            ORDER BY mr.month_num";

            command.Parameters.Add(new Npgsql.NpgsqlParameter { Value = studentId });
            command.Parameters.Add(new Npgsql.NpgsqlParameter { Value = startMonth });
            command.Parameters.Add(new Npgsql.NpgsqlParameter { Value = endMonth });

            var result = new List<object>();
            var monthNames = new[] { "", "Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic" };

            using (var reader = await command.ExecuteReaderAsync())
            {
                while (await reader.ReadAsync())
                {
                    var monthNum = reader.GetInt32(0);
                    var civil = Convert.ToInt32(reader.GetInt64(1));
                    var procesal = Convert.ToInt32(reader.GetInt64(2));

                    result.Add(new
                    {
                        date = monthNames[monthNum],
                        monthNum = monthNum,
                        civil = civil,
                        procesal = procesal,
                        total = civil + procesal
                    });
                }
            }

            return Ok(new { success = true, data = result });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo progreso mensual");
            return Ok(new { success = true, data = new List<object>() });
        }
    }
    [HttpGet("hierarchical-stats/{studentId}")]
    public async Task<ActionResult> GetHierarchicalStats(int studentId)
    {
        try
        {
            var connection = _context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            // Estadísticas generales
            using var generalCommand = connection.CreateCommand();
            generalCommand.CommandText = @"
            SELECT 
                COUNT(DISTINCT t.id) as total_sessions,
                COUNT(tp.id) as total_questions,
                SUM(CASE WHEN tp.es_correcta = true THEN 1 ELSE 0 END) as correct_answers,
                ROUND(
                    CASE 
                        WHEN COUNT(tp.id) > 0 
                        THEN (SUM(CASE WHEN tp.es_correcta = true THEN 1 ELSE 0 END)::numeric / COUNT(tp.id)::numeric) * 100
                        ELSE 0 
                    END, 2
                ) as success_rate
            FROM tests t
            INNER JOIN test_preguntas tp ON t.id = tp.test_id
            WHERE t.estudiante_id = $1";

            generalCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = studentId });

            var result = new List<object>();

            using (var reader = await generalCommand.ExecuteReaderAsync())
            {
                if (await reader.ReadAsync())
                {
                    result.Add(new
                    {
                        type = "general",
                        area = "General",
                        sessions = reader.GetInt64(0),
                        totalQuestions = reader.GetInt64(1),
                        correctAnswers = reader.IsDBNull(2) ? 0 : reader.GetInt64(2),
                        successRate = reader.IsDBNull(3) ? 0.0m : reader.GetDecimal(3)
                    });
                }
            }

            using var hierarchyCommand = connection.CreateCommand();
            hierarchyCommand.CommandText = @"
                SELECT 
                    a.id AS area_id,
                    a.nombre AS area_nombre,
                    t.id AS tema_id,
                    t.nombre AS tema_nombre,
                    s.id AS subtema_id,
                    s.nombre AS subtema_nombre,

                    /* Total de preguntas disponibles en BD para el subtema/tema */
                    COUNT(DISTINCT pg.id) AS total_preguntas_bd,

                    /* Practicadas por el estudiante */
                    COUNT(CASE WHEN test.estudiante_id = $1 AND test.completado = true THEN tp.id END) AS preguntas_practicadas,

                    /* Correctas del estudiante */
                    SUM(CASE WHEN test.estudiante_id = $1 AND test.completado = true AND tp.es_correcta = true THEN 1 ELSE 0 END) AS preguntas_correctas,

                    /* % acierto del estudiante en ese subtema/tema */
                    ROUND(
                        CASE 
                            WHEN COUNT(CASE WHEN test.estudiante_id = $1 AND test.completado = true THEN tp.id END) > 0 
                            THEN (SUM(CASE WHEN test.estudiante_id = $1 AND test.completado = true AND tp.es_correcta = true THEN 1 ELSE 0 END)::numeric 
                                / COUNT(CASE WHEN test.estudiante_id = $1 AND test.completado = true THEN tp.id END)::numeric) * 100
                            ELSE 0 
                        END, 2
                    ) AS porcentaje_acierto,

                    /* % practicadas respecto del total disponible en BD */
                    ROUND(
                        CASE 
                            WHEN COUNT(DISTINCT pg.id) > 0 
                            THEN (COUNT(CASE WHEN test.estudiante_id = $1 AND test.completado = true THEN tp.id END)::numeric 
                                / COUNT(DISTINCT pg.id)::numeric) * 100
                            ELSE 0
                        END, 2
                    ) AS porcentaje_practicadas

                FROM areas a
                INNER JOIN temas t ON t.area_id = a.id AND t.activo = true
                LEFT JOIN subtemas s ON s.tema_id = t.id AND (s.activo = true OR s.id IS NULL)
                LEFT JOIN preguntas_generadas pg 
                    ON (pg.subtema_id = s.id) OR (s.id IS NULL AND pg.tema_id = t.id)
                LEFT JOIN test_preguntas tp ON tp.pregunta_generada_id = pg.id
                LEFT JOIN tests test ON test.id = tp.test_id AND test.estudiante_id = $1 AND test.completado = true

                WHERE a.id IN (1, 2)

                GROUP BY a.id, a.nombre, t.id, t.nombre, s.id, s.nombre
                ORDER BY a.id, t.nombre, s.nombre";


            hierarchyCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = studentId });

 // Primero: Obtener TODOS los temas y subtemas activos
            var allTemasSubtemas = new Dictionary<int, Dictionary<int, List<object>>>();
            
            using var allStructureCommand = connection.CreateCommand();
            allStructureCommand.CommandText = @"
                SELECT 
                    a.id as area_id,
                    t.id as tema_id,
                    t.nombre as tema_nombre,
                    s.id as subtema_id,
                    s.nombre as subtema_nombre
                FROM areas a
                INNER JOIN temas t ON t.area_id = a.id AND t.activo = true
                LEFT JOIN subtemas s ON s.tema_id = t.id AND s.activo = true
                WHERE a.id IN (1, 2)
                ORDER BY a.id, t.nombre, s.nombre";
            
            using (var structureReader = await allStructureCommand.ExecuteReaderAsync())
            {
                while (await structureReader.ReadAsync())
                {
                    int areaId = structureReader.GetInt32(0);
                    int temaId = structureReader.GetInt32(1);
                    string temaNombre = structureReader.GetString(2);
                    int? subtemaId = structureReader.IsDBNull(3) ? null : structureReader.GetInt32(3);
                    string? subtemaNombre = structureReader.IsDBNull(4) ? null : structureReader.GetString(4);
                    
                    if (!allTemasSubtemas.ContainsKey(areaId))
                        allTemasSubtemas[areaId] = new Dictionary<int, List<object>>();
                    
                    if (!allTemasSubtemas[areaId].ContainsKey(temaId))
                        allTemasSubtemas[areaId][temaId] = new List<object>();
                    
                    if (subtemaId.HasValue && !string.IsNullOrEmpty(subtemaNombre))
                    {
                        allTemasSubtemas[areaId][temaId].Add(new
                        {
                            subtemaId = subtemaId.Value,
                            subtemaNombre = subtemaNombre,
                            totalPreguntas = 0L,
                            preguntasPracticadas = 0L,
                            preguntasCorrectas = 0L,
                            porcentajeAcierto = 0m,
                            porcentajePracticadas = 0m
                        });
                    }
                }
            }

            // Segundo: Obtener los datos del estudiante
            var datosEstudiante = new Dictionary<int, decimal>();
            
            using (var reader = await hierarchyCommand.ExecuteReaderAsync())
            {
                int ordAreaId = reader.GetOrdinal("area_id");
                int ordTemaId = reader.GetOrdinal("tema_id");
                int ordSubtemaId = reader.GetOrdinal("subtema_id");
                int ordTotalPregBD = reader.GetOrdinal("total_preguntas_bd");
                int ordPracticadas = reader.GetOrdinal("preguntas_practicadas");
                int ordCorrectas = reader.GetOrdinal("preguntas_correctas");
                int ordPctAcierto = reader.GetOrdinal("porcentaje_acierto");
                int ordPctPracticadas = reader.GetOrdinal("porcentaje_practicadas");

                while (await reader.ReadAsync())
                {
                    int areaId = reader.GetInt32(ordAreaId);
                    int temaId = reader.GetInt32(ordTemaId);
                    int? subtemaId = reader.IsDBNull(ordSubtemaId) ? null : reader.GetInt32(ordSubtemaId);
                    
                    if (subtemaId.HasValue && allTemasSubtemas.ContainsKey(areaId) && 
                        allTemasSubtemas[areaId].ContainsKey(temaId))
                    {
                        long totalPreguntasBD = reader.IsDBNull(ordTotalPregBD) ? 0 : reader.GetInt64(ordTotalPregBD);
                        long preguntasPracticadas = reader.IsDBNull(ordPracticadas) ? 0 : reader.GetInt64(ordPracticadas);
                        long preguntasCorrectas = reader.IsDBNull(ordCorrectas) ? 0 : reader.GetInt64(ordCorrectas);
                        decimal porcentajeAcierto = reader.IsDBNull(ordPctAcierto) ? 0m : reader.GetDecimal(ordPctAcierto);
                        decimal porcentajePracticadas = reader.IsDBNull(ordPctPracticadas) ? 0m : reader.GetDecimal(ordPctPracticadas);

                        // Actualizar el subtema con los datos reales
                        var subtemasList = allTemasSubtemas[areaId][temaId];
                        for (int i = 0; i < subtemasList.Count; i++)
                        {
                            dynamic sub = subtemasList[i];
                            if (sub.subtemaId == subtemaId.Value)
                            {
                                subtemasList[i] = new
                                {
                                    subtemaId = subtemaId.Value,
                                    subtemaNombre = sub.subtemaNombre,
                                    totalPreguntas = totalPreguntasBD,
                                    preguntasPracticadas = preguntasPracticadas,
                                    preguntasCorrectas = preguntasCorrectas,
                                    porcentajeAcierto = porcentajeAcierto,
                                    porcentajePracticadas = porcentajePracticadas
                                };
                                break;
                            }
                        }
                    }
                }
            }

            // Tercero: Construir la respuesta final
            var temasByArea = new Dictionary<int, List<object>>();
            
            foreach (var areaId in new[] { 1, 2 })
            {
                temasByArea[areaId] = new List<object>();
                
                if (allTemasSubtemas.ContainsKey(areaId))
                {
                    foreach (var temaId in allTemasSubtemas[areaId].Keys)
                    {
                        var subtemas = allTemasSubtemas[areaId][temaId];
                        
                        // Calcular porcentaje del tema como PROMEDIO de subtemas
                        decimal porcentajeAcierto = subtemas.Count > 0
                            ? Math.Round(subtemas.Average(s => (decimal)((dynamic)s).porcentajeAcierto), 2)
                            : 0;

                        long totalPreguntasBD = subtemas.Sum(s => (long)((dynamic)s).totalPreguntas);
                        long totalPracticadas = subtemas.Sum(s => (long)((dynamic)s).preguntasPracticadas);
                        long totalCorrectas = subtemas.Sum(s => (long)((dynamic)s).preguntasCorrectas);

                        decimal porcentajePracticadas = totalPreguntasBD > 0
                            ? Math.Round((decimal)totalPracticadas / totalPreguntasBD * 100, 2)
                            : 0;

                        using var temaCommand = connection.CreateCommand();
                        temaCommand.CommandText = "SELECT nombre FROM temas WHERE id = $1";
                        temaCommand.Parameters.Add(new Npgsql.NpgsqlParameter { Value = temaId });
                        string temaNombre = (string)(await temaCommand.ExecuteScalarAsync() ?? "");

                        temasByArea[areaId].Add(new
                        {
                            type = "tema",
                            temaId = temaId,
                            temaNombre = temaNombre,
                            totalPreguntas = totalPreguntasBD,
                            preguntasPracticadas = totalPracticadas,
                            preguntasCorrectas = totalCorrectas,
                            porcentajeAcierto = porcentajeAcierto,
                            porcentajePracticadas = porcentajePracticadas,
                            subtemas = subtemas
                        });
                    }
                }

                string areaNombre = areaId == 1 ? "Derecho Civil" : "Derecho Procesal";
                result.Add(new
                {
                    type = "area",
                    area = areaNombre,
                    temas = temasByArea[areaId]
             });
            }

            return Ok(new { success = true, data = result });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo estadísticas jerárquicas para estudiante {StudentId}", studentId);
            return Ok(new { success = true, data = new List<object>() });
        }
    }
}