﻿// src/GradoCerrado.Api/Controllers/GeminiQuickTestController.cs
using GradoCerrado.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace GradoCerrado.Api.Controllers;


[ApiController]
[Route("api/gemini-test")]
public class GeminiQuickTestController : ControllerBase
{
    private readonly IQuestionValidationService _validation;
    private readonly ILogger<GeminiQuickTestController> _logger;

    public GeminiQuickTestController(
        IQuestionValidationService validation,
        ILogger<GeminiQuickTestController> logger)
    {
        _validation = validation;
        _logger = logger;
    }


    // Agregar en GeminiQuickTestController.cs

    [HttpGet("models")]
    public async Task<IActionResult> ListAvailableModels([FromServices] IConfiguration config)
    {
        var apiKey = config["Gemini:ApiKey"];
        var httpClient = new HttpClient();

        try
        {
            // Probar con v1
            var urlV1 = $"https://generativelanguage.googleapis.com/v1/models?key={apiKey}";
            var responseV1 = await httpClient.GetStringAsync(urlV1);

            _logger.LogInformation("✅ Modelos disponibles en v1");

            return Ok(new
            {
                success = true,
                apiVersion = "v1",
                models = responseV1
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error obteniendo modelos");
            return BadRequest(new { error = ex.Message });
        }
    }

    [HttpGet]
    public async Task<IActionResult> Test()
    {
        _logger.LogInformation("🧪 Probando Gemini...");

        var result = await _validation.ValidateQuestionAsync(
            chunkContent: "El artículo 19 de la Constitución Política de Chile establece los derechos y deberes fundamentales de las personas, garantizando el derecho a la vida, a la integridad física y psíquica, la igualdad ante la ley, el respeto y protección a la vida privada y a la honra de la persona y su familia.",
            questionText: "¿Qué establece el artículo 19 de la Constitución?",
            expectedAnswer: "Establece los derechos y deberes fundamentales de las personas"
        );

        _logger.LogInformation("✅ Test completado - Válida: {IsValid}", result.IsValid);

        return Ok(new
        {
            success = true,
            geminiConectado = true,
            resultado = new
            {
                preguntaValida = result.IsValid,
                scores = new
                {
                    relevancia = result.Scores.QuestionRelevance,
                    calidad = result.Scores.QuestionQuality,
                    respuestaCorrecta = result.Scores.AnswerCorrectness
                },
                feedback = result.Feedback
            },
            mensaje = "✅ Gemini funcionando correctamente"
        });
    }
}