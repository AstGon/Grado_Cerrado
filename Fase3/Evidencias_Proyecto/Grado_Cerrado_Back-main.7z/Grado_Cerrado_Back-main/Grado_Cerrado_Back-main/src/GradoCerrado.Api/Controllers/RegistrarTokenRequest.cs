﻿namespace GradoCerrado.Api.Controllers
{
    //cambiar a las clases o a DTOs
    public class RegistrarTokenRequest
    {
        public int EstudianteId { get; set; }
        public string Token { get; set; }
    }
}