﻿// ═══════════════════════════════════════════════════════════════════
// ARCHIVO: src/GradoCerrado.Application/Interfaces/IQuestionGenerationService.cs
// REEMPLAZAR COMPLETAMENTE
// ═══════════════════════════════════════════════════════════════════

using GradoCerrado.Domain.Entities;

namespace GradoCerrado.Application.Interfaces;

public interface IQuestionGenerationService
{
    /// <summary>
    /// Genera preguntas de un documento
    /// </summary>
    ///  <param name="validateWithAI">Si es true, valida con Gemini antes de retornar (default: true)</param>
    Task<List<StudyQuestion>> GenerateQuestionsFromDocument(
        LegalDocument document,
        int count = 10,
        bool validateWithAI = true);  // 🆕 PARÁMETRO OPCIONAL

    /// <summary>
    /// 🆕 Genera preguntas con DISTRIBUCIÓN DE NIVELES (básico, intermedio, avanzado)
    /// </summary>
    Task<List<StudyQuestion>> GenerateQuestionsWithMixedTypesAndDifficulty(
        LegalDocument document,
        int totalCount,
        QuestionType[]? allowedTypes = null);

    /// <summary>
    /// Genera preguntas aleatorias de áreas y dificultad específicas
    /// </summary>
    Task<List<StudyQuestion>> GenerateRandomQuestions(
        List<string> legalAreas,
        DifficultyLevel difficulty,
        int count = 5);

    /// <summary>
    /// Genera pregunta de seguimiento basada en respuesta anterior
    /// </summary>
    Task<StudyQuestion> GenerateFollowUpQuestion(
        StudyQuestion originalQuestion,
        bool wasCorrect);

    /// <summary>
    /// Genera y guarda preguntas
    /// </summary>
    Task<List<StudyQuestion>> GenerateAndSaveQuestionsAsync(
        string topic,
        List<string> legalAreas,
        DifficultyLevel difficulty,
        int count = 5);

    Task<List<StudyQuestion>> ValidateQuestionsWithGemini(
    List<StudyQuestion> questions,
    string documentContent);

}

