using System.Threading.Tasks;

namespace GradoCerrado.Application.Interfaces
{
    public interface IEmailService
    {
        Task<bool> SendPasswordResetEmailAsync(string toEmail, string resetToken);
    }
}