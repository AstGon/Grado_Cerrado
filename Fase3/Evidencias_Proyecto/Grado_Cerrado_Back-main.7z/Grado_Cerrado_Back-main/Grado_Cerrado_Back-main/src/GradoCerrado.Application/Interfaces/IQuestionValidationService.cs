﻿// src/GradoCerrado.Application/Interfaces/IQuestionValidationService.cs
using GradoCerrado.Application.DTOs;
namespace GradoCerrado.Application.Interfaces;

public interface IQuestionValidationService
{
    Task<ValidationResult> ValidateQuestionAsync(
        string chunkContent,
        string questionText,
        string expectedAnswer);
}

