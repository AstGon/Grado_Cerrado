﻿using GradoCerrado.Application.DTOs.Auth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradoCerrado.Application.Interfaces
{
    public interface IAuthService
    {
        Task<ConnectionTestResult> TestConnectionAsync();
        Task<UpdateProfileResult> UpdateProfileAsync(int studentId, UpdateProfileRequest request);
        Task<ConnectionInfoResult> GetConnectionInfoAsync();
        Task<RegisterResult> RegisterAsync(AuthRegisterRequest request);
        Task<LoginResult> LoginAsync(AuthLoginRequest request);
        Task<CompleteDiagnosticResult> CompleteDiagnosticTestAsync(CompleteDiagnosticRequest request);
        Task<DiagnosticStatusResult> GetDiagnosticStatusAsync(int estudianteId);
    }
}
