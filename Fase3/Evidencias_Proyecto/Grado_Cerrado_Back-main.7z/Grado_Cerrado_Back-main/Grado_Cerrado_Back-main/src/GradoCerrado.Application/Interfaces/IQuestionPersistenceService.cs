﻿using GradoCerrado.Domain.Entities;

namespace GradoCerrado.Application.Interfaces;

/// <summary>
/// Servicio para persistir preguntas generadas en la base de datos
/// </summary>
public interface IQuestionPersistenceService
{
    /// <summary>
    /// 🆕 Guarda preguntas CLASIFICANDO cada una según sus fragmentos de contexto
    /// </summary>
    /// <param name="studyQuestions">Lista de preguntas a guardar</param>
    /// <param name="areaId">ID del área legal (obligatorio)</param>
    /// <param name="defaultTemaId">ID del tema por defecto si no se puede clasificar (opcional)</param>
    /// <param name="defaultSubtemaId">ID del subtema por defecto (opcional)</param>
    /// <param name="modalidadId">ID de la modalidad (1=escrito, 2=oral)</param>
    /// <param name="creadaPor">Identificador de quién creó las preguntas</param>
    /// <returns>Lista de IDs de las preguntas guardadas</returns>
    Task<List<int>> SaveQuestionsToDatabase(
        List<StudyQuestion> studyQuestions,
        int areaId,
        int? defaultTemaId = null,
        int? defaultSubtemaId = null,
        int modalidadId = 1,
        string creadaPor = "AI");

    /// <summary>
    /// Obtiene o crea un tema en la base de datos
    /// </summary>
    /// <param name="temaName">Nombre del tema</param>
    /// <param name="areaId">ID del área legal</param>
    /// <returns>ID del tema</returns>
    Task<int> GetOrCreateTemaId(string temaName, int areaId);

    /// <summary>
    /// Obtiene el ID de un área legal por nombre
    /// </summary>
    /// <param name="areaName">Nombre del área legal</param>
    /// <returns>ID del área</returns>
    Task<int> GetAreaIdByName(string areaName);
}