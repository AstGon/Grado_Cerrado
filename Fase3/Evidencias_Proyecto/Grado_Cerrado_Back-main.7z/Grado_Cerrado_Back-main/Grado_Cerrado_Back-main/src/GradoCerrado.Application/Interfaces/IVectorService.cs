﻿namespace GradoCerrado.Application.Interfaces;

public interface IVectorService
{
    Task<bool> InitializeCollectionAsync();
    Task<string> AddDocumentAsync(string content, Dictionary<string, object> metadata);
    Task<string> AddDocumentAsync(
        string content,
        Dictionary<string, object> metadata,
        float[] embedding);
    Task<List<SearchResult>> SearchSimilarAsync(string query, int limit = 5);
    Task<bool> DeleteDocumentAsync(string documentId);
    Task<bool> CollectionExistsAsync();
    Task<CollectionStats> GetCollectionStatsAsync();

    // 🆕 ESTE MÉTODO DEBE ESTAR AQUÍ
    Task<List<SearchResult>> GetPointsByIdsAsync(List<string> pointIds);
    Task<bool> CreatePayloadIndexAsync(string fieldName, string fieldType = "keyword");
}

public class CollectionStats
{
    public long VectorsCount { get; set; }
    public long IndexedVectorsCount { get; set; }
    public string Status { get; set; } = "";
}

public class SearchResult
{
    public string Id { get; set; } = string.Empty;
    public string Content { get; set; } = string.Empty;
    public double Score { get; set; }
    public Dictionary<string, object> Metadata { get; set; } = new();
}