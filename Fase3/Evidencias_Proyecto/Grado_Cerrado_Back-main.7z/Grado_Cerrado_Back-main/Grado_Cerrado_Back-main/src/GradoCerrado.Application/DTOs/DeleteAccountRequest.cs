﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradoCerrado.Application.DTOs
{
    // DTO para eliminar cuenta
    public class DeleteAccountRequest
    {
        public string Password { get; set; } = string.Empty;
    }
}
