﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradoCerrado.Application.DTOs.Auth
{
    public class DiagnosticStatusDataDto
    {
        public int EstudianteId { get; set; }
        public bool TestCompletado { get; set; }
        public DateTime? FechaCompletado { get; set; }
        public bool RequiereTest { get; set; }
    }
}
