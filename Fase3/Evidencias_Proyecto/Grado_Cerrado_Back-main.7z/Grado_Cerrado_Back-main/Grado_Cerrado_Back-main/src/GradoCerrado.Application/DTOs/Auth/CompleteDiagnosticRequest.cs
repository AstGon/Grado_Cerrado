﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradoCerrado.Application.DTOs.Auth
{
    public class CompleteDiagnosticRequest
    {
        public int EstudianteId { get; set; }
        // Podrías agregar más campos como resultados del test, nivel asignado, etc.
        public string? ResultadoNivel { get; set; }
        public int? PuntajeObtenido { get; set; }
    }
}
