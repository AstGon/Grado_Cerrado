﻿// src/GradoCerrado.Application/DTOs/ValidationDTOs.cs
namespace GradoCerrado.Application.DTOs;

/// <summary>
/// Resultado de validación con Gemini (solo en memoria - NO se guarda en BD)
/// </summary>
public class ValidationResult
{
    public bool IsValid { get; set; }
    public ValidationScores Scores { get; set; } = new();
    public List<string> Issues { get; set; } = new();
    public List<string> Recommendations { get; set; } = new();
    public string Feedback { get; set; } = string.Empty;
    public bool ShouldRegenerate { get; set; }
    public DateTime ValidatedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>
/// Scores detallados de la validación
/// </summary>
public class ValidationScores
{
    /// <summary>
    /// ¿La pregunta es relevante al chunk? (0-1)
    /// </summary>
    public decimal QuestionRelevance { get; set; }

    /// <summary>
    /// ¿La pregunta es de calidad pedagógica? (0-1)
    /// </summary>
    public decimal QuestionQuality { get; set; }

    /// <summary>
    /// ¿La respuesta es correcta? (0-1)
    /// </summary>
    public decimal AnswerCorrectness { get; set; }

    /// <summary>
    /// ¿La respuesta es coherente con la pregunta? (0-1)
    /// </summary>
    public decimal AnswerCoherence { get; set; }

    /// <summary>
    /// ¿Hay coherencia general chunk-pregunta-respuesta? (0-1)
    /// </summary>
    public decimal OverallCoherence { get; set; }
}

/// <summary>
/// Estadísticas de validación para logs y respuestas al frontend
/// </summary>
public class ValidationStatsDto
{
    public int TotalGenerated { get; set; }
    public int TotalValidated { get; set; }
    public int Approved { get; set; }
    public int Rejected { get; set; }
    public int Errors { get; set; }
    public decimal ApprovalRate { get; set; }
    public List<string>? RejectionReasons { get; set; }
}