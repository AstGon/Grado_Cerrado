﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradoCerrado.Application.DTOs.Auth
{
    public class ConnectionInfoResult
    {
        public bool Success { get; set; }
        public string? Host { get; set; }
        public string? Port { get; set; }
        public string? Database { get; set; }
        public string? Username { get; set; }
        public bool HasPassword { get; set; }
        public string? Error { get; set; }
    }
}
