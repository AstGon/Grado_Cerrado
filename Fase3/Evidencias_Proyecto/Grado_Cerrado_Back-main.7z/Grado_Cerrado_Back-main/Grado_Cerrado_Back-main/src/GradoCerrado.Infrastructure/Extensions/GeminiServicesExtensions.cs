// src/GradoCerrado.Infrastructure/Extensions/GeminiServicesExtensions.cs
using GradoCerrado.Application.Interfaces;
using GradoCerrado.Infrastructure.Services;
using Microsoft.Extensions.DependencyInjection;

namespace GradoCerrado.Infrastructure.Extensions;

/// <summary>
/// Extensiones para configurar servicios de Gemini optimizados para documentos grandes
/// </summary>
public static class GeminiServicesExtensions
{
    /// <summary>
    /// Registra el servicio h�brido de validaci�n (RECOMENDADO)
    /// Combina extracci�n inteligente + resumen autom�tico seg�n tama�o del documento
    /// </summary>
    public static IServiceCollection AddHybridGeminiValidation(
        this IServiceCollection services)
    {
        // Rate limiter (singleton para compartir estado)
        services.AddSingleton<GeminiRateLimiter>();

        // Summarizer (para casos extremos)
        services.AddScoped<GeminiDocumentSummarizer>();

        // Servicio principal h�brido
        services.AddScoped<IQuestionValidationService, HybridGeminiValidationService>();

        return services;
    }

    /// <summary>
    /// Registra solo el servicio mejorado con extracci�n inteligente
    /// (Sin capacidad de resumen, m�s r�pido pero limitado a documentos medianos)
    /// </summary>
    public static IServiceCollection AddEnhancedGeminiValidation(
        this IServiceCollection services)
    {
        services.AddSingleton<GeminiRateLimiter>();

        // Nota: Este servicio usa la clase GeminiQuestionValidationService_Enhanced.cs
        // Necesitas renombrarla a GeminiQuestionValidationService.cs o ajustar el registro
        // services.AddScoped<IQuestionValidationService, EnhancedGeminiValidationService>();

        return services;
    }

    /// <summary>
    /// Configuraci�n personalizada con l�mites ajustables
    /// </summary>
    public static IServiceCollection AddGeminiValidationWithOptions(
        this IServiceCollection services,
        Action<GeminiValidationOptions>? configureOptions = null)
    {
        var options = new GeminiValidationOptions();
        configureOptions?.Invoke(options);

        services.AddSingleton(options);
        services.AddSingleton<GeminiRateLimiter>();
        services.AddScoped<GeminiDocumentSummarizer>();
        services.AddScoped<IQuestionValidationService, HybridGeminiValidationService>();

        return services;
    }
}

/// <summary>
/// Opciones configurables para el servicio de validaci�n
/// </summary>
public class GeminiValidationOptions
{
    /// <summary>
    /// Tama�o �ptimo del contexto para validaci�n (default: 6000 caracteres)
    /// </summary>
    public int OptimalContextSize { get; set; } = 6000;

    /// <summary>
    /// Umbral para activar resumen autom�tico (default: 50000 caracteres)
    /// </summary>
    public int SummaryThreshold { get; set; } = 50000;

    /// <summary>
    /// Tiempo m�nimo entre requests a Gemini en segundos (default: 2)
    /// </summary>
    public int MinSecondsBetweenRequests { get; set; } = 2;

    /// <summary>
    /// N�mero m�ximo de reintentos en caso de error (default: 3)
    /// </summary>
    public int MaxRetries { get; set; } = 3;

    /// <summary>
    /// Habilitar logs detallados de procesamiento (default: false)
    /// </summary>
    public bool EnableDetailedLogging { get; set; } = false;
}