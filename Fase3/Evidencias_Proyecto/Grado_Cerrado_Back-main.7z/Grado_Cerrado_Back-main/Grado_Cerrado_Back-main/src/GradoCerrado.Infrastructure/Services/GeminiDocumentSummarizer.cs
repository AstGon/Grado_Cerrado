﻿
// src/GradoCerrado.Infrastructure/Services/GeminiDocumentSummarizer.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace GradoCerrado.Infrastructure.Services;

/// <summary>
/// Servicio para resumir documentos grandes usando Gemini
/// Útil cuando el documento excede los límites incluso con extracción de contexto
/// </summary>
public class GeminiDocumentSummarizer
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<GeminiDocumentSummarizer> _logger;
    private readonly string _apiKey;
    private readonly string _model;
    private readonly GeminiRateLimiter _rateLimiter;

    private const int MAX_CHUNK_SIZE = 30000; // Gemini 1.5 Pro soporta ~30K tokens

    public GeminiDocumentSummarizer(
        HttpClient httpClient,
        IConfiguration configuration,
        ILogger<GeminiDocumentSummarizer> logger,
        GeminiRateLimiter rateLimiter)
    {
        _httpClient = httpClient;
        _logger = logger;
        _rateLimiter = rateLimiter;
        _apiKey = configuration["Gemini:ApiKey"]
            ?? throw new InvalidOperationException("Gemini API Key no configurada");
        _model = configuration["Gemini:Model"] ?? "gemini-1.5-pro";
    }

    /// <summary>
    /// Resume un documento largo en partes manejables
    /// </summary>
    public async Task<string> SummarizeForValidationAsync(
        string fullContent,
        string questionContext)
    {
        if (string.IsNullOrWhiteSpace(fullContent))
            return string.Empty;

        // Si es suficientemente pequeño, devolver tal cual
        if (fullContent.Length <= MAX_CHUNK_SIZE)
            return fullContent;

        _logger.LogInformation(
            "📝 Documento muy grande ({Length} chars). Generando resumen contextual...",
            fullContent.Length);

        try
        {
            // Dividir en chunks para procesar por partes si es necesario
            var chunks = SplitIntoManagedChunks(fullContent, MAX_CHUNK_SIZE);

            if (chunks.Count == 1)
            {
                // Un solo chunk grande, resumir directamente
                return await SummarizeSingleChunkAsync(chunks[0], questionContext);
            }

            // Múltiples chunks: resumir cada uno y luego consolidar
            var summaries = new List<string>();

            for (int i = 0; i < chunks.Count; i++)
            {
                _logger.LogDebug("📄 Resumiendo chunk {Current}/{Total}...", i + 1, chunks.Count);

                var summary = await SummarizeSingleChunkAsync(chunks[i], questionContext);
                summaries.Add(summary);

                // Pausar entre chunks para rate limiting
                if (i < chunks.Count - 1)
                {
                    await Task.Delay(2000);
                }
            }

            // Consolidar resúmenes
            var consolidatedSummary = string.Join("\n\n", summaries);

            // Si aún es muy grande, resumir una vez más
            if (consolidatedSummary.Length > MAX_CHUNK_SIZE)
            {
                _logger.LogDebug("🔄 Consolidando resúmenes finales...");
                return await SummarizeSingleChunkAsync(consolidatedSummary, questionContext);
            }

            return consolidatedSummary;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error resumiendo documento");

            // Fallback: devolver el inicio del documento
            return fullContent.Length > MAX_CHUNK_SIZE
                ? fullContent.Substring(0, MAX_CHUNK_SIZE) + "\n\n[... contenido truncado ...]"
                : fullContent;
        }
    }

    private async Task<string> SummarizeSingleChunkAsync(string content, string questionContext)
    {
        await _rateLimiter.WaitIfNeededAsync();

        var prompt = $@"Resume el siguiente contenido manteniendo TODA la información relevante para responder preguntas educativas.

CONTEXTO DE PREGUNTA: {questionContext}

INSTRUCCIONES:
- Mantén todos los conceptos clave, definiciones, fechas, nombres y datos importantes
- Preserva la estructura lógica del contenido
- NO omitas información que pueda ser relevante para validar preguntas
- El resumen debe ser completo pero conciso (máximo 5000 caracteres)

CONTENIDO:
{content}

RESUMEN:";

        var url = $"https://generativelanguage.googleapis.com/v1/models/{_model}:generateContent?key={_apiKey}";

        var requestBody = new
        {
            contents = new[]
            {
                new
                {
                    parts = new[]
                    {
                        new { text = prompt }
                    }
                }
            },
            generationConfig = new
            {
                temperature = 0.3,
                maxOutputTokens = 2048,
                topP = 0.8,
                topK = 40
            }
        };

        var json = JsonSerializer.Serialize(requestBody);
        var httpContent = new StringContent(json, Encoding.UTF8, "application/json");

        var response = await _httpClient.PostAsync(url, httpContent);
        var responseContent = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogError("❌ Error en resumen: {Status} - {Response}",
                response.StatusCode, responseContent);
            return content.Length > 5000
                ? content.Substring(0, 5000) + "\n[truncado]"
                : content;
        }

        var jsonDoc = JsonDocument.Parse(responseContent);
        var summary = ExtractTextFromGeminiResponse(jsonDoc.RootElement);

        return string.IsNullOrWhiteSpace(summary) ? content : summary;
    }

    private List<string> SplitIntoManagedChunks(string content, int maxSize)
    {
        var chunks = new List<string>();

        // Intentar dividir por párrafos primero
        var paragraphs = content.Split(
            new[] { "\n\n", "\r\n\r\n" },
            StringSplitOptions.RemoveEmptyEntries);

        var currentChunk = new StringBuilder();

        foreach (var paragraph in paragraphs)
        {
            if (currentChunk.Length + paragraph.Length + 2 > maxSize)
            {
                if (currentChunk.Length > 0)
                {
                    chunks.Add(currentChunk.ToString());
                    currentChunk.Clear();
                }

                // Si un párrafo solo es muy grande, dividirlo
                if (paragraph.Length > maxSize)
                {
                    for (int i = 0; i < paragraph.Length; i += maxSize)
                    {
                        var length = Math.Min(maxSize, paragraph.Length - i);
                        chunks.Add(paragraph.Substring(i, length));
                    }
                    continue;
                }
            }

            if (currentChunk.Length > 0)
                currentChunk.Append("\n\n");

            currentChunk.Append(paragraph);
        }

        if (currentChunk.Length > 0)
        {
            chunks.Add(currentChunk.ToString());
        }

        return chunks.Any() ? chunks : new List<string> { content };
    }

    private string ExtractTextFromGeminiResponse(JsonElement root)
    {
        if (root.TryGetProperty("candidates", out var candidates) &&
            candidates.ValueKind == JsonValueKind.Array &&
            candidates.GetArrayLength() > 0)
        {
            var first = candidates[0];
            if (first.TryGetProperty("content", out var content) &&
                content.TryGetProperty("parts", out var parts) &&
                parts.ValueKind == JsonValueKind.Array &&
                parts.GetArrayLength() > 0)
            {
                var part = parts[0];
                if (part.TryGetProperty("text", out var text))
                {
                    return text.GetString() ?? string.Empty;
                }
            }
        }

        return string.Empty;
    }
}