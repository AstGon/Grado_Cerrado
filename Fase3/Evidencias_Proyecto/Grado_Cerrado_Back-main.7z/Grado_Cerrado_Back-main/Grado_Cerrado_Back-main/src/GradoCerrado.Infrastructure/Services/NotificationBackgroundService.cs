﻿using GradoCerrado.Application.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore; // ✅ AGREGAR ESTA LÍNEA
using GradoCerrado.Application.Interfaces; // ✅ AGREGAR ESTA LÍNEA
using GradoCerrado.Domain.Models; // ✅ AGREGAR ESTA LÍNEA

namespace GradoCerrado.Infrastructure.Services;

/// <summary>
/// Servicio en background que ejecuta tareas programadas de notificaciones
/// </summary>
public class NotificationBackgroundService : BackgroundService
{
    private readonly ILogger<NotificationBackgroundService> _logger;
    private readonly IServiceProvider _serviceProvider;
    private Timer? _timer;

    public NotificationBackgroundService(
        ILogger<NotificationBackgroundService> logger,
        IServiceProvider serviceProvider)
    {
        _logger = logger;
        _serviceProvider = serviceProvider;
    }

    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("🔔 Servicio de Notificaciones iniciado");

        // Ejecutar cada hora
        _timer = new Timer(
            callback: async _ => await DoWorkAsync(),
            state: null,
            dueTime: TimeSpan.Zero, // Ejecutar inmediatamente al iniciar
            period: TimeSpan.FromHours(1)); // Luego cada hora

        return Task.CompletedTask;
    }

    private async Task DoWorkAsync()
    {
        try
        {
            var horaActual = DateTime.Now.Hour;

            _logger.LogDebug("⏰ Verificando si es hora de generar notificaciones (hora actual: {Hora})", horaActual);

            // Solo generar notificaciones a las 6 AM
            if (horaActual == 9)
            {
                _logger.LogInformation("🔔 Iniciando generación de notificaciones del día");

                using var scope = _serviceProvider.CreateScope();
                var notificationService = scope.ServiceProvider
                    .GetRequiredService<INotificacionService>();

                await notificationService.GenerarNotificacionesDelDiaAsync();

                _logger.LogInformation("✅ Notificaciones generadas exitosamente");
            }

            // Enviar notificaciones pendientes cada hora
            await EnviarNotificacionesPendientesAsync();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error en tarea programada de notificaciones");
        }
    }



    // 🔧 REEMPLAZAR ESTE MÉTODO COMPLETO en NotificationBackgroundService.cs
    private async Task EnviarNotificacionesPendientesAsync()
    {
        try
        {
            using var scope = _serviceProvider.CreateScope();

            var pushService = scope.ServiceProvider
                .GetRequiredService<IPushNotificationService>();

            var context = scope.ServiceProvider
                .GetRequiredService<GradocerradoContext>();

            // 🔧 USAR SQL DIRECTO para evitar problemas de tipo DateTime
            var connection = context.Database.GetDbConnection();
            if (connection.State != System.Data.ConnectionState.Open)
                await connection.OpenAsync();

            var notificacionesPendientes = new List<Notificacion>();

            // 1️⃣ LEER NOTIFICACIONES PENDIENTES CON SQL DIRECTO
            using (var command = connection.CreateCommand())
            {
                command.CommandText = @"
                SELECT 
                    id, estudiante_id, tipo_notificacion_id, 
                    titulo, mensaje, datos_adicionales,
                    fecha_programada, enviado, fecha_enviado,
                    leido, fecha_leido, accion_tomada, 
                    fecha_accion, fecha_creacion
                FROM notificaciones
                WHERE enviado = false 
                  AND fecha_programada <= CURRENT_TIMESTAMP
                ORDER BY fecha_programada
                LIMIT 50";

                using var reader = await command.ExecuteReaderAsync();

                while (await reader.ReadAsync())
                {
                    notificacionesPendientes.Add(new Notificacion
                    {
                        Id = reader.GetInt32(0),
                        EstudianteId = reader.GetInt32(1),
                        TiposNotificacionId = reader.GetInt32(2),
                        Titulo = reader.GetString(3),
                        Mensaje = reader.GetString(4),
                        DatosAdicionales = reader.IsDBNull(5) ? null : reader.GetString(5),
                        FechaProgramada = reader.GetDateTime(6),
                        Enviado = reader.IsDBNull(7) ? (bool?)null : reader.GetBoolean(7),
                        FechaEnviado = reader.IsDBNull(8) ? null : reader.GetDateTime(8),
                        Leido = reader.IsDBNull(9) ? (bool?)null : reader.GetBoolean(9),
                        FechaLeido = reader.IsDBNull(10) ? null : reader.GetDateTime(10),
                        AccionTomada = reader.IsDBNull(11) ? (bool?)null : reader.GetBoolean(11),
                        FechaAccion = reader.IsDBNull(12) ? null : reader.GetDateTime(12),
                        FechaCreacion = reader.IsDBNull(13) ? null : reader.GetDateTime(13)
                    });
                }
            }

            if (!notificacionesPendientes.Any())
            {
                _logger.LogDebug("No hay notificaciones pendientes por enviar");
                return;
            }

            _logger.LogInformation(
                "📤 Enviando {Count} notificaciones pendientes",
                notificacionesPendientes.Count);

            // 2️⃣ PROCESAR CADA NOTIFICACIÓN
            foreach (var notificacion in notificacionesPendientes)
            {
                try
                {
                    // Obtener token del estudiante
                    var config = await context.EstudianteNotificacionConfigs
                        .FirstOrDefaultAsync(c =>
                            c.EstudianteId == notificacion.EstudianteId &&
                            c.NotificacionesHabilitadas == true);

                    if (config == null || string.IsNullOrWhiteSpace(config.TokenDispositivo))
                    {
                        _logger.LogDebug(
                            "Estudiante {Id} no tiene token registrado",
                            notificacion.EstudianteId);
                        continue;
                    }

                    // Enviar notificación push
                    var enviada = await pushService.SendPushNotificationAsync(
                        deviceToken: config.TokenDispositivo,
                        title: notificacion.Titulo,
                        body: notificacion.Mensaje,
                        data: new Dictionary<string, string>
                        {
                            ["notificacion_id"] = notificacion.Id.ToString(),
                            ["tipo"] = notificacion.TiposNotificacionId.ToString()
                        });

                    if (enviada)
                    {
                        // 3️⃣ ACTUALIZAR CON SQL DIRECTO
                        using var updateCommand = connection.CreateCommand();
                        updateCommand.CommandText = @"
                        UPDATE notificaciones 
                        SET enviado = true, 
                            fecha_enviado = CURRENT_TIMESTAMP
                        WHERE id = $1";

                        updateCommand.Parameters.Add(
                            new Npgsql.NpgsqlParameter { Value = notificacion.Id });

                        await updateCommand.ExecuteNonQueryAsync();

                        _logger.LogInformation(
                            "✅ Notificación {Id} enviada a estudiante {EstudianteId}",
                            notificacion.Id, notificacion.EstudianteId);
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex,
                        "Error enviando notificación {Id}",
                        notificacion.Id);
                }
            }

            _logger.LogInformation("✅ Proceso de envío completado");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error en envío de notificaciones pendientes");
        }
    }



    public override void Dispose()
    {
        _timer?.Dispose();
        base.Dispose();
    }
}
