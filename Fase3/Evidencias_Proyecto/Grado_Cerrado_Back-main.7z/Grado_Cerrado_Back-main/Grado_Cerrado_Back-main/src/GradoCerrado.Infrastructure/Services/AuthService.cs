﻿using GradoCerrado.Application.DTOs.Auth;
using GradoCerrado.Application.Interfaces;
using GradoCerrado.Domain.Models;
using GradoCerrado.Infrastructure.Configuration;
using Microsoft.CognitiveServices.Speech;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace GradoCerrado.Infrastructure.Services
{
    public class AuthService: IAuthService
    {
        private readonly GradocerradoContext _context;
        private readonly ILogger<AuthService> _logger;

        public AuthService(
            ILogger<AuthService> logger,
            GradocerradoContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<ConnectionTestResult> TestConnectionAsync()
        {
            try
            {
                var count = await _context.Estudiantes.CountAsync();
                var dbName = _context.Database.GetDbConnection().Database;

                _logger.LogInformation("Conexión a base de datos exitosa. DB: {DbName}, Estudiantes: {Count}",
                    dbName, count);

                return new ConnectionTestResult
                {
                    Success = true,
                    Database = dbName,
                    EstudiantesCount = count,
                    Message = "Conexión exitosa"
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error al probar la conexión a la base de datos");

                return new ConnectionTestResult
                {
                    Success = false,
                    Error = ex.Message
                };
            }
        }
        public async Task<ConnectionInfoResult> GetConnectionInfoAsync()
        {
            try
            {
                var connection = _context.Database.GetDbConnection();
                var connectionString = connection.ConnectionString;

                // Parsear la cadena para extraer los componentes
                var parts = ParseConnectionString(connectionString);

                _logger.LogInformation("Información de conexión obtenida para DB: {Database}",
                    parts.GetValueOrDefault("Database", "N/A"));

                return new ConnectionInfoResult
                {
                    Success = true,
                    Host = parts.GetValueOrDefault("Host", "N/A"),
                    Port = parts.GetValueOrDefault("Port", "N/A"),
                    Database = parts.GetValueOrDefault("Database", "N/A"),
                    Username = parts.GetValueOrDefault("Username", "N/A"),
                    HasPassword = parts.ContainsKey("Password")
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error obteniendo información de conexión");

                return new ConnectionInfoResult
                {
                    Success = false,
                    Error = ex.Message
                };
            }
        }

        // Métodos auxiliares para hash de contraseñas
        private string HashPassword(string password)
        {
            using var sha256 = SHA256.Create();
            var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
            return Convert.ToBase64String(hashedBytes);
        }

        private bool VerifyPassword(string password, string hash)
        {
            var hashedPassword = HashPassword(password);
            return hashedPassword == hash;
        }

        public async Task<LoginResult> LoginAsync(AuthLoginRequest request)
        {
            try
            {
                // Validar datos
                if (string.IsNullOrWhiteSpace(request.Email) || string.IsNullOrWhiteSpace(request.Password))
                {
                    return new LoginResult
                    {
                        Success = false,
                        Message = "Email y contraseña son obligatorios"
                    };
                }

                // Buscar usuario
                var estudiante = await _context.Estudiantes
                    .FirstOrDefaultAsync(e => e.Email.ToLower() == request.Email.ToLower() && e.Activo == true);

                if (estudiante == null)
                {
                    _logger.LogWarning("Intento de login fallido - Usuario no encontrado: {Email}", request.Email);
                    return new LoginResult
                    {
                        Success = false,
                        Message = "Credenciales incorrectas"
                    };
                }

                // Verificar contraseña
                if (!VerifyPassword(request.Password, estudiante.PasswordHash))
                {
                    _logger.LogWarning("Intento de login fallido - Contraseña incorrecta: {Email}", request.Email);
                    return new LoginResult
                    {
                        Success = false,
                        Message = "Credenciales incorrectas"
                    };
                }

                // Actualizar último acceso
                estudiante.UltimoAcceso = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
                await _context.SaveChangesAsync();

                _logger.LogInformation("✅ Login exitoso: {Email}", request.Email);

                return new LoginResult
                {
                    Success = true,
                    Message = "Login exitoso",
                    User = new LoggedUserDto
                    {
                        Id = estudiante.Id,
                        Name = estudiante.Nombre,
                        Email = estudiante.Email,
                        FechaRegistro = estudiante.FechaRegistro
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error en login: {Email}", request.Email);

                return new LoginResult
                {
                    Success = false,
                    Message = "Error interno del servidor"
                };
            }
        }





        public async Task<CompleteDiagnosticResult> CompleteDiagnosticTestAsync(CompleteDiagnosticRequest request)
        {
            try
            {
                // Buscar el estudiante
                var estudiante = await _context.Estudiantes
                    .FirstOrDefaultAsync(e => e.Id == request.EstudianteId && e.Activo == true);

                if (estudiante == null)
                {
                    return new CompleteDiagnosticResult
                    {
                        Success = false,
                        Message = "Estudiante no encontrado"
                    };
                }

                // Verificar que no haya completado ya el test
                if (estudiante.TestDiagnosticoCompletado == true)
                {
                    return new CompleteDiagnosticResult
                    {
                        Success = false,
                        Message = "Test diagnóstico ya completado"
                    };
                }

                // Actualizar los campos del test diagnóstico
                var currentTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
                estudiante.TestDiagnosticoCompletado = true;
                estudiante.FechaTestDiagnostico = currentTime;
                estudiante.UltimoAcceso = currentTime;

                await _context.SaveChangesAsync();

                _logger.LogInformation("✅ Test diagnóstico completado para estudiante: {EstudianteId}", request.EstudianteId);

                return new CompleteDiagnosticResult
                {
                    Success = true,
                    Message = "Test diagnóstico completado exitosamente",
                    Data = new DiagnosticDataDto
                    {
                        EstudianteId = estudiante.Id,
                        FechaCompletado = estudiante.FechaTestDiagnostico,
                        TestCompletado = estudiante.TestDiagnosticoCompletado
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error completando test diagnóstico para estudiante: {EstudianteId}", request.EstudianteId);

                return new CompleteDiagnosticResult
                {
                    Success = false,
                    Message = "Error interno del servidor"
                };
            }
        }

        public async Task<DiagnosticStatusResult> GetDiagnosticStatusAsync(int estudianteId)
        {
            try
            {
                var estudiante = await _context.Estudiantes
                    .Where(e => e.Id == estudianteId && e.Activo == true)
                    .Select(e => new
                    {
                        e.Id,
                        e.TestDiagnosticoCompletado,
                        e.FechaTestDiagnostico
                    })
                    .FirstOrDefaultAsync();

                if (estudiante == null)
                {
                    return new DiagnosticStatusResult
                    {
                        Success = false,
                        Message = "Estudiante no encontrado"
                    };
                }

                return new DiagnosticStatusResult
                {
                    Success = true,
                    Message = "Estado del diagnóstico obtenido exitosamente",
                    Data = new DiagnosticStatusDataDto
                    {
                        EstudianteId = estudiante.Id,
                        TestCompletado = estudiante.TestDiagnosticoCompletado ?? false,
                        FechaCompletado = estudiante.FechaTestDiagnostico,
                        RequiereTest = estudiante.TestDiagnosticoCompletado != true
                    }
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error obteniendo estado diagnóstico: {EstudianteId}", estudianteId);

                return new DiagnosticStatusResult
                {
                    Success = false,
                    Message = "Error interno del servidor"
                };
            }
        }

        public async Task<RegisterResult> RegisterAsync(AuthRegisterRequest request)
        {
            try
            {
                // Validar datos básicos
                var validationResult = ValidateRegisterRequest(request);
                if (!validationResult.IsValid)
                {
                    return new RegisterResult
                    {
                        Success = false,
                        Message = validationResult.ErrorMessage
                    };
                }

                // Verificar si el email ya existe
                var emailExists = await _context.Estudiantes
                    .AnyAsync(e => e.Email.ToLower() == request.Email.ToLower());

                if (emailExists)
                {
                    return new RegisterResult
                    {
                        Success = false,
                        Message = "El email ya está registrado"
                    };
                }

                var currentTime = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);

                // Crear nuevo estudiante
                var estudiante = new Estudiante
                {
                    Nombre = request.Nombre.Trim(),
                    SegundoNombre = request.SegundoNombre?.Trim(),
                    ApellidoPaterno = request.ApellidoPaterno?.Trim(),
                    ApellidoMaterno = request.ApellidoMaterno?.Trim(),
                    NombreCompleto = request.NombreCompleto?.Trim() ?? ConstructNombreCompleto(
                        request.Nombre?.Trim(),
                        request.SegundoNombre?.Trim(),
                        request.ApellidoPaterno?.Trim(),
                        request.ApellidoMaterno?.Trim()
                    ),
                    Email = request.Email.ToLower().Trim(),
                    PasswordHash = HashPassword(request.Password),
                    FechaRegistro = currentTime,
                    UltimoAcceso = currentTime,
                    Activo = true,
                    Verificado = false
                };

                // Guardar en base de datos
                _context.Estudiantes.Add(estudiante);
                await _context.SaveChangesAsync();

                _logger.LogInformation("✅ Usuario registrado exitosamente: {Email}", request.Email);

                // Crear configuración inicial de notificaciones
                var notifConfig = new EstudianteNotificacionConfig
                {
                    EstudianteId = estudiante.Id,
                    NotificacionesHabilitadas = true,
                    TokenDispositivo = null, // Se registrará después desde la app
                    FechaInicio = currentTime,
                    FechaActualizacion = currentTime,
                    FechaFin = null
                };

                _context.EstudianteNotificacionConfigs.Add(notifConfig);
                await _context.SaveChangesAsync();

                _logger.LogInformation("✅ Configuración de notificaciones creada para estudiante {Id}", estudiante.Id);

                return new RegisterResult
                {
                    Success = true,
                    Message = "Usuario registrado exitosamente",
                    User = new RegisteredUserDto
                    {
                        Id = estudiante.Id,
                        Name = estudiante.Nombre,
                        Email = estudiante.Email,
                        FechaRegistro = estudiante.FechaRegistro
                    }
                };
            }
            catch (DbUpdateException dbEx)
            {
                _logger.LogError(dbEx, "❌ Error de base de datos al registrar usuario: {Email}", request.Email);

                return new RegisterResult
                {
                    Success = false,
                    Message = "Error en la base de datos"
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error registrando usuario: {Email}", request.Email);

                return new RegisterResult
                {
                    Success = false,
                    Message = "Error interno del servidor"
                };
            }
        }

        // Métodos auxiliares privados

        private (bool IsValid, string ErrorMessage) ValidateRegisterRequest(AuthRegisterRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.Nombre) || string.IsNullOrWhiteSpace(request.Email))
            {
                return (false, "Nombre y email son obligatorios");
            }

            if (string.IsNullOrWhiteSpace(request.Password) || request.Password.Length < 6)
            {
                return (false, "La contraseña debe tener al menos 6 caracteres");
            }

            return (true, string.Empty);
        }



        // Métodos auxiliares privados

        private Dictionary<string, string> ParseConnectionString(string? connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString))
                return new Dictionary<string, string>();

            return connectionString
                .Split(';')
                .Where(part => !string.IsNullOrEmpty(part))
                .Select(part => part.Split('='))
                .Where(split => split.Length == 2)
                .ToDictionary(split => split[0].Trim(), split => split[1].Trim());
        }
        public async Task<UpdateProfileResult> UpdateProfileAsync(int studentId, UpdateProfileRequest request)
        {
            try
            {
                var estudiante = await _context.Estudiantes.FindAsync(studentId);
                if (estudiante == null)
                {
                    return new UpdateProfileResult
                    {
                        Success = false,
                        Message = "Usuario no encontrado"
                    };
                }

                // Solo actualizar campos que vienen en el request (PATCH behavior)
                bool hasChanges = false;

                // Actualizar nombre si se proporciona
                if (!string.IsNullOrWhiteSpace(request.Nombre))
                {
                    estudiante.Nombre = request.Nombre.Trim();
                    hasChanges = true;
                }

                if (request.SegundoNombre != null) // Permite string vacío para borrar
                {
                    estudiante.SegundoNombre = string.IsNullOrWhiteSpace(request.SegundoNombre)
                        ? null
                        : request.SegundoNombre.Trim();
                    hasChanges = true;
                }

                if (request.ApellidoPaterno != null)
                {
                    estudiante.ApellidoPaterno = string.IsNullOrWhiteSpace(request.ApellidoPaterno)
                        ? null
                        : request.ApellidoPaterno.Trim();
                    hasChanges = true;
                }

                if (request.ApellidoMaterno != null)
                {
                    estudiante.ApellidoMaterno = string.IsNullOrWhiteSpace(request.ApellidoMaterno)
                        ? null
                        : request.ApellidoMaterno.Trim();
                    hasChanges = true;
                }

                // Si se actualizó algún nombre, reconstruir nombre completo
                if (hasChanges)
                {
                    estudiante.NombreCompleto = ConstructNombreCompleto(
                        estudiante.Nombre,
                        estudiante.SegundoNombre,
                        estudiante.ApellidoPaterno,
                        estudiante.ApellidoMaterno
                    );
                    estudiante.FechaModificacion = DateTime.UtcNow;
                }

                // Actualizar email (con validación)
                if (!string.IsNullOrWhiteSpace(request.Email) && request.Email != estudiante.Email)
                {
                    // Verificar que el email no esté en uso
                    var emailExists = await _context.Estudiantes
                        .AnyAsync(e => e.Email.ToLower() == request.Email.ToLower() && e.Id != studentId);

                    if (emailExists)
                    {
                        return new UpdateProfileResult
                        {
                            Success = false,
                            Message = "El email ya está en uso"
                        };
                    }

                    estudiante.Email = request.Email.ToLower().Trim();
                    estudiante.Verificado = false; // Requiere re-verificación
                    hasChanges = true;

                    // TODO: Enviar email de verificación
                }

                if (!hasChanges)
                {
                    return new UpdateProfileResult
                    {
                        Success = true,
                        Message = "No hay cambios para guardar",
                        User = MapToUserProfileDto(estudiante)
                    };
                }

                await _context.SaveChangesAsync();

                _logger.LogInformation("✅ Perfil actualizado para estudiante {Id}", studentId);

                // Devolver el usuario actualizado
                return new UpdateProfileResult
                {
                    Success = true,
                    Message = "Perfil actualizado exitosamente",
                    User = MapToUserProfileDto(estudiante)
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Error actualizando perfil para estudiante {Id}", studentId);

                return new UpdateProfileResult
                {
                    Success = false,
                    Message = "Error interno del servidor"
                };
            }
        }

        // Métodos auxiliares privados
        private string ConstructNombreCompleto(params string?[] partes)
        {
            return string.Join(" ", partes.Where(p => !string.IsNullOrWhiteSpace(p)));
        }

        private UserProfileDto MapToUserProfileDto(Estudiante estudiante)
        {
            return new UserProfileDto
            {
                Id = estudiante.Id,
                Nombre = estudiante.Nombre,
                SegundoNombre = estudiante.SegundoNombre,
                ApellidoPaterno = estudiante.ApellidoPaterno,
                ApellidoMaterno = estudiante.ApellidoMaterno,
                NombreCompleto = estudiante.NombreCompleto,
                Email = estudiante.Email,
                Verificado = estudiante.Verificado,
                LastProfileUpdate = estudiante.FechaModificacion
            };
        }
    }
}

