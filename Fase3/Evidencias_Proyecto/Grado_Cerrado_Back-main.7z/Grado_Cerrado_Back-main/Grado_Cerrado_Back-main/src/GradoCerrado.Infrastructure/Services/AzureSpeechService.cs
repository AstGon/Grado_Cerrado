﻿using Microsoft.CognitiveServices.Speech;
using Microsoft.CognitiveServices.Speech.Audio;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using GradoCerrado.Application.Interfaces;
using GradoCerrado.Infrastructure.Configuration;
using NAudio.Wave;

namespace GradoCerrado.Infrastructure.Services;

public class AzureSpeechService : ISpeechService
{
    private readonly SpeechConfig _speechConfig;
    private readonly AzureSpeechSettings _settings;
    private readonly ILogger<AzureSpeechService> _logger;

    public AzureSpeechService(
        IOptions<AzureSpeechSettings> settings,
        ILogger<AzureSpeechService> logger)
    {
        _settings = settings.Value;
        _logger = logger;

        // 🔧 Configurar Azure Speech
        _speechConfig = SpeechConfig.FromSubscription(_settings.ApiKey, _settings.Region);
        _speechConfig.SpeechSynthesisVoiceName = _settings.DefaultVoice;

        // 🎯 Configurar formato de audio
        _speechConfig.SetSpeechSynthesisOutputFormat(SpeechSynthesisOutputFormat.Audio16Khz32KBitRateMonoMp3);
    }

    // TEXT-TO-SPEECH
    public async Task<byte[]> TextToSpeechAsync(string text, string? voice = null)
    {
        try
        {
            _logger.LogInformation("Generando audio para texto: {Text}", text[..Math.Min(50, text.Length)]);

            using var synthesizer = new SpeechSynthesizer(_speechConfig);

            // Usar voz específica si se proporciona
            if (!string.IsNullOrEmpty(voice))
            {
                _speechConfig.SpeechSynthesisVoiceName = voice;
            }

            // Sintetizar audio
            using var result = await synthesizer.SpeakTextAsync(text);

            if (result.Reason == ResultReason.SynthesizingAudioCompleted)
            {
                _logger.LogInformation("Audio generado exitosamente. Tamaño: {Size} bytes", result.AudioData.Length);
                return result.AudioData;
            }
            else
            {
                var errorMessage = $"Error en síntesis: {result.Reason}";
                _logger.LogError(errorMessage);
                throw new Exception(errorMessage);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando audio para texto");
            throw;
        }
    }

    // SSML para pronunciación avanzada
    public async Task<byte[]> SsmlToSpeechAsync(string ssml)
    {
        try
        {
            _logger.LogInformation("Generando audio desde SSML");

            using var synthesizer = new SpeechSynthesizer(_speechConfig);
            using var result = await synthesizer.SpeakSsmlAsync(ssml);

            if (result.Reason == ResultReason.SynthesizingAudioCompleted)
            {
                _logger.LogInformation("Audio SSML generado exitosamente");
                return result.AudioData;
            }
            else
            {
                throw new Exception($"Error en síntesis SSML: {result.Reason}");
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando audio desde SSML");
            throw;
        }
    }

    // SPEECH-TO-TEXT
    public async Task<string> SpeechToTextAsync(byte[] audioData)
    {
        try
        {
            _logger.LogInformation("Transcribiendo audio. Tamaño: {Size} bytes", audioData.Length);

            // Configurar idioma
            _speechConfig.SpeechRecognitionLanguage = "es-ES";

            // 🆕 DETECTAR FORMATO Y CONVERTIR SI ES NECESARIO
            var wavData = await ConvertToWavIfNeededAsync(audioData);

            // Validar que es un WAV válido
            if (wavData.Length < 44 ||
                System.Text.Encoding.ASCII.GetString(wavData, 0, 4) != "RIFF")
            {
                throw new Exception("El archivo no pudo ser convertido a WAV válido");
            }

            var tempFile = Path.GetTempFileName() + ".wav";

            try
            {
                await File.WriteAllBytesAsync(tempFile, wavData);

                using var audioConfig = AudioConfig.FromWavFileInput(tempFile);
                using var recognizer = new SpeechRecognizer(_speechConfig, audioConfig);

                recognizer.Properties.SetProperty(PropertyId.SpeechServiceConnection_InitialSilenceTimeoutMs, "10000");
                recognizer.Properties.SetProperty(PropertyId.SpeechServiceConnection_EndSilenceTimeoutMs, "10000");

                var result = await recognizer.RecognizeOnceAsync();

                _logger.LogInformation("Resultado del reconocimiento: {Reason}", result.Reason);

                switch (result.Reason)
                {
                    case ResultReason.RecognizedSpeech:
                        _logger.LogInformation("✅ Texto reconocido: {Text}", result.Text);
                        return result.Text;

                    case ResultReason.NoMatch:
                        _logger.LogWarning("⚠️ No se reconoció ningún discurso");
                        var noMatchDetails = NoMatchDetails.FromResult(result);
                        _logger.LogWarning("Razón de NoMatch: {Reason}", noMatchDetails.Reason);
                        return string.Empty;

                    case ResultReason.Canceled:
                        var cancellationDetails = CancellationDetails.FromResult(result);
                        _logger.LogError("❌ Reconocimiento cancelado: {Reason}", cancellationDetails.Reason);
                        if (cancellationDetails.Reason == CancellationReason.Error)
                        {
                            _logger.LogError("Código de error: {ErrorCode}", cancellationDetails.ErrorCode);
                            _logger.LogError("Detalles del error: {ErrorDetails}", cancellationDetails.ErrorDetails);
                        }
                        throw new Exception($"Reconocimiento cancelado: {cancellationDetails.Reason}");

                    default:
                        throw new Exception($"Razón inesperada: {result.Reason}");
                }
            }
            finally
            {
                if (File.Exists(tempFile))
                {
                    File.Delete(tempFile);
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error en reconocimiento de voz");
            throw;
        }
    }

    // ═══════════════════════════════════════════════════════════
    // 🆕 CONVERSIÓN DE AUDIO A WAV (MULTIPLATAFORMA)
    // ═══════════════════════════════════════════════════════════
    private async Task<byte[]> ConvertToWavIfNeededAsync(byte[] audioData)
    {
        try
        {
            _logger.LogInformation("🔍 Verificando formato de audio. Tamaño: {Size} bytes", audioData.Length);

            // ✅ VERIFICAR SI YA ES WAV (RIFF header)
            if (audioData.Length >= 12 &&
                audioData[0] == 0x52 && // R
                audioData[1] == 0x49 && // I
                audioData[2] == 0x46 && // F
                audioData[3] == 0x46)   // F
            {
                _logger.LogInformation("✅ Audio ya está en formato WAV válido");
                return audioData;
            }

            _logger.LogInformation("⚠️ Audio no es WAV, intentando conversión...");

            // ✅ SOLO INTENTAR CONVERSIÓN EN WINDOWS
            if (System.Runtime.InteropServices.RuntimeInformation.IsOSPlatform(
                System.Runtime.InteropServices.OSPlatform.Windows))
            {
                _logger.LogInformation("🪟 Sistema Windows detectado, usando NAudio para conversión");

                var tempInput = Path.GetTempFileName();
                var tempOutput = Path.GetTempFileName() + ".wav";

                try
                {
                    await File.WriteAllBytesAsync(tempInput, audioData);

                    using (var reader = new MediaFoundationReader(tempInput))
                    {
                        WaveFileWriter.CreateWaveFile(tempOutput, reader);
                    }

                    var wavData = await File.ReadAllBytesAsync(tempOutput);
                    _logger.LogInformation("✅ Audio convertido exitosamente. Tamaño: {Size} bytes", wavData.Length);

                    return wavData;
                }
                finally
                {
                    if (File.Exists(tempInput)) File.Delete(tempInput);
                    if (File.Exists(tempOutput)) File.Delete(tempOutput);
                }
            }
            else
            {
                // ✅ EN MAC/LINUX: ASUMIR QUE EL FRONTEND YA ENVIÓ WAV
                _logger.LogWarning("⚠️ Sistema no Windows detectado (Mac/Linux)");
                _logger.LogWarning("⚠️ Se asume que el audio viene en formato correcto desde el frontend");
                return audioData;
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error en conversión de audio");

            // ✅ SI FALLA, DEVOLVER EL AUDIO ORIGINAL
            // Azure Speech intentará procesarlo de todas formas
            _logger.LogWarning("⚠️ Devolviendo audio original sin conversión");
            return audioData;
        }
    }

    // ═══════════════════════════════════════════════════════════
    // TEST DE CONEXIÓN
    // ═══════════════════════════════════════════════════════════
    public async Task<bool> TestConnectionAsync()
    {
        try
        {
            _logger.LogInformation("🧪 Probando conexión con Azure Speech Service");

            using var synthesizer = new SpeechSynthesizer(_speechConfig);
            using var result = await synthesizer.SpeakTextAsync("Test");

            if (result.Reason == ResultReason.SynthesizingAudioCompleted)
            {
                _logger.LogInformation("✅ Conexión exitosa con Azure Speech Service");
                return true;
            }
            else
            {
                _logger.LogWarning("⚠️ Conexión fallida: {Reason}", result.Reason);
                return false;
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error probando conexión con Azure Speech Service");
            return false;
        }
    }
}