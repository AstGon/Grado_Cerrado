﻿using Microsoft.Extensions.Logging;

namespace GradoCerrado.Infrastructure.Services;

/// <summary>
/// Rate limiter para espaciar peticiones a Gemini y evitar 429 (Too Many Requests)
/// </summary>
public class GeminiRateLimiter
{
    private readonly ILogger<GeminiRateLimiter> _logger;
    private DateTime _lastRequestTime = DateTime.MinValue;
    private readonly SemaphoreSlim _semaphore = new(1, 1);

    // Configuración: mínimo 2 segundos entre requests
    private readonly TimeSpan _minTimeBetweenRequests = TimeSpan.FromSeconds(2);

    public GeminiRateLimiter(ILogger<GeminiRateLimiter> logger)
    {
        _logger = logger;
    }

    /// <summary>
    /// Espera el tiempo necesario para respetar el rate limit
    /// </summary>
    public async Task WaitIfNeededAsync()
    {
        await _semaphore.WaitAsync();

        try
        {
            var timeSinceLastRequest = DateTime.UtcNow - _lastRequestTime;

            if (timeSinceLastRequest < _minTimeBetweenRequests)
            {
                var delay = _minTimeBetweenRequests - timeSinceLastRequest;
                _logger.LogDebug("⏸️ Rate limiting: esperando {Ms}ms antes de llamar a Gemini",
                    (int)delay.TotalMilliseconds);
                await Task.Delay(delay);
            }

            _lastRequestTime = DateTime.UtcNow;
        }
        finally
        {
            _semaphore.Release();
        }
    }

    /// <summary>
    /// Pausa extendida entre lotes de validaciones
    /// </summary>
    public async Task PauseBetweenBatchesAsync(int batchNumber, int totalBatches)
    {
        if (batchNumber < totalBatches)
        {
            _logger.LogInformation("⏸️ Pausa de 3 segundos entre lotes ({Current}/{Total})...",
                batchNumber + 1, totalBatches);
            await Task.Delay(3000);
        }
    }
}