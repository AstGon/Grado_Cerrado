﻿// src/GradoCerrado.Application/Services/NotificacionService.cs
using GradoCerrado.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace GradoCerrado.Application.Services;

public interface INotificacionService
{
    Task GenerarNotificacionesDelDiaAsync();
    Task<List<Notificacion>> ObtenerNotificacionesPendientesAsync(int estudianteId);
    Task MarcarComoLeidaAsync(int notificacionId);
    Task MarcarAccionTomadaAsync(int notificacionId);
}

public class NotificacionService : INotificacionService
{
    private readonly GradocerradoContext _context;
    private readonly ILogger<NotificacionService> _logger;

    public NotificacionService(
        GradocerradoContext context,
        ILogger<NotificacionService> logger)
    {
        _context = context;
        _logger = logger;
    }

    /// <summary>
    /// Genera notificaciones de recordatorio para todos los estudiantes según su configuración
    /// Este método debe ejecutarse diariamente (ej: con un job scheduler)
    /// </summary>
    public async Task GenerarNotificacionesDelDiaAsync()
    {
        try
        {
            var hoy = DateTime.Now;
            var diaSemana = ObtenerDiaSemanaEspanol(hoy.DayOfWeek);

            _logger.LogInformation(
                "🔔 Generando notificaciones para {Fecha} ({Dia})",
                hoy.ToString("yyyy-MM-dd"), diaSemana);

            var estudiantes = await _context.Estudiantes
                .Where(e => e.Activo == true)
                .ToListAsync();

            var notificacionesCreadas = 0;

            foreach (var estudiante in estudiantes)
            {
                // Obtener config de notificaciones
                var config = await _context.EstudianteNotificacionConfigs
                    .FirstOrDefaultAsync(c => c.EstudianteId == estudiante.Id);

                if (config == null || !config.NotificacionesHabilitadas) continue;

                // 1️⃣ RECORDATORIO DE ESTUDIO (ID: 1)
                if (estudiante.RecordatorioEstudioActivo == true &&
                    DebeRecibirNotificacionHoy(estudiante, diaSemana))
                {
                    await CrearNotificacion(estudiante.Id, 1,
                        "⏰ Recordatorio de estudio",
                        GenerarMensajeRecordatorio(estudiante));
                    notificacionesCreadas++;
                }

                // 2️⃣ RACHA (ID: 2) - REEMPLAZAR ESTAS LÍNEAS (alrededor de línea 70-76):
                // Obtener métricas del estudiante
                var metricas = await _context.MetricasEstudiantes
                    .FirstOrDefaultAsync(m => m.EstudianteId == estudiante.Id);

                if (metricas?.RachaDiasActual > 0)
                {
                    await CrearNotificacion(estudiante.Id, 2,
                        $"🔥 Racha de {metricas.RachaDiasActual} días",
                        $"¡Mantén tu racha, {estudiante.Nombre}! Estudia hoy");
                    notificacionesCreadas++;
                }

                // 3️⃣ LOGROS (ID: 3)
                var tieneLogrosNuevos = await TieneLogrosNuevos(estudiante.Id);
                if (tieneLogrosNuevos)
                {
                    await CrearNotificacion(estudiante.Id, 3,
                        "🏆 ¡Nuevo logro desbloqueado!",
                        "Has alcanzado un nuevo hito en tu aprendizaje");
                    notificacionesCreadas++;
                }

                // 4️⃣ CONSEJOS (ID: 4) - Miércoles
                if (hoy.DayOfWeek == DayOfWeek.Wednesday)
                {
                    await CrearNotificacion(estudiante.Id, 4,
                        "💡 Consejo de estudio",
                        GenerarConsejoAleatorio());
                    notificacionesCreadas++;
                }

                // 5️⃣ METAS (ID: 5)
                var cercaDeMeta = await EstaCercaDeMeta(estudiante.Id);
                if (cercaDeMeta)
                {
                    await CrearNotificacion(estudiante.Id, 5,
                        "🎯 ¡Casi llegas a tu meta!",
                        "Solo te faltan unos puntos más, ¡sigue así!");
                    notificacionesCreadas++;
                }

                // 6️⃣ MENSAJES MOTIVACIONALES (ID: 6) - Lunes y Viernes
                if (hoy.DayOfWeek == DayOfWeek.Monday || hoy.DayOfWeek == DayOfWeek.Friday)
                {
                    await CrearNotificacion(estudiante.Id, 6,
                        "💪 Mensaje motivacional",
                        GenerarMensajeMotivacional(estudiante.Nombre));
                    notificacionesCreadas++;
                }

                // 7️⃣ REPORTE SEMANAL (ID: 7) - Domingos
                if (hoy.DayOfWeek == DayOfWeek.Sunday)
                {
                    var reporte = await GenerarReporteSemanal(estudiante.Id);
                    await CrearNotificacion(estudiante.Id, 7,
                        "📊 Tu reporte semanal",
                        reporte);
                    notificacionesCreadas++;
                }
            }

            await _context.SaveChangesAsync();
            _logger.LogInformation("✅ {Total} notificaciones creadas", notificacionesCreadas);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error generando notificaciones");
            throw;
        }
    }

    /// <summary>
    /// Obtiene notificaciones pendientes de un estudiante
    /// </summary>
    public async Task<List<Notificacion>> ObtenerNotificacionesPendientesAsync(int estudianteId)
    {
        try
        {
            var ahora = DateTime.Now;

            var notificaciones = await _context.Notificaciones
                .Where(n =>
                    n.EstudianteId == estudianteId &&
                    n.Leido == false &&
                    n.FechaProgramada <= ahora)
                .OrderByDescending(n => n.FechaProgramada)
                .Take(10)
                .ToListAsync();

            return notificaciones;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error obteniendo notificaciones pendientes");
            return new List<Notificacion>();
        }
    }

    /// <summary>
    /// Marca una notificación como leída
    /// </summary>
    public async Task MarcarComoLeidaAsync(int notificacionId)
    {
        try
        {
            var notificacion = await _context.Notificaciones
                .FirstOrDefaultAsync(n => n.Id == notificacionId);

            if (notificacion != null)
            {
                notificacion.Leido = true;
                notificacion.FechaLeido = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
                await _context.SaveChangesAsync();

                _logger.LogInformation("Notificación {Id} marcada como leída", notificacionId);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error marcando notificación como leída");
            throw;
        }
    }

    /// <summary>
    /// Marca que el usuario tomó acción sobre la notificación (ej: inició sesión de estudio)
    /// </summary>
    public async Task MarcarAccionTomadaAsync(int notificacionId)
    {
        try
        {
            var notificacion = await _context.Notificaciones
                .FirstOrDefaultAsync(n => n.Id == notificacionId);

            if (notificacion != null)
            {
                notificacion.AccionTomada = true;
                notificacion.FechaAccion = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
                await _context.SaveChangesAsync();

                _logger.LogInformation("Acción tomada en notificación {Id}", notificacionId);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error marcando acción tomada");
            throw;
        }
    }

    // ═══════════════════════════════════════════════════════════
    // MÉTODOS PRIVADOS
    // ═══════════════════════════════════════════════════════════

    private async Task CrearNotificacion(int estudianteId, int tipoId, string titulo, string mensaje)
    {
        var yaExiste = await _context.Notificaciones
            .AnyAsync(n => n.EstudianteId == estudianteId &&
                          n.TiposNotificacionId == tipoId &&
                          n.FechaProgramada.Date == DateTime.Now.Date);

        if (yaExiste) return;

        var notificacion = new Notificacion
        {
            EstudianteId = estudianteId,
            TiposNotificacionId = tipoId,
            Titulo = titulo,
            Mensaje = mensaje,
            FechaProgramada = DateTime.SpecifyKind(DateTime.Now.AddHours(1), DateTimeKind.Unspecified),
            Enviado = false,
            Leido = false,
            FechaCreacion = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified)
        };

        _context.Notificaciones.Add(notificacion);
    }

    private async Task<bool> TieneLogrosNuevos(int estudianteId)
    {
        // Por ahora retorna false - implementar cuando tengas tabla de logros
        return await Task.FromResult(false);
    }

    private async Task<bool> EstaCercaDeMeta(int estudianteId)
    {
        // Por ahora retorna false - implementar cuando tengas tabla de metas
        return await Task.FromResult(false);
    }

    private string GenerarConsejoAleatorio()
    {
        var consejos = new[]
        {
            "Estudia en bloques de 25 minutos con descansos de 5 (Técnica Pomodoro)",
            "Repasa lo aprendido antes de dormir para mejor retención",
            "Practica con exámenes anteriores para familiarizarte con el formato"
        };
        return consejos[new Random().Next(consejos.Length)];
    }

    private string GenerarMensajeMotivacional(string nombre)
    {
        var mensajes = new[]
        {
            $"¡Tú puedes, {nombre}! Cada pregunta te acerca a tu meta 💪",
            $"{nombre}, el éxito es la suma de pequeños esfuerzos diarios ✨",
            $"¡Sigue así, {nombre}! Tu dedicación dará frutos 🌟"
        };
        return mensajes[new Random().Next(mensajes.Length)];
    }

    private async Task<string> GenerarReporteSemanal(int estudianteId)
    {
        var metricas = await _context.MetricasEstudiantes
            .FirstOrDefaultAsync(m => m.EstudianteId == estudianteId);

        var diasEstudiados = metricas?.TotalDiasEstudiados ?? 0;
        var promedio = metricas?.PromedioAciertos ?? 0;

        return $"Esta semana: {diasEstudiados} días estudiados, {promedio:F1}% de aciertos. ¡Sigue mejorando! 📈";
    }

    private bool DebeRecibirNotificacionHoy(Estudiante estudiante, string diaSemana)
    {
        if (string.IsNullOrEmpty(estudiante.DiasPreferidosEstudio))
        {
            var frecuencia = estudiante.FrecuenciaEstudioSemanal ?? 3;
            var diasDistribuidos = DistribuirDiasPorFrecuencia(frecuencia);
            return diasDistribuidos.Contains(diaSemana);
        }

        try
        {
            var diasPreferidos = JsonSerializer.Deserialize<List<string>>(
                estudiante.DiasPreferidosEstudio);

            return diasPreferidos?.Contains(diaSemana.ToLower()) ?? false;
        }
        catch
        {
            _logger.LogWarning(
                "Error parseando días preferidos para estudiante {Id}",
                estudiante.Id);
            return false;
        }
    }

    private List<string> DistribuirDiasPorFrecuencia(int frecuencia)
    {
        return frecuencia switch
        {
            1 => new List<string> { "miercoles" },
            2 => new List<string> { "martes", "jueves" },
            3 => new List<string> { "lunes", "miercoles", "viernes" },
            4 => new List<string> { "lunes", "martes", "jueves", "viernes" },
            5 => new List<string> { "lunes", "martes", "miercoles", "jueves", "viernes" },
            6 => new List<string> { "lunes", "martes", "miercoles", "jueves", "viernes", "sabado" },
            7 => new List<string> { "lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo" },
            _ => new List<string> { "lunes", "miercoles", "viernes" }
        };
    }

    private string GenerarMensajeRecordatorio(Estudiante estudiante)
    {
        var mensajes = new[]
        {
            $"¡Hola {estudiante.Nombre}! Es hora de tu sesión de estudio de hoy 📚",
            $"{estudiante.Nombre}, ¡no olvides tu práctica de hoy! 💪",
            $"Recordatorio: Tu sesión de estudio te espera, {estudiante.Nombre} 🎯",
            $"¡Es momento de practicar, {estudiante.Nombre}! Mantén tu racha activa 🔥",
            $"Tu aprendizaje diario está listo, {estudiante.Nombre} ✨"
        };

        var random = new Random();
        return mensajes[random.Next(mensajes.Length)];
    }

    private string ObtenerDiaSemanaEspanol(DayOfWeek dayOfWeek)
    {
        return dayOfWeek switch
        {
            DayOfWeek.Monday => "lunes",
            DayOfWeek.Tuesday => "martes",
            DayOfWeek.Wednesday => "miercoles",
            DayOfWeek.Thursday => "jueves",
            DayOfWeek.Friday => "viernes",
            DayOfWeek.Saturday => "sabado",
            DayOfWeek.Sunday => "domingo",
            _ => "lunes"
        };
    }
}