using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using LangChain.Providers.OpenAI;
using GradoCerrado.Application.Interfaces;
using GradoCerrado.Domain.Entities;
using GradoCerrado.Infrastructure.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;

namespace GradoCerrado.Infrastructure.Services;

public class LangChainQuestionService : IAIService
{
    private readonly OpenAiProvider _provider;
    private readonly OpenAISettings _settings;
    private readonly ILogger<LangChainQuestionService> _logger;
    private readonly IRateLimiter _rateLimiter;

    public LangChainQuestionService(
        IOptions<OpenAISettings> settings,
        ILogger<LangChainQuestionService> logger,
        IRateLimiter rateLimiter)
    {
        _settings = settings.Value;
        _logger = logger;
        _rateLimiter = rateLimiter;
        _provider = new OpenAiProvider(_settings.ApiKey);
    }

    // ═══════════════════════════════════════════════════════════════
    // 1️⃣ GenerateStructuredQuestionsAsync
    // ═══════════════════════════════════════════════════════════════

    public async Task<string> GenerateStructuredQuestionsAsync(
        string sourceText,
        string legalArea,
        QuestionType type,
        DifficultyLevel difficulty,
        int count)
    {
        const int MAX_RETRIES = 4;
        int attempt = 0;

        // Recorta fuente para no mandar textos gigantes (reduce latencia y 429)
        var safeSource = string.IsNullOrWhiteSpace(sourceText)
            ? string.Empty
            : (sourceText.Length > 12000 ? sourceText[..12000] : sourceText);

        // Over-ask (+30%) para obtener más material y luego recortar en el parser
        int overAsk = Math.Max(count + (int)Math.Ceiling(count * 0.3), count);

        _logger.LogInformation(
            "🤖 Generando {Count} preguntas {Type} nivel {Difficulty}",
            count, type, difficulty);

        var model = new OpenAiChatModel(_provider, _settings.Model);

        string difficultyInstructions = GetDifficultyInstructions(difficulty);
        string formatExample = GetFormatExample(type, difficulty);

        var prompt = BuildEnhancedQuestionPrompt(
            safeSource, legalArea, type, difficulty,
            difficultyInstructions, overAsk, formatExample);

        while (true)
        {
            try
            {
                await _rateLimiter.WaitIfNeededAsync();

                string responseText = "";
                await foreach (var response in model.GenerateAsync(
                    // Encabezado muy estricto de estilo
                    $"Eres un profesor experto de Derecho chileno que prepara exámenes de grado. " +
                    $"ESTILO: Preguntas DIRECTAS, TÉCNICAS y AUTÓNOMAS (como examen real). " +
                    $"PROHIBIDO: 'según el texto', 'según el documento', 'de acuerdo al fragmento', 'como se dijo'. " +
                    $"Responde SOLO con JSON válido y completo. " +
                    $"RESTRICCIÓN DE TIPOS: SOLO {type}. " +
                    $"{(type == QuestionType.MultipleChoice ? "Exactamente 3 opciones (A,B,C) y UNA correcta." : "Para TrueFalse, usa 'isTrue' y explicación breve.")} " +
                    $"Usa únicamente información explícita del contexto; no inventes. " +
                    $"Si no hay suficiente información, responde SOLO con JSON {{\"questions\": []}} (sin campos extra). " +
                    $"PROHIBIDO escribir mensajes como 'insuficiente contexto'. " +
                    $"Cierra correctamente llaves y corchetes.\n\n{prompt}"))
                {
                    responseText = response.Messages.Last().Content;
                }

                _rateLimiter.RecordRequest();

                string jsonResponse = ExtractJson(responseText);

                // En vez de lanzar, devolvemos vacío para no cortar el pipeline
                if (jsonResponse.Contains("\"error\"", StringComparison.OrdinalIgnoreCase))
                {
                    _logger.LogWarning("⚠️ Respuesta con 'error' en JSON. Retornando {{\"questions\":[]}}.");
                    return "{\"questions\":[]}";
                }

                _logger.LogInformation("✅ Preguntas generadas exitosamente");
                return jsonResponse;
            }
            catch (tryAGI.OpenAI.ApiException apiEx) when (
                apiEx.Message.Contains("Too Many Requests", StringComparison.OrdinalIgnoreCase) ||
                apiEx.Message.Contains("429"))
            {
                attempt++;
                _rateLimiter.RecordError();

                if (attempt > MAX_RETRIES)
                {
                    _logger.LogError(apiEx, "❌ 429 persistente tras {Attempts} intentos. Devolviendo vacío.", attempt);
                    return "{\"questions\":[]}";
                }

                var delayMs = (int)(Math.Pow(2, attempt) * 500 + Random.Shared.Next(0, 400));
                _logger.LogWarning("⏳ 429: reintentando en {Delay} ms (intento {Attempt}/{Max})", delayMs, attempt, MAX_RETRIES);
                await Task.Delay(delayMs);
                continue;
            }
            catch (HttpRequestException httpEx)
            {
                attempt++;
                _rateLimiter.RecordError();

                if (attempt > MAX_RETRIES)
                {
                    _logger.LogError(httpEx, "❌ Error HTTP persistente tras {Attempts} intentos. Devolviendo vacío.", attempt);
                    return "{\"questions\":[]}";
                }

                var delayMs = (int)(Math.Pow(2, attempt) * 400 + Random.Shared.Next(0, 300));
                _logger.LogWarning("⏳ Error HTTP: reintentando en {Delay} ms (intento {Attempt}/{Max})", delayMs, attempt, MAX_RETRIES);
                await Task.Delay(delayMs);
                continue;
            }
            catch (Exception ex)
            {
                _rateLimiter.RecordError();
                _logger.LogError(ex, "❌ Error generando preguntas (retornando vacío para no frenar el pipeline)");
                return "{\"questions\":[]}";
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // 2️⃣ GenerateAnswerExplanationAsync (NO SE USA EN GENERACIÓN)
    // ═══════════════════════════════════════════════════════════════
    public async Task<string> GenerateAnswerExplanationAsync(
        string questionText,
        string chosenAnswer,
        string correctAnswer,
        bool wasCorrect)
    {
        try
        {
            await _rateLimiter.WaitIfNeededAsync();

            var model = new OpenAiChatModel(_provider, _settings.Model);

            var prompt = BuildExplanationPrompt(
                questionText, chosenAnswer, correctAnswer, wasCorrect);

            string responseText = "";
            await foreach (var response in model.GenerateAsync(
                $"Eres un tutor paciente y constructivo de Derecho chileno.\n\n{prompt}"))
            {
                responseText = response.Messages.Last().Content;
            }

            _rateLimiter.RecordRequest();
            return responseText.Trim();
        }
        catch (Exception ex)
        {
            _rateLimiter.RecordError();
            _logger.LogError(ex, "❌ Error generando explicación");
            throw;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // 3️⃣ EvaluateOralAnswerAsync
    // ═══════════════════════════════════════════════════════════════
    public async Task<string> EvaluateOralAnswerAsync(
        string questionText,
        string expectedAnswer,
        string explanation,
        string studentAnswer)
    {
        try
        {
            await _rateLimiter.WaitIfNeededAsync();

            var model = new OpenAiChatModel(_provider, _settings.Model);
            var prompt = $@"
Eres un evaluador experto de exámenes de grado de Derecho chileno.

PREGUNTA: {questionText}
RESPUESTA ESPERADA: {expectedAnswer}
EXPLICACIÓN: {explanation}
RESPUESTA DEL ESTUDIANTE: {studentAnswer}

Evalúa si la respuesta del estudiante es correcta considerando:
- Es una respuesta ORAL (puede tener errores de transcripción menores)
- Enfócate en los CONCEPTOS CLAVE y la comprensión fundamental
- Tolera variaciones en la redacción si el concepto es correcto
- Considera sinónimos y reformulaciones válidas

RESPONDE EN JSON VÁLIDO:
{{
    ""isCorrect"": true/false,
    ""confidence"": 0.0-1.0,
    ""evaluation"": ""CORRECTA/PARCIAL/INCORRECTA"",
    ""feedback"": ""Explicación constructiva para el estudiante""
}}";

            string responseText = "";
            await foreach (var response in model.GenerateAsync(
                $"Eres un evaluador justo y objetivo de Derecho.\n\n{prompt}"))
            {
                responseText = response.Messages.Last().Content;
            }

            _rateLimiter.RecordRequest();
            return ExtractJson(responseText);
        }
        catch (Exception ex)
        {
            _rateLimiter.RecordError();
            _logger.LogError(ex, "❌ Error evaluando respuesta oral");
            throw;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // 4️⃣ GenerateResponseAsync
    // ═══════════════════════════════════════════════════════════════
    public async Task<string> GenerateResponseAsync(string prompt)
    {
        try
        {
            await _rateLimiter.WaitIfNeededAsync();

            var model = new OpenAiChatModel(_provider, _settings.Model);

            string responseText = "";
            await foreach (var response in model.GenerateAsync(prompt))
            {
                responseText = response.Messages.Last().Content;
            }

            _rateLimiter.RecordRequest();
            return responseText.Trim();
        }
        catch (Exception ex)
        {
            _rateLimiter.RecordError();
            _logger.LogError(ex, "❌ Error generando respuesta");
            throw;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // MÉTODOS AUXILIARES PRIVADOS
    // ═══════════════════════════════════════════════════════════════

    private string GetDifficultyInstructions(DifficultyLevel difficulty)
    {
        return difficulty switch
        {
            DifficultyLevel.Basic => @"
NIVEL BÁSICO - Fundamentos e Introducción:
- Conceptos fundamentales y definiciones básicas del Código Civil
- Vocabulario jurídico esencial y terminología básica
- Comprensión literal de artículos específicos
- Ejemplos de aplicación en situaciones cotidianas
- Preguntas directas sin interpretación compleja
- Respuestas explícitas en el texto",

            DifficultyLevel.Intermediate => @"
NIVEL INTERMEDIO - Aplicación y Relación:
- Aplicación práctica de conceptos jurídicos ya conocidos
- Relación y comparación entre diferentes artículos
- Casos prácticos de complejidad moderada
- Identificación de excepciones a reglas generales
- Interpretación sistemática de normas relacionadas
- Vocabulario técnico especializado",

            DifficultyLevel.Advanced => @"
NIVEL AVANZADO - Análisis y Síntesis:
- Análisis crítico profundo de instituciones jurídicas complejas
- Integración de múltiples artículos y principios generales
- Casos complejos con múltiples variables
- Interpretación jurídica avanzada (histórica, teleológica, sistemática)
- Identificación de excepciones y situaciones especiales
- Terminología técnica altamente especializada",

            _ => "Nivel intermedio por defecto"
        };
    }

    private string BuildEnhancedQuestionPrompt(
        string sourceText,
        string legalArea,
        QuestionType type,
        DifficultyLevel difficulty,
        string difficultyInstructions,
        int count,
        string formatExample)
    {
        // NO interpolado: verbatim @"..." (llaves normales)
        const string fewShots = @"
[EJEMPLOS]
# MultipleChoice (Básico)
{""questions"":[{
  ""questionText"": ""Respecto de la cosa juzgada formal, ¿cuál de las siguientes afirmaciones es correcta?"",
  ""options"": [
    {""id"": ""A"", ""text"": ""Impide iniciar un nuevo juicio sobre el mismo objeto y causa, con las mismas partes"", ""isCorrect"": false},
    {""id"": ""B"", ""text"": ""Vincula únicamente al tribunal que dictó la sentencia"", ""isCorrect"": false},
    {""id"": ""C"", ""text"": ""Se refiere a la inmutabilidad de las resoluciones dentro del mismo proceso, salvo recursos"", ""isCorrect"": true}
  ],
  ""explanation"": ""La cosa juzgada formal implica inmutabilidad dentro del mismo proceso, distinta de la material que impide un nuevo juicio."",
  ""difficulty"": ""basic""
}]}
# TrueFalse (Intermedio)
{""questions"":[{
  ""questionText"": ""La cosa juzgada material impide discutir nuevamente el mismo asunto entre las mismas partes."",
  ""isTrue"": true,
  ""explanation"": ""La cosa juzgada material bloquea reabrir un litigio sobre el mismo objeto y causa con identidad de partes."",
  ""difficulty"": ""intermediate""
}]}";

        // SÍ interpolado (usa {count} y el condicional por tipo)
        var rules = $@"
[REGLAS DE ESTILO]
- Escribe como profesor de examen de grado: directo, técnico, autónomo.
- PROHIBIDO: ""según el texto"", ""según el documento"", ""de acuerdo al fragmento"", ""el texto indica"", ""como se dijo"".
- Las preguntas deben ser comprensibles sin mencionar el texto fuente.
- Sé específico con el concepto jurídico; evita vaguedades.

[FORMATO]
- Responde SOLO con JSON válido con la propiedad ""questions"" (array).
- {(type == QuestionType.MultipleChoice ? "Para MultipleChoice: EXACTAMENTE 3 opciones (A,B,C) y UNA correcta." : "Para TrueFalse: usa booleano 'isTrue' y agrega 'explanation'.")}
- Incluye siempre ""explanation"" que explique el concepto jurídico directamente, sin decir ""es correcta"", ""es verdadera"", ""la opción X es correcta"" o frases similares.
- La explicación debe ser educativa y enfocarse en el fundamento legal o conceptual.

[CONTEO]
- Devuelve hasta " + count + @" ítems. Prioriza calidad y consistencia.";

        // SÍ interpolado: usa {legalArea}, {difficulty}, {sourceText}, {formatExample}
        return $@"
Genera preguntas de tipo '{type}' para un examen de Derecho chileno.

═══════════════════════════════════════════════════════════════
CONFIGURACIÓN
═══════════════════════════════════════════════════════════════
ÁREA LEGAL: {legalArea}
DIFICULTAD: {difficulty}

{difficultyInstructions}

{rules}

{fewShots}

═══════════════════════════════════════════════════════════════
CONTEXTO (FUENTE ÚNICA)
═══════════════════════════════════════════════════════════════
{sourceText}

═══════════════════════════════════════════════════════════════
FORMATO JSON REQUERIDO
═══════════════════════════════════════════════════════════════
{formatExample}

⚠️ No agregues texto antes o después del JSON.";
    }

    private string BuildExplanationPrompt(
        string questionText,
        string chosenAnswer,
        string correctAnswer,
        bool wasCorrect)
    {
        return $@"
Genera una explicación pedagógica clara y constructiva:

PREGUNTA: {questionText}
RESPUESTA DEL ESTUDIANTE: {chosenAnswer}
RESPUESTA CORRECTA: {correctAnswer}
RESULTADO: {(wasCorrect ? "✅ CORRECTA" : "❌ INCORRECTA")}

Tu explicación debe incluir:

{(wasCorrect
? @"1. ✅ Confirmación de por qué su respuesta es correcta
2. 📚 Fundamento legal o conceptual que la respalda
3. 💡 Consejo o truco mnemotécnico para recordar"
: @"1. ❌ Por qué su respuesta no es correcta
2. ✅ Por qué la respuesta correcta SÍ lo es
3. 📚 Fundamento legal o conceptual
4. 💡 Consejo para evitar este error")}

Tono: Constructivo, educativo y alentador (máximo 100 palabras).
";
    }

    /// <summary>
    /// Obtiene el formato de ejemplo según el tipo de pregunta
    /// </summary>
    private string GetFormatExample(QuestionType type, DifficultyLevel difficulty)
    {
        return type switch
        {
            QuestionType.MultipleChoice => GetMultipleChoiceFormat(difficulty),
            QuestionType.TrueFalse => GetTrueFalseFormat(difficulty),
            QuestionType.OpenEnded => GetOpenEndedFormat(difficulty),
            _ => "{}"
        };
    }

    private string GetMultipleChoiceFormat(DifficultyLevel difficulty)
    {
        var (question, correctText, explanation) = difficulty switch
        {
            DifficultyLevel.Basic => (
                "¿Qué son los bienes corporales según el Código Civil chileno?",
                "Aquellos que tienen un ser real y pueden ser percibidos por los sentidos",
                "Los bienes corporales son aquellos que tienen existencia física y pueden ser percibidos por los sentidos, según el Código Civil."
            ),
            DifficultyLevel.Intermediate => (
                "¿Cuál es la principal diferencia entre la tradición de bienes muebles e inmuebles?",
                "Los inmuebles requieren inscripción en el Conservador; los muebles, entrega material",
                "La tradición de bienes inmuebles se perfecciona mediante inscripción en el Conservador; los muebles mediante entrega material."
            ),
            _ => (
                "¿Cómo opera la prescripción adquisitiva extraordinaria?",
                "No requiere título ni buena fe; basta posesión ininterrumpida por el plazo legal",
                "La prescripción extraordinaria prescinde de título y buena fe, requiriendo únicamente posesión ininterrumpida durante el plazo legal."
            )
        };

        return $@"{{
  ""questions"": [
    {{
      ""questionText"": ""{question}"",
      ""options"": [
        {{""id"": ""A"", ""text"": ""Opción plausible pero incorrecta"", ""isCorrect"": false}},
        {{""id"": ""B"", ""text"": ""{correctText}"", ""isCorrect"": true}},
        {{""id"": ""C"", ""text"": ""Otra opción plausible pero incorrecta"", ""isCorrect"": false}}
      ],
      ""explanation"": ""{explanation}"",
      ""difficulty"": ""{difficulty.ToString().ToLower()}""
    }}
  ]
}}";
    }

    private string GetTrueFalseFormat(DifficultyLevel difficulty)
    {
        var (statement, isTrue, explanation) = difficulty switch
        {
            DifficultyLevel.Basic => (
                "Los bienes corporales son aquellos que tienen un ser real y pueden ser percibidos por los sentidos",
                true,
                "Los bienes corporales se definen legalmente como aquellos con existencia real y perceptibles por los sentidos."
            ),
            DifficultyLevel.Intermediate => (
                "La tradición de bienes inmuebles siempre se perfecciona por escritura pública",
                false,
                "La tradición de inmuebles se perfecciona mediante inscripción en el Conservador; la escritura pública corresponde al título, no a la tradición."
            ),
            _ => (
                "La prescripción adquisitiva extraordinaria no requiere título ni buena fe",
                true,
                "La prescripción extraordinaria requiere únicamente posesión continua durante el plazo legal, sin necesidad de título ni buena fe."
            )
        };

        return $@"{{
  ""questions"": [
    {{
      ""questionText"": ""{statement}"",
      ""isTrue"": {isTrue.ToString().ToLower()},
      ""explanation"": ""{explanation}"",
      ""difficulty"": ""{difficulty.ToString().ToLower()}""
    }}
  ]
}}";
    }

    private string GetOpenEndedFormat(DifficultyLevel difficulty)
    {
        var (question, answer) = difficulty switch
        {
            DifficultyLevel.Basic => (
                "¿Qué son los bienes corporales según el Código Civil chileno?",
                "Los bienes corporales tienen existencia real y son perceptibles por los sentidos."
            ),
            DifficultyLevel.Intermediate => (
                "Explique la diferencia entre bienes muebles e inmuebles y una consecuencia jurídica",
                "Los inmuebles requieren inscripción para su tradición; los muebles, entrega. Esa es la consecuencia clave."
            ),
            _ => (
                "Analice requisitos de la prescripción adquisitiva extraordinaria",
                "No exige título ni buena fe; requiere posesión continua por el plazo legal."
            )
        };

        return $@"{{
  ""questions"": [
    {{
      ""questionText"": ""{question}"",
      ""modelAnswer"": ""{answer}"",
      ""explanation"": ""{answer}"",
      ""difficulty"": ""{difficulty.ToString().ToLower()}""
    }}
  ]
}}";
    }

    private string ExtractJson(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
            return "{}";

        var start = text.IndexOf('{');
        var end = text.LastIndexOf('}');

        return (start >= 0 && end > start)
            ? text.Substring(start, end - start + 1).Trim()
            : text.Trim();
    }

    // Temperatura recomendada por tipo/nivel
    private static double GetTemp(QuestionType type, DifficultyLevel diff)
    {
        double baseTemp = type == QuestionType.TrueFalse ? 0.1 : 0.2;
        return diff switch
        {
            DifficultyLevel.Basic => baseTemp,
            DifficultyLevel.Intermediate => Math.Min(baseTemp + 0.05, 0.3),
            DifficultyLevel.Advanced => Math.Min(baseTemp + 0.1, 0.35),
            _ => baseTemp
        };
    }
}
