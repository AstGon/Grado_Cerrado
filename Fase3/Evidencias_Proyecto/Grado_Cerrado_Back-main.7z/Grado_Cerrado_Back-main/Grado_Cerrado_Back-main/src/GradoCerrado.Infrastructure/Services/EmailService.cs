using System;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using GradoCerrado.Application.Interfaces;
using GradoCerrado.Infrastructure.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace GradoCerrado.Infrastructure.Services
{
    public class EmailService : IEmailService
    {
        private readonly EmailSettings _emailSettings;
        private readonly ILogger<EmailService> _logger;

        public EmailService(IOptions<EmailSettings> emailSettings, ILogger<EmailService> logger)
        {
            _emailSettings = emailSettings.Value;
            _logger = logger;
        }

        public async Task<bool> SendPasswordResetEmailAsync(string toEmail, string resetToken)
        {
            try
            {
                using var smtpClient = new SmtpClient(_emailSettings.SmtpServer, _emailSettings.SmtpPort)
                {
                    Credentials = new NetworkCredential(_emailSettings.SmtpUsername, _emailSettings.SmtpPassword),
                    EnableSsl = _emailSettings.EnableSsl
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_emailSettings.FromEmail, _emailSettings.FromName),
                    Subject = "Recuperación de Contraseña - Grado Cerrado",
                    Body = BuildPasswordResetEmailBody(resetToken),
                    IsBodyHtml = true
                };

                mailMessage.To.Add(toEmail);

                await smtpClient.SendMailAsync(mailMessage);

                _logger.LogInformation("Email de recuperación enviado exitosamente a: {Email}", toEmail);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error enviando email de recuperación a: {Email}", toEmail);
                return false;
            }
        }

        private string BuildPasswordResetEmailBody(string resetToken)
        {
            return $@"
                <html>
                <body style='font-family: Arial, sans-serif;'>
                    <div style='max-width: 600px; margin: 0 auto; padding: 20px;'>
                        <h2 style='color: #333;'>Recuperación de Contraseña</h2>
                        <p>Has solicitado recuperar tu contraseña en Grado Cerrado.</p>
                        <p>Tu código de recuperación es:</p>
                        <div style='background-color: #f4f4f4; padding: 15px; text-align: center; font-size: 24px; font-weight: bold; letter-spacing: 3px; margin: 20px 0;'>
                            {resetToken}
                        </div>
                        <p>Este código expirará en 1 hora.</p>
                        <p>Si no solicitaste este cambio, ignora este email.</p>
                        <hr style='margin-top: 30px; border: none; border-top: 1px solid #ddd;'>
                        <p style='color: #888; font-size: 12px;'>Grado Cerrado - Tu plataforma de estudio legal</p>
                    </div>
                </body>
                </html>
            ";
        }
    }
}