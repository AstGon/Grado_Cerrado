﻿
using CSharpToJsonSchema;
using GradoCerrado.Application.Interfaces;
using GradoCerrado.Domain.Entities;
using GradoCerrado.Infrastructure.Configuration;
using GradoCerrado.Infrastructure.DTOs;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Text.Json;

namespace GradoCerrado.Infrastructure.Services;

public class QuestionGenerationService : IQuestionGenerationService
{
    private readonly IVectorService _vectorService;
    private readonly OpenAISettings _settings;
    private readonly ILogger<QuestionGenerationService> _logger;
    private readonly IAIService _aiService;
    private readonly IQuestionValidationService _validationService;

    public QuestionGenerationService(
        IOptions<OpenAISettings> settings,
        IVectorService vectorService,
        ILogger<QuestionGenerationService> logger,
        IAIService aiService,
        IQuestionValidationService validationService)
    {
        _settings = settings.Value;
        _vectorService = vectorService;
        _logger = logger;
        _aiService = aiService;
        _validationService = validationService;
    }

    // ════════════════════════════════════════════════════════════════
    // 🆕 MÉTODO PRINCIPAL CON VALIDACIÓN INTEGRADA
    // ════════════════════════════════════════════════════════════════

    public async Task<List<StudyQuestion>> GenerateQuestionsFromDocument(
        LegalDocument document,
        int questionCount = 10,
        bool validateWithAI = true)
    {
        _logger.LogInformation(
            "🤖 Generando {Count} preguntas para documento: {DocumentTitle}",
            questionCount, document.Title);

        try
        {
            // ════════════════════════════════════════════════════════
            // 1️⃣ GENERAR PREGUNTAS CON CHATGPT (LÓGICA ORIGINAL)
            // ════════════════════════════════════════════════════════

            var content = document.Content.Length > 12000
                ? document.Content.Substring(0, 12000)
                : document.Content;

            var multipleChoiceCount = (int)(questionCount * 0.7);
            var trueFalseCount = questionCount - multipleChoiceCount;

            var mcQuestions = await GenerateMultipleChoiceQuestions(
                content, document, multipleChoiceCount);

            var tfQuestions = await GenerateTrueFalseQuestions(
                content, document, trueFalseCount);

            var generatedQuestions = mcQuestions.Concat(tfQuestions).ToList();

            _logger.LogInformation(
                "✅ {Total} preguntas generadas con ChatGPT",
                generatedQuestions.Count);

            // ════════════════════════════════════════════════════════
            // 2️⃣ VALIDAR CON GEMINI (SI ESTÁ ACTIVADO)
            // ════════════════════════════════════════════════════════

            if (!validateWithAI)
            {
                _logger.LogInformation("⚠️ Validación con Gemini desactivada");
                return generatedQuestions;
            }

            var validatedQuestions = await ValidateQuestionsWithGemini(
                generatedQuestions,
                document.Content);

            return validatedQuestions;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas del documento");
            throw;
        }
    }

    // ════════════════════════════════════════════════════════════════
    // 🆕 MÉTODO DE VALIDACIÓN CON GEMINI
    // ════════════════════════════════════════════════════════════════

    public async Task<List<StudyQuestion>> ValidateQuestionsWithGemini(
        List<StudyQuestion> questions,
        string documentContent)
    {
        if (!questions.Any())
        {
            _logger.LogWarning("No hay preguntas para validar");
            return questions;
        }

        _logger.LogInformation("🔍 Iniciando validación con Gemini de {Count} preguntas...", questions.Count);

        var validatedQuestions = new List<StudyQuestion>();
        var stats = new
        {
            Total = 0,
            Approved = 0,
            Rejected = 0,
            Errors = 0
        };

        // Dividir contenido en chunks para asociar con preguntas
        var chunks = SplitIntoChunks(documentContent, maxSize: 1000);

        foreach (var question in questions)
        {
            stats = stats with { Total = stats.Total + 1 };

            try
            {
                // Determinar el chunk relevante para esta pregunta
                var chunkContent = GetRelevantChunk(question, chunks, documentContent);

                // Validar con Gemini
                var validation = await _validationService.ValidateQuestionAsync(
                    chunkContent,
                    question.QuestionText,
                    question.CorrectAnswer ?? string.Empty);

                // Umbrales mínimos de validación
                const decimal minRelevance = 0.7m;
                const decimal minQuality = 0.7m;

                // Evaluar si pasa los umbrales
                if (validation.IsValid &&
                    validation.Scores.QuestionRelevance >= minRelevance &&
                    validation.Scores.QuestionQuality >= minQuality)
                {
                    // ✅ APROBADA
                    stats = stats with { Approved = stats.Approved + 1 };
                    validatedQuestions.Add(question);

                    _logger.LogInformation(
                        "✅ APROBADA [{Index}/{Total}]: '{Question}' (R:{Relevance:F2}, Q:{Quality:F2})",
                        stats.Total,
                        questions.Count,
                        TruncateText(question.QuestionText, 60),
                        validation.Scores.QuestionRelevance,
                        validation.Scores.QuestionQuality);
                }
                else
                {
                    // ❌ RECHAZADA
                    stats = stats with { Rejected = stats.Rejected + 1 };

                    _logger.LogWarning(
                        "❌ RECHAZADA [{Index}/{Total}]: '{Question}' - {Feedback}",
                        stats.Total,
                        questions.Count,
                        TruncateText(question.QuestionText, 60),
                        validation.Feedback);

                    // Log detallado de scores
                    _logger.LogDebug(
                        "   Scores: Relevancia={R:F2}, Calidad={Q:F2}, Precisión={A:F2}",
                        validation.Scores.QuestionRelevance,
                        validation.Scores.QuestionQuality,
                        validation.Scores.AnswerCorrectness);
                }
            }
            catch (Exception ex)
            {
                stats = stats with { Errors = stats.Errors + 1 };

                _logger.LogError(ex,
                    "⚠️ Error validando pregunta [{Index}/{Total}]: '{Question}'. Se incluirá sin validación.",
                    stats.Total,
                    questions.Count,
                    TruncateText(question.QuestionText, 60));

                // En caso de error, incluir la pregunta (mejor tener pregunta que nada)
                validatedQuestions.Add(question);
            }
        }

        // ════════════════════════════════════════════════════════
        // 3️⃣ LOG FINAL DE ESTADÍSTICAS
        // ════════════════════════════════════════════════════════

        var approvalRate = stats.Total > 0
            ? Math.Round((decimal)stats.Approved / stats.Total * 100, 1)
            : 0;

        _logger.LogInformation(
            "📊 Validación completada: {Approved}/{Total} aprobadas ({Rate}% aprobación), {Rejected} rechazadas, {Errors} errores",
            stats.Approved,
            stats.Total,
            approvalRate,
            stats.Rejected,
            stats.Errors);

        if (validatedQuestions.Count == 0)
        {
            _logger.LogWarning(
                "⚠️ ADVERTENCIA: Ninguna pregunta pasó la validación. " +
                "Considera revisar los prompts de ChatGPT o ajustar umbrales de validación.");
        }
        else if (approvalRate < 50)
        {
            _logger.LogWarning(
                "⚠️ Tasa de aprobación baja ({Rate}%). " +
                "Puede ser necesario mejorar la calidad de generación de preguntas.",
                approvalRate);
        }

        return validatedQuestions;
    }

    // ════════════════════════════════════════════════════════════════
    // 🆕 MÉTODOS AUXILIARES PARA VALIDACIÓN
    // ════════════════════════════════════════════════════════════════

    /// <summary>
    /// Divide el contenido en chunks para asociar con preguntas
    /// </summary>
    private List<string> SplitIntoChunks(string content, int maxSize = 1000)
    {
        var chunks = new List<string>();
        var sentences = content.Split(new[] { ". ", ".\n", "? ", "! " }, StringSplitOptions.RemoveEmptyEntries);

        var currentChunk = "";
        foreach (var sentence in sentences)
        {
            if (currentChunk.Length + sentence.Length > maxSize && !string.IsNullOrEmpty(currentChunk))
            {
                chunks.Add(currentChunk.Trim());
                currentChunk = "";
            }
            currentChunk += sentence + ". ";
        }

        if (!string.IsNullOrEmpty(currentChunk))
        {
            chunks.Add(currentChunk.Trim());
        }

        return chunks;
    }

    /// <summary>
    /// Obtiene el chunk más relevante para una pregunta específica
    /// </summary>
    private string GetRelevantChunk(StudyQuestion question, List<string> chunks, string fullContent)
    {
        // Opción 1: Buscar palabras clave de la pregunta en los chunks
        var questionKeywords = ExtractKeywords(question.QuestionText);

        // Buscar el chunk que más coincida con las palabras clave
        var bestChunk = chunks
            .Select(chunk => new
            {
                Chunk = chunk,
                Score = questionKeywords.Count(keyword =>
                    chunk.Contains(keyword, StringComparison.OrdinalIgnoreCase))
            })
            .OrderByDescending(x => x.Score)
            .FirstOrDefault();

        if (bestChunk != null && bestChunk.Score > 0)
        {
            return bestChunk.Chunk;
        }

        // Opción 2: Si no hay match, usar el primer chunk o contenido limitado
        return chunks.FirstOrDefault() ??
               fullContent.Substring(0, Math.Min(1000, fullContent.Length));
    }

    /// <summary>
    /// Extrae palabras clave simples de una pregunta
    /// </summary>
    private List<string> ExtractKeywords(string text)
    {
        if (string.IsNullOrEmpty(text))
            return new List<string>();

        // Palabras a ignorar (stop words básicas en español)
        var stopWords = new HashSet<string>
        {
            "el", "la", "los", "las", "un", "una", "de", "del", "en", "y", "o",
            "que", "qué", "cuál", "cuáles", "cómo", "por", "para", "con", "es",
            "son", "fue", "fue", "será", "sea", "cual", "según"
        };

        return text
            .Split(new[] { ' ', ',', '.', '?', '¡', '!' }, StringSplitOptions.RemoveEmptyEntries)
            .Where(word => word.Length > 3 && !stopWords.Contains(word.ToLower()))
            .Take(5) // Top 5 palabras clave
            .ToList();
    }

    /// <summary>
    /// Trunca texto para logs
    /// </summary>
    private string TruncateText(string text, int maxLength)
    {
        if (string.IsNullOrEmpty(text))
            return string.Empty;

        return text.Length <= maxLength
            ? text
            : text.Substring(0, maxLength) + "...";
    }

    // ════════════════════════════════════════════════════════════════
    // RESTO DE MÉTODOS ORIGINALES (SIN CAMBIOS)
    // ════════════════════════════════════════════════════════════════

    public async Task<List<StudyQuestion>> GenerateRandomQuestions(
        List<string> legalAreas,
        DifficultyLevel difficulty,
        int count = 10)
    {
        try
        {
            _logger.LogInformation(
                "Generando {Count} preguntas aleatorias",
                count);

            var searchQuery = string.Join(" ", legalAreas);

            var relevantDocs = await _vectorService.SearchSimilarAsync(searchQuery, limit: 3);

            if (!relevantDocs.Any())
            {
                _logger.LogWarning("No se encontraron documentos relevantes");
                return new List<StudyQuestion>();
            }

            var content = string.Join("\n\n", relevantDocs.Select(d => d.Content));

            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: legalAreas.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.MultipleChoice,
                difficulty: difficulty,
                count: count);

            return ParseQuestionResponse<MultipleChoiceResponse>(
                questionsJson,
                legalAreas.FirstOrDefault() ?? "Derecho General",
                difficulty,
                Guid.NewGuid());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas aleatorias");
            return new List<StudyQuestion>();
        }
    }

    public async Task<StudyQuestion> GenerateFollowUpQuestion(
        StudyQuestion previousQuestion,
        bool wasCorrect)
    {
        try
        {
            var difficulty = wasCorrect
                ? IncreaseDifficulty(previousQuestion.Difficulty)
                : DecreaseDifficulty(previousQuestion.Difficulty);

            var relatedConcepts = string.Join(", ", previousQuestion.RelatedConcepts);

            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: $"Conceptos: {relatedConcepts}\nPregunta anterior: {previousQuestion.QuestionText}",
                legalArea: previousQuestion.LegalArea,
                type: previousQuestion.Type,
                difficulty: difficulty,
                count: 1);

            var questions = ParseQuestionResponse<MultipleChoiceResponse>(
                questionsJson,
                previousQuestion.LegalArea,
                difficulty,
                previousQuestion.SourceDocumentIds.FirstOrDefault());

            return questions.FirstOrDefault() ?? previousQuestion;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando pregunta de seguimiento");
            return previousQuestion;
        }
    }

    public async Task<List<StudyQuestion>> GenerateAndSaveQuestionsAsync(
        string documentContent,
        List<string> legalAreas,
        DifficultyLevel difficulty,
        int count = 10)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: documentContent,
                legalArea: legalAreas.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.MultipleChoice,
                difficulty: difficulty,
                count: count);

            var questions = ParseQuestionResponse<MultipleChoiceResponse>(
                questionsJson,
                legalAreas.FirstOrDefault() ?? "Derecho General",
                difficulty,
                Guid.NewGuid());

            return questions;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando y guardando preguntas");
            throw;
        }
    }

    // En QuestionGenerationService.cs (o donde tengas la implementación)

    public async Task<List<StudyQuestion>> GenerateQuestionsWithMixedTypesAndDifficulty(
        LegalDocument document,
        int totalCount,
        QuestionType[]? allowedTypes = null)
    {
        var allQuestions = new List<StudyQuestion>();

        try
        {
            if (document == null || string.IsNullOrWhiteSpace(document.Content))
            {
                _logger.LogWarning("⚠️ Documento nulo o sin contenido. Retornando 0 preguntas.");
                return allQuestions;
            }

            if (totalCount <= 0)
            {
                _logger.LogInformation("ℹ️ totalCount <= 0. Nada que generar.");
                return allQuestions;
            }

            // Tipos permitidos por defecto (sin abiertas)
            var types = (allowedTypes == null || allowedTypes.Length == 0)
                ? new[] { QuestionType.TrueFalse, QuestionType.MultipleChoice }
                : allowedTypes;

            // Recorta para reducir latencia y chances de 429
            var safeContent = document.Content.Length > 12000
                ? document.Content[..12000]
                : document.Content;

            _logger.LogInformation(
                "🎯 Generando {Count} preguntas. Tipos permitidos: {Types}",
                totalCount, string.Join(", ", types));

            var difficulties = new[] { DifficultyLevel.Basic, DifficultyLevel.Intermediate, DifficultyLevel.Advanced };

            // Distribución equitativa por dificultad
            int questionsPerDifficulty = totalCount / difficulties.Length;
            int remainingQuestions = totalCount % difficulties.Length;

            foreach (var difficulty in difficulties)
            {
                int questionsForThisDifficulty = questionsPerDifficulty;

                // Resto al nivel básico
                if (difficulty == DifficultyLevel.Basic && remainingQuestions > 0)
                {
                    questionsForThisDifficulty += remainingQuestions;
                }

                if (questionsForThisDifficulty == 0) continue;

                _logger.LogInformation(
                    "📝 Generando {Count} preguntas nivel {Level}...",
                    questionsForThisDifficulty, difficulty);

                // Distribución por tipo dentro del nivel
                int questionsPerType = questionsForThisDifficulty / types.Length;
                int extraQuestions = questionsForThisDifficulty % types.Length;

                for (int i = 0; i < types.Length; i++)
                {
                    var type = types[i];
                    int countForThisType = questionsPerType;

                    // Extras al primer tipo
                    if (i == 0 && extraQuestions > 0)
                    {
                        countForThisType += extraQuestions;
                    }

                    if (countForThisType == 0) continue;

                    try
                    {
                        var jsonResponse = await _aiService.GenerateStructuredQuestionsAsync(
                            safeContent,
                            document.AreaNombre ?? "Derecho General",
                            type,
                            difficulty,
                            countForThisType
                        );

                        var questionsForTypeAndDifficulty = ParseQuestionsFromJson(
                            jsonResponse,
                            type,
                            difficulty,
                            document.AreaNombre ?? "Derecho General"
                        );

                        if (questionsForTypeAndDifficulty?.Count > 0)
                        {
                            allQuestions.AddRange(questionsForTypeAndDifficulty);
                        }

                        _logger.LogInformation(
                            "✅ {Count} preguntas {Type} nivel {Level} generadas",
                            questionsForTypeAndDifficulty?.Count ?? 0, type, difficulty);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex,
                            "❌ Error generando preguntas {Type} nivel {Level}",
                            type, difficulty);
                        // Continuar con las siguientes combinaciones
                    }
                }
            }

            // Si no se generó nada, usar Fallback (MC / Intermedio) con la meta completa
            if (allQuestions.Count == 0)
            {
                _logger.LogWarning("⚠️ No se generaron preguntas en las combinaciones. Activando fallback MC/Intermedio ({Count}).", totalCount);
                try
                {
                    var json = await _aiService.GenerateStructuredQuestionsAsync(
                        safeContent,
                        document.AreaNombre ?? "Derecho General",
                        QuestionType.MultipleChoice,
                        DifficultyLevel.Intermediate,
                        totalCount
                    );

                    var fallbackQs = ParseQuestionsFromJson(
                        json,
                        QuestionType.MultipleChoice,
                        DifficultyLevel.Intermediate,
                        document.AreaNombre ?? "Derecho General"
                    );

                    if (fallbackQs?.Count > 0)
                    {
                        allQuestions.AddRange(fallbackQs);
                        _logger.LogInformation("✅ Fallback generó {Count} preguntas", fallbackQs.Count);
                    }
                    else
                    {
                        _logger.LogWarning("⚠️ Fallback no produjo preguntas.");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "❌ Fallback también falló");
                }
            }
            // Si se generó menos que la meta, intentar completar con un top-up MC/Intermedio
            else if (allQuestions.Count < totalCount)
            {
                int missing = totalCount - allQuestions.Count;
                _logger.LogWarning("ℹ️ Se generaron {Have}/{Target}. Intentando top-up de {Missing} MC/Intermedio.",
                    allQuestions.Count, totalCount, missing);

                try
                {
                    var json = await _aiService.GenerateStructuredQuestionsAsync(
                        safeContent,
                        document.AreaNombre ?? "Derecho General",
                        QuestionType.MultipleChoice,
                        DifficultyLevel.Intermediate,
                        missing
                    );

                    var topUpQs = ParseQuestionsFromJson(
                        json,
                        QuestionType.MultipleChoice,
                        DifficultyLevel.Intermediate,
                        document.AreaNombre ?? "Derecho General"
                    );

                    if (topUpQs?.Count > 0)
                    {
                        allQuestions.AddRange(topUpQs);
                        _logger.LogInformation("✅ Top-up añadió {Count} preguntas (total {Total})",
                            topUpQs.Count, allQuestions.Count);
                    }
                    else
                    {
                        _logger.LogWarning("⚠️ Top-up no añadió preguntas.");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "❌ Top-up falló");
                }
            }

            _logger.LogInformation(
                "✅ Total generado: {Count}/{Target} preguntas",
                allQuestions.Count, totalCount);

            return allQuestions;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error en generación mixta de preguntas. Devolviendo acumulado ({Count}).", allQuestions.Count);
            // No relanzamos: devolvemos lo que haya para no cortar el pipeline
            return allQuestions;
        }
    }


    // Método auxiliar para parsear el JSON de respuesta
    // Método auxiliar para parsear el JSON de respuesta
    private List<StudyQuestion> ParseQuestionsFromJson(
        string jsonResponse,
        QuestionType type,
        DifficultyLevel difficulty,
        string legalArea)
    {
        try
        {
            var questions = new List<StudyQuestion>();
            var jsonDoc = JsonDocument.Parse(jsonResponse);

            if (!jsonDoc.RootElement.TryGetProperty("questions", out var questionsArray))
            {
                _logger.LogWarning("No se encontró array 'questions' en respuesta JSON");
                return questions;
            }

            foreach (var questionElement in questionsArray.EnumerateArray())
            {
                try
                {
                    var question = new StudyQuestion
                    {
                        Id = Guid.NewGuid(),
                        Type = type,
                        Difficulty = difficulty,
                        LegalArea = legalArea,
                        RelatedConcepts = new List<string>(),
                        SourceDocumentIds = new List<Guid>(), // ✅ Inicializar lista vacía
                        CreatedAt = DateTime.UtcNow,
                        IsActive = true
                    };

                    // Extraer texto de la pregunta
                    if (questionElement.TryGetProperty("questionText", out var questionText))
                    {
                        question.QuestionText = questionText.GetString() ?? "";
                    }

                    // Extraer explicación
                    if (questionElement.TryGetProperty("explanation", out var explanation))
                    {
                        question.Explanation = explanation.GetString() ?? "";
                    }

                    // Extraer conceptos relacionados
                    if (questionElement.TryGetProperty("relatedConcepts", out var concepts))
                    {
                        question.RelatedConcepts = concepts.EnumerateArray()
                            .Select(c => c.GetString() ?? "")
                            .Where(c => !string.IsNullOrWhiteSpace(c))
                            .ToList();
                    }

                    // Procesar según el tipo
                    if (type == QuestionType.MultipleChoice)
                    {
                        question.Options = new List<QuestionOption>();

                        if (questionElement.TryGetProperty("options", out var options))
                        {
                            foreach (var option in options.EnumerateArray())
                            {
                                var optionObj = new QuestionOption
                                {
                                    Id = Guid.NewGuid(), // ✅ GUID para Id
                                    Text = option.GetProperty("text").GetString() ?? "",
                                    IsCorrect = option.GetProperty("isCorrect").GetBoolean()
                                };
                                question.Options.Add(optionObj);
                            }

                            // ✅ RANDOMIZAR OPCIONES
                            question.Options = RandomizeOptions(question.Options);
                        }

                        // Establecer respuesta correcta (el TEXT de la opción correcta)
                        var correctOption = question.Options?.FirstOrDefault(o => o.IsCorrect);
                        question.CorrectAnswer = correctOption?.Text ?? ""; // ✅ Usar Text, no Id
                    }
                    else if (type == QuestionType.TrueFalse)
                    {
                        if (questionElement.TryGetProperty("isTrue", out var isTrue))
                        {
                            var boolValue = isTrue.GetBoolean();
                            question.IsTrue = boolValue;
                            question.CorrectAnswer = boolValue ? "Verdadero" : "Falso"; // ✅ String
                        }
                    }

                    questions.Add(question);
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Error parseando pregunta individual");
                }
            }

            return questions;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error parseando JSON de preguntas");
            return new List<StudyQuestion>();
        }
    }

    private async Task<List<StudyQuestion>> GenerateMultipleChoiceQuestionsForLevel(
        string content,
        LegalDocument document,
        int count,
        DifficultyLevel level)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.MultipleChoice,
                difficulty: level,
                count: count);

            return ParseQuestionResponse<MultipleChoiceResponse>(
                questionsJson,
                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                level,
                document.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas de selección múltiple nivel {Level}", level);
            return new List<StudyQuestion>();
        }
    }

    private async Task<List<StudyQuestion>> GenerateTrueFalseQuestionsForLevel(
        string content,
        LegalDocument document,
        int count,
        DifficultyLevel level)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.TrueFalse,
                difficulty: level,
                count: count);

            return ParseQuestionResponse<TrueFalseResponse>(
                questionsJson,
                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                level,
                document.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas verdadero/falso nivel {Level}", level);
            return new List<StudyQuestion>();
        }
    }

    private async Task<List<StudyQuestion>> GenerateOpenEndedQuestionsForLevel(
        string content,
        LegalDocument document,
        int count,
        DifficultyLevel level)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.OpenEnded,
                difficulty: level,
                count: count);

            return ParseQuestionResponse<OpenEndedResponse>(
                questionsJson,
                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                level,
                document.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas de desarrollo nivel {Level}", level);
            return new List<StudyQuestion>();
        }
    }

    private async Task<List<StudyQuestion>> GenerateMultipleChoiceQuestions(
        string content,
        LegalDocument document,
        int count)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.MultipleChoice,
                difficulty: document.Difficulty,
                count: count);

            return ParseQuestionResponse<MultipleChoiceResponse>(
                questionsJson,
                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                document.Difficulty,
                document.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas de selección múltiple");
            return new List<StudyQuestion>();
        }
    }

    private async Task<List<StudyQuestion>> GenerateTrueFalseQuestions(
        string content,
        LegalDocument document,
        int count)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.TrueFalse,
                difficulty: document.Difficulty,
                count: count);

            return ParseQuestionResponse<TrueFalseResponse>(
                questionsJson,
                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                document.Difficulty,
                document.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas verdadero/falso");
            return new List<StudyQuestion>();
        }
    }

    private async Task<List<StudyQuestion>> GenerateOpenEndedQuestions(
        string content,
        LegalDocument document,
        int count)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.OpenEnded,
                difficulty: document.Difficulty,
                count: count);

            return ParseQuestionResponse<OpenEndedResponse>(
                questionsJson,
                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                document.Difficulty,
                document.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas de desarrollo");
            return new List<StudyQuestion>();
        }
    }

    private List<StudyQuestion> ParseQuestionResponse<T>(
        string jsonResponse,
        string legalArea,
        DifficultyLevel difficulty,
        Guid documentId)
    {
        try
        {
            _logger.LogDebug("📝 JSON recibido (primeros 500 chars):\n{Json}",
                jsonResponse.Substring(0, Math.Min(500, jsonResponse.Length)));

            string cleanedJson = CleanAndValidateJson(jsonResponse);

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            if (typeof(T) == typeof(MultipleChoiceResponse))
            {
                var response = JsonSerializer.Deserialize<MultipleChoiceResponse>(
                    cleanedJson, options);

                return response?.Questions?.Select(q =>
                {
                    // Crear opciones con GUID
                    var questionOptions = q.Options.Select(o => new QuestionOption
                    {
                        Id = Guid.NewGuid(), // ✅ GUID, no string
                        Text = o.Text,
                        IsCorrect = o.IsCorrect
                    }).ToList();

                    // ✅ RANDOMIZAR OPCIONES
                    var randomizedOptions = RandomizeOptions(questionOptions);

                    return new StudyQuestion
                    {
                        Id = Guid.NewGuid(),
                        SourceDocumentIds = new List<Guid> { documentId },
                        QuestionText = q.QuestionText,
                        Type = QuestionType.MultipleChoice,
                        Difficulty = difficulty,
                        LegalArea = legalArea,
                        Options = randomizedOptions,
                        CorrectAnswer = randomizedOptions.First(o => o.IsCorrect).Text, // ✅ TEXT, no Id
                        Explanation = q.Explanation,
                        RelatedConcepts = q.RelatedConcepts ?? new List<string>(),
                        CreatedAt = DateTime.UtcNow,
                        IsActive = true
                    };
                }).ToList() ?? new List<StudyQuestion>();
            }
            else if (typeof(T) == typeof(TrueFalseResponse))
            {
                var response = JsonSerializer.Deserialize<TrueFalseResponse>(
                    cleanedJson, options);

                return response?.Questions?.Select(q => new StudyQuestion
                {
                    Id = Guid.NewGuid(),
                    SourceDocumentIds = new List<Guid> { documentId },
                    QuestionText = q.QuestionText,
                    Type = QuestionType.TrueFalse,
                    Difficulty = difficulty,
                    LegalArea = legalArea,
                    IsTrue = q.IsTrue,
                    CorrectAnswer = q.IsTrue ? "Verdadero" : "Falso", // ✅ String
                    Explanation = q.Explanation,
                    RelatedConcepts = q.RelatedConcepts ?? new List<string>(),
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                }).ToList() ?? new List<StudyQuestion>();
            }
            else if (typeof(T) == typeof(OpenEndedResponse))
            {
                var response = JsonSerializer.Deserialize<OpenEndedResponse>(
                    cleanedJson, options);

                return response?.Questions?.Select(q => new StudyQuestion
                {
                    Id = Guid.NewGuid(),
                    SourceDocumentIds = new List<Guid> { documentId },
                    QuestionText = q.QuestionText,
                    Type = QuestionType.OpenEnded,
                    Difficulty = difficulty,
                    LegalArea = legalArea,
                    Options = new List<QuestionOption>(),
                    CorrectAnswer = q.ModelAnswer ?? "", // ✅ String con fallback
                    Explanation = q.Explanation,
                    RelatedConcepts = q.RelatedConcepts ?? new List<string>(),
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                }).ToList() ?? new List<StudyQuestion>();
            }

            return new List<StudyQuestion>(); // ✅ Retorno vacío válido
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error parseando respuesta JSON");
            _logger.LogError("JSON que causó el error:\n{Json}", jsonResponse);
            return new List<StudyQuestion>();
        }
    }

    private string CleanAndValidateJson(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return "{}";

        var start = json.IndexOf('{');
        var end = json.LastIndexOf('}');

        if (start < 0 || end < 0 || end <= start)
        {
            _logger.LogWarning("⚠️ No se pudo encontrar JSON válido en la respuesta");
            return "{}";
        }

        var extracted = json.Substring(start, end - start + 1);

        int openBraces = extracted.Count(c => c == '{');
        int closeBraces = extracted.Count(c => c == '}');
        int openBrackets = extracted.Count(c => c == '[');
        int closeBrackets = extracted.Count(c => c == ']');

        if (openBraces != closeBraces || openBrackets != closeBrackets)
        {
            _logger.LogWarning("⚠️ JSON desbalanceado: {{={0}, }}={1}, [={2}, ]={3}",
                openBraces, closeBraces, openBrackets, closeBrackets);

            while (openBraces > closeBraces)
            {
                extracted += "}";
                closeBraces++;
            }
            while (openBrackets > closeBrackets)
            {
                extracted += "]";
                closeBrackets++;
            }
        }

        return extracted;
    }

    private DifficultyLevel IncreaseDifficulty(DifficultyLevel current)
    {
        return current switch
        {
            DifficultyLevel.Basic => DifficultyLevel.Intermediate,
            DifficultyLevel.Intermediate => DifficultyLevel.Advanced,
            DifficultyLevel.Advanced => DifficultyLevel.Advanced,
            _ => current
        };
    }

    private DifficultyLevel DecreaseDifficulty(DifficultyLevel current)
    {
        return current switch
        {
            DifficultyLevel.Advanced => DifficultyLevel.Intermediate,
            DifficultyLevel.Intermediate => DifficultyLevel.Basic,
            DifficultyLevel.Basic => DifficultyLevel.Basic,
            _ => current
        };
    }

    private List<QuestionOption> RandomizeOptions(List<QuestionOption> options)
    {
        if (options == null || options.Count <= 1)
            return options;

        var random = new Random();
        return options.OrderBy(_ => random.Next()).ToList();
    }
}




/*
using CSharpToJsonSchema;
using GradoCerrado.Application.Interfaces;
using GradoCerrado.Domain.Entities;
using GradoCerrado.Infrastructure.Configuration;
using GradoCerrado.Infrastructure.DTOs;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Text.Json;

namespace GradoCerrado.Infrastructure.Services;

public class QuestionGenerationService : IQuestionGenerationService
{
    private readonly IVectorService _vectorService;
    private readonly OpenAISettings _settings;
    private readonly ILogger<QuestionGenerationService> _logger;
    private readonly IAIService _aiService;
    private readonly IQuestionValidationService _validationService;  // 🆕 INYECTAR


    public QuestionGenerationService(
        IOptions<OpenAISettings> settings,
        IVectorService vectorService,
        ILogger<QuestionGenerationService> logger,
        IAIService aiService,
        IQuestionValidationService validationService)
    {
        _settings = settings.Value;
        _vectorService = vectorService;
        _logger = logger;
        _aiService = aiService;
        _validationService = validationService;

    }

    public async Task<List<StudyQuestion>> GenerateQuestionsFromDocument(
        LegalDocument document,
        int questionCount = 10,
        bool validateWithAI = true)
    {
        _logger.LogInformation(
    "🤖 Generando {Count} preguntas para documento: {DocumentTitle}",
    questionCount, document.Title);

        try
        {
            _logger.LogInformation(
                "Generando {Count} preguntas del documento {DocId}",
                questionCount, document.Id);

            var content = document.Content.Length > 3000
                ? document.Content.Substring(0, 3000)
                : document.Content;

            var multipleChoiceCount = (int)(questionCount * 0.7);
            var trueFalseCount = questionCount - multipleChoiceCount;

            var mcQuestions = await GenerateMultipleChoiceQuestions(
                content, document, multipleChoiceCount);

            var tfQuestions = await GenerateTrueFalseQuestions(
                content, document, trueFalseCount);

            var allQuestions = mcQuestions.Concat(tfQuestions).ToList();

            _logger.LogInformation(
                "Generadas {Total} preguntas",
                allQuestions.Count);

            return allQuestions;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas del documento");
            throw;
        }
    }

    public async Task<List<StudyQuestion>> GenerateRandomQuestions(
        List<string> legalAreas,
        DifficultyLevel difficulty,
        int count = 10)
    {
        try
        {
            _logger.LogInformation(
                "Generando {Count} preguntas aleatorias",
                count);

            var searchQuery = string.Join(" ", legalAreas);

            var relevantDocs = await _vectorService.SearchSimilarAsync(searchQuery, limit: 3);

            if (!relevantDocs.Any())
            {
                _logger.LogWarning("No se encontraron documentos relevantes");
                return new List<StudyQuestion>();
            }

            var content = string.Join("\n\n", relevantDocs.Select(d => d.Content));

            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: legalAreas.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.MultipleChoice,
                difficulty: difficulty,
                count: count);

            return ParseQuestionResponse<MultipleChoiceResponse>(
                questionsJson,
                legalAreas.FirstOrDefault() ?? "Derecho General",
                difficulty,
                Guid.NewGuid());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas aleatorias");
            return new List<StudyQuestion>();
        }
    }

    public async Task<StudyQuestion> GenerateFollowUpQuestion(
        StudyQuestion previousQuestion,
        bool wasCorrect)
    {
        try
        {
            var difficulty = wasCorrect
                ? IncreaseDifficulty(previousQuestion.Difficulty)
                : DecreaseDifficulty(previousQuestion.Difficulty);

            var relatedConcepts = string.Join(", ", previousQuestion.RelatedConcepts);

            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: $"Conceptos: {relatedConcepts}\nPregunta anterior: {previousQuestion.QuestionText}",
                legalArea: previousQuestion.LegalArea,
                type: previousQuestion.Type,
                difficulty: difficulty,
                count: 1);

            var questions = ParseQuestionResponse<MultipleChoiceResponse>(
                questionsJson,
                previousQuestion.LegalArea,
                difficulty,
                previousQuestion.SourceDocumentIds.FirstOrDefault());

            return questions.FirstOrDefault() ?? previousQuestion;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando pregunta de seguimiento");
            return previousQuestion;
        }
    }

    public async Task<List<StudyQuestion>> GenerateAndSaveQuestionsAsync(
        string documentContent,
        List<string> legalAreas,
        DifficultyLevel difficulty,
        int count = 10)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: documentContent,
                legalArea: legalAreas.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.MultipleChoice,
                difficulty: difficulty,
                count: count);

            var questions = ParseQuestionResponse<MultipleChoiceResponse>(
                questionsJson,
                legalAreas.FirstOrDefault() ?? "Derecho General",
                difficulty,
                Guid.NewGuid());

            return questions;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando y guardando preguntas");
            throw;
        }
    }

    /// <summary>
    /// 🆕 Genera N preguntas × 3 tipos × 3 niveles = N × 9 preguntas totales
    /// Ejemplo: Si N=2, genera 2×3×3 = 18 preguntas
    /// </summary>
    public async Task<List<StudyQuestion>> GenerateQuestionsWithMixedDifficulty(
        LegalDocument document,
        int questionsPerCombination)
    {
        try
        {
            var totalExpected = questionsPerCombination * 3 * 3; // tipos × niveles

            _logger.LogInformation(
                "🎯 Generando {N} preguntas × 3 tipos × 3 niveles = {Total} preguntas totales para documento {DocId}",
                questionsPerCombination, totalExpected, document.Id);

            var content = document.Content.Length > 5000
                ? document.Content.Substring(0, 5000)
                : document.Content;

            var allQuestions = new List<StudyQuestion>();

            // Definir los 3 niveles
            var levels = new[]
            {
            DifficultyLevel.Basic,
            DifficultyLevel.Intermediate,
            DifficultyLevel.Advanced
        };

            // Definir los 3 tipos
            var types = new[]
            {
            QuestionType.TrueFalse,
            QuestionType.MultipleChoice,
            QuestionType.OpenEnded
        };

            // Generar para cada combinación de nivel y tipo
            foreach (var level in levels)
            {
                foreach (var type in types)
                {
                    try
                    {
                        _logger.LogInformation(
                            "📝 Generando {Count} preguntas de tipo {Type}, nivel {Level}",
                            questionsPerCombination, type, level);

                        var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                            sourceText: content,
                            legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                            type: type,
                            difficulty: level,
                            count: questionsPerCombination);

                        List<StudyQuestion> questions;

                        if (type == QuestionType.MultipleChoice)
                        {
                            questions = ParseQuestionResponse<MultipleChoiceResponse>(
                                questionsJson,
                                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                                level,
                                document.Id);
                        }
                        else if (type == QuestionType.TrueFalse)
                        {
                            questions = ParseQuestionResponse<TrueFalseResponse>(
                                questionsJson,
                                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                                level,
                                document.Id);
                        }
                        else // OpenEnded
                        {
                            questions = ParseQuestionResponse<OpenEndedResponse>(
                                questionsJson,
                                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                                level,
                                document.Id);
                        }

                        if (questions.Any())
                        {
                            allQuestions.AddRange(questions);
                            _logger.LogInformation(
                                "✅ Generadas {Count} preguntas de {Type}/{Level}",
                                questions.Count, type, level);
                        }
                        else
                        {
                            _logger.LogWarning(
                                "⚠️ No se generaron preguntas para {Type}/{Level}",
                                type, level);
                        }

                        // Pequeño delay entre llamadas para evitar rate limiting
                        await Task.Delay(500);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(ex,
                            "❌ Error generando preguntas {Type}/{Level}",
                            type, level);
                    }
                }
            }

            _logger.LogInformation(
                "✅ TOTAL GENERADO: {Generated}/{Expected} preguntas " +
                "({Basic} básicas, {Intermediate} intermedias, {Advanced} avanzadas)",
                allQuestions.Count,
                totalExpected,
                allQuestions.Count(q => q.Difficulty == DifficultyLevel.Basic),
                allQuestions.Count(q => q.Difficulty == DifficultyLevel.Intermediate),
                allQuestions.Count(q => q.Difficulty == DifficultyLevel.Advanced));

            return allQuestions;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error en GenerateQuestionsWithMixedDifficulty");
            return new List<StudyQuestion>();
        }
    }

    /// <summary>
    /// 🆕 Genera preguntas para UN NIVEL específico, intentando balancear tipos
    /// </summary>
    private async Task<List<StudyQuestion>> GenerateQuestionsForLevelBalanced(
        string content,
        LegalDocument document,
        int targetCount,
        DifficultyLevel level,
        Dictionary<QuestionType, double> typeDistribution)
    {
        var levelQuestions = new List<StudyQuestion>();

        // Calcular cuántas preguntas de cada tipo se necesitan
        var targetByType = new Dictionary<QuestionType, int>();
        int assigned = 0;

        foreach (var kvp in typeDistribution.OrderByDescending(x => x.Value))
        {
            int count = (int)Math.Round(targetCount * kvp.Value);

            // Asegurar que no nos pasemos del target
            if (assigned + count > targetCount)
                count = targetCount - assigned;

            targetByType[kvp.Key] = count;
            assigned += count;
        }

        // Si quedaron preguntas sin asignar por redondeo, asignar a MultipleChoice
        if (assigned < targetCount)
        {
            targetByType[QuestionType.MultipleChoice] += (targetCount - assigned);
        }

        _logger.LogInformation(
            "📊 Nivel {Level}: {MC} MC, {TF} V/F, {OE} Desarrollo",
            level,
            targetByType.GetValueOrDefault(QuestionType.MultipleChoice, 0),
            targetByType.GetValueOrDefault(QuestionType.TrueFalse, 0),
            targetByType.GetValueOrDefault(QuestionType.OpenEnded, 0));

        // ═══════════════════════════════════════════════════════════
        // 🔄 GENERAR POR TIPO
        // ═══════════════════════════════════════════════════════════

        foreach (var kvp in targetByType.Where(x => x.Value > 0))
        {
            var type = kvp.Key;
            var count = kvp.Value;

            try
            {
                _logger.LogInformation(
                    "🎯 Intentando generar {Count} preguntas de tipo {Type} nivel {Level}...",
                    count, type, level);

                var typeQuestions = await GenerateQuestionsOfTypeSafe(
                    content, document, count, type, level);

                if (typeQuestions.Any())
                {
                    levelQuestions.AddRange(typeQuestions);
                    _logger.LogInformation(
                        "✅ {Generated}/{Target} preguntas {Type} generadas",
                        typeQuestions.Count, count, type);
                }
                else
                {
                    _logger.LogWarning(
                        "⚠️ No se pudieron generar preguntas {Type} - posible falta de contenido",
                        type);
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex,
                    "⚠️ Error generando preguntas {Type} nivel {Level} - continuando con otros tipos",
                    type, level);
            }
        }

        return levelQuestions;
    }

    /// <summary>
    /// 🆕 Genera preguntas de un tipo específico de forma SEGURA (sin lanzar excepciones)
    /// </summary>
    private async Task<List<StudyQuestion>> GenerateQuestionsOfTypeSafe(
        string content,
        LegalDocument document,
        int count,
        QuestionType type,
        DifficultyLevel difficulty)
    {
        const int MAX_RETRIES = 2;

        for (int retry = 0; retry <= MAX_RETRIES; retry++)
        {
            try
            {
                var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                    sourceText: content,
                    legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                    type: type,
                    difficulty: difficulty,
                    count: count
                );

                List<StudyQuestion> questions;

                if (type == QuestionType.MultipleChoice)
                {
                    questions = ParseQuestionResponse<MultipleChoiceResponse>(
                        questionsJson,
                        document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                        difficulty,
                        document.Id
                    );
                }
                else if (type == QuestionType.TrueFalse)
                {
                    questions = ParseQuestionResponse<TrueFalseResponse>(
                        questionsJson,
                        document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                        difficulty,
                        document.Id
                    );
                }
                else // OpenEnded
                {
                    questions = ParseQuestionResponse<OpenEndedResponse>(
                        questionsJson,
                        document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                        difficulty,
                        document.Id
                    );
                }

                if (questions.Any())
                {
                    return questions;
                }

                _logger.LogWarning(
                    "⚠️ Intento {Retry}: No se generaron preguntas válidas para {Type} {Level}",
                    retry + 1, type, difficulty);

                if (retry < MAX_RETRIES)
                {
                    await Task.Delay(1000); // Esperar 1 segundo antes de reintentar
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex,
                    "⚠️ Intento {Retry}: Error generando {Type} {Level}",
                    retry + 1, type, difficulty);

                if (retry < MAX_RETRIES)
                {
                    await Task.Delay(1000);
                }
            }
        }

        // Si llegamos aquí, no se pudo generar nada después de MAX_RETRIES
        _logger.LogWarning(
            "❌ No se pudieron generar preguntas {Type} {Level} después de {Retries} intentos",
            type, difficulty, MAX_RETRIES + 1);

        return new List<StudyQuestion>();
    }

    private async Task<List<StudyQuestion>> GenerateMultipleChoiceQuestions(
        string content,
        LegalDocument document,
        int count)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.MultipleChoice,
                difficulty: document.Difficulty,
                count: count);

            return ParseQuestionResponse<MultipleChoiceResponse>(
                questionsJson,
                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                document.Difficulty,
                document.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas múltiple choice");
            return new List<StudyQuestion>();
        }
    }

    private async Task<List<StudyQuestion>> GenerateTrueFalseQuestions(
        string content,
        LegalDocument document,
        int count)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.TrueFalse,
                difficulty: document.Difficulty,
                count: count);

            return ParseQuestionResponse<TrueFalseResponse>(
                questionsJson,
                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                document.Difficulty,
                document.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas verdadero/falso");
            return new List<StudyQuestion>();
        }
    }

    private async Task<List<StudyQuestion>> GenerateOpenEndedQuestions(
        string content,
        LegalDocument document,
        int count)
    {
        try
        {
            var questionsJson = await _aiService.GenerateStructuredQuestionsAsync(
                sourceText: content,
                legalArea: document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                type: QuestionType.OpenEnded,
                difficulty: document.Difficulty,
                count: count);

            return ParseQuestionResponse<OpenEndedResponse>(
                questionsJson,
                document.TemaNombres?.FirstOrDefault() ?? "Derecho General",
                document.Difficulty,
                document.Id);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error generando preguntas de desarrollo");
            return new List<StudyQuestion>();
        }
    }

    private List<StudyQuestion> ParseQuestionResponse<T>(
        string jsonResponse,
        string legalArea,
        DifficultyLevel difficulty,
        Guid documentId)
    {
        try
        {
            _logger.LogDebug("📝 JSON recibido (primeros 500 chars):\n{Json}",
                jsonResponse.Substring(0, Math.Min(500, jsonResponse.Length)));

            string cleanedJson = CleanAndValidateJson(jsonResponse);

            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };

            if (typeof(T) == typeof(MultipleChoiceResponse))
            {
                var response = JsonSerializer.Deserialize<MultipleChoiceResponse>(
                    cleanedJson, options);

                return response?.Questions?.Select(q =>
                {
                    // Crear opciones
                    var questionOptions = q.Options.Select(o => new QuestionOption
                    {
                        Id = Guid.NewGuid(),
                        Text = o.Text,
                        IsCorrect = o.IsCorrect
                    }).ToList();

                    // ✅ RANDOMIZAR OPCIONES para evitar que siempre sea B
                    var randomizedOptions = RandomizeOptions(questionOptions);

                    return new StudyQuestion
                    {
                        Id = Guid.NewGuid(),
                        SourceDocumentIds = new List<Guid> { documentId },
                        QuestionText = q.QuestionText,
                        Type = QuestionType.MultipleChoice,
                        Difficulty = difficulty,
                        LegalArea = legalArea,
                        Options = randomizedOptions,
                        CorrectAnswer = randomizedOptions.First(o => o.IsCorrect).Text,
                        Explanation = q.Explanation,
                        RelatedConcepts = q.RelatedConcepts ?? new List<string>(),
                        CreatedAt = DateTime.UtcNow,
                        IsActive = true
                    };
                }).ToList() ?? new List<StudyQuestion>();
            }

            else if (typeof(T) == typeof(TrueFalseResponse))
            {
                var response = JsonSerializer.Deserialize<TrueFalseResponse>(
                    cleanedJson, options);

                return response?.Questions?.Select(q => new StudyQuestion
                {
                    Id = Guid.NewGuid(),
                    SourceDocumentIds = new List<Guid> { documentId },
                    QuestionText = q.QuestionText,
                    Type = QuestionType.TrueFalse,
                    Difficulty = difficulty,
                    LegalArea = legalArea,
                    IsTrue = q.IsTrue,
                    CorrectAnswer = q.IsTrue ? "Verdadero" : "Falso",
                    Explanation = q.Explanation,
                    RelatedConcepts = q.RelatedConcepts ?? new List<string>(),
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                }).ToList() ?? new List<StudyQuestion>();
            }
            else if (typeof(T) == typeof(OpenEndedResponse))
            {
                var response = JsonSerializer.Deserialize<OpenEndedResponse>(
                    cleanedJson, options);

                return response?.Questions?.Select(q => new StudyQuestion
                {
                    Id = Guid.NewGuid(),
                    SourceDocumentIds = new List<Guid> { documentId },
                    QuestionText = q.QuestionText,
                    Type = QuestionType.OpenEnded,
                    Difficulty = difficulty,
                    LegalArea = legalArea,
                    Options = new List<QuestionOption>(),
                    CorrectAnswer = q.ModelAnswer,
                    Explanation = q.Explanation,
                    RelatedConcepts = q.RelatedConcepts ?? new List<string>(),
                    CreatedAt = DateTime.UtcNow,
                    IsActive = true
                }).ToList() ?? new List<StudyQuestion>();
            }

            return new List<StudyQuestion>();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error parseando respuesta JSON");
            _logger.LogError("JSON que causó el error:\n{Json}", jsonResponse);
            return new List<StudyQuestion>();
        }
    }

    private string CleanAndValidateJson(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
            return "{}";

        var start = json.IndexOf('{');
        var end = json.LastIndexOf('}');

        if (start < 0 || end < 0 || end <= start)
        {
            _logger.LogWarning("⚠️ No se pudo encontrar JSON válido en la respuesta");
            return "{}";
        }

        var extracted = json.Substring(start, end - start + 1);

        int openBraces = extracted.Count(c => c == '{');
        int closeBraces = extracted.Count(c => c == '}');
        int openBrackets = extracted.Count(c => c == '[');
        int closeBrackets = extracted.Count(c => c == ']');

        if (openBraces != closeBraces || openBrackets != closeBrackets)
        {
            _logger.LogWarning("⚠️ JSON desbalanceado: {{={0}, }}={1}, [={2}, ]={3}",
                openBraces, closeBraces, openBrackets, closeBrackets);

            while (openBraces > closeBraces)
            {
                extracted += "}";
                closeBraces++;
            }
            while (openBrackets > closeBrackets)
            {
                extracted += "]";
                closeBrackets++;
            }
        }

        return extracted;
    }

    private DifficultyLevel IncreaseDifficulty(DifficultyLevel current)
    {
        return current switch
        {
            DifficultyLevel.Basic => DifficultyLevel.Intermediate,
            DifficultyLevel.Intermediate => DifficultyLevel.Advanced,
            DifficultyLevel.Advanced => DifficultyLevel.Advanced,
            _ => current
        };
    }

    private DifficultyLevel DecreaseDifficulty(DifficultyLevel current)
    {
        return current switch
        {
            DifficultyLevel.Advanced => DifficultyLevel.Intermediate,
            DifficultyLevel.Intermediate => DifficultyLevel.Basic,
            DifficultyLevel.Basic => DifficultyLevel.Basic,
            _ => current
        };
    }
    /// <summary>
    /// Randomiza el orden de las opciones para evitar patrones predecibles
    /// </summary>
    private List<QuestionOption> RandomizeOptions(List<QuestionOption> options)
    {
        if (options == null || options.Count <= 1)
            return options;

        var random = new Random();
        return options.OrderBy(_ => random.Next()).ToList();
    }
}
*/