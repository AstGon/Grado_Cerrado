﻿// src/GradoCerrado.Infrastructure/Services/HybridGeminiValidationService.cs
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using GradoCerrado.Application.DTOs;
using GradoCerrado.Application.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace GradoCerrado.Infrastructure.Services;

/// <summary>
/// Servicio híbrido que combina:
/// 1. Extracción inteligente de contexto (estrategia principal)
/// 2. Resumen con Gemini (para casos extremos)
/// 3. Procesamiento por lotes para múltiples validaciones
/// </summary>
public class HybridGeminiValidationService : IQuestionValidationService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<HybridGeminiValidationService> _logger;
    private readonly string _apiKey;
    private readonly string _model;
    private readonly GeminiRateLimiter _rateLimiter;
    private readonly GeminiDocumentSummarizer? _summarizer;

    // Configuración adaptativa
    private const int OPTIMAL_SIZE = 6000;           // Tamaño óptimo para validación
    private const int MAX_SIZE_BEFORE_SUMMARY = 50000; // Umbral para activar resumen
    private const int ABSOLUTE_MAX_SIZE = 30000;     // Límite absoluto de Gemini

    public HybridGeminiValidationService(
        HttpClient httpClient,
        IConfiguration configuration,
        ILogger<HybridGeminiValidationService> logger,
        GeminiRateLimiter rateLimiter,
        GeminiDocumentSummarizer? summarizer = null)
    {
        _httpClient = httpClient;
        _logger = logger;
        _rateLimiter = rateLimiter;
        _summarizer = summarizer;

        _apiKey = configuration["Gemini:ApiKey"]
            ?? throw new InvalidOperationException("Gemini API Key no configurada");
        _model = configuration["Gemini:Model"] ?? "gemini-1.5-pro";

        _logger.LogInformation("🔧 Hybrid Gemini Validation Service inicializado");
    }

    public async Task<ValidationResult> ValidateQuestionAsync(
        string chunkContent,
        string questionText,
        string expectedAnswer)
    {
        try
        {
            _logger.LogDebug("🔍 Validando: {Question}",
                questionText.Substring(0, Math.Min(50, questionText.Length)));

            // 🎯 ESTRATEGIA ADAPTATIVA
            var processedContent = await PrepareContentForValidationAsync(
                chunkContent,
                questionText,
                expectedAnswer);

            _logger.LogDebug(
                "📏 Original: {Original} → Procesado: {Processed} chars (reducción: {Percent}%)",
                chunkContent?.Length ?? 0,
                processedContent.Length,
                chunkContent?.Length > 0
                    ? Math.Round((1 - (double)processedContent.Length / chunkContent.Length) * 100, 1)
                    : 0);

            // Construir y ejecutar validación
            var prompt = BuildValidationPrompt(
                processedContent,
                questionText,
                expectedAnswer);

            var response = await CallGeminiWithRetryAsync(prompt);
            var result = ParseValidationResponse(response);

            _logger.LogDebug(
                "✅ Validación: Válida={IsValid}, Relevancia={Score:F2}",
                result.IsValid, result.Scores.QuestionRelevance);

            return result;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error en validación");
            return CreateErrorResult($"Error: {ex.Message}");
        }
    }

    /// <summary>
    /// Prepara el contenido usando la estrategia más apropiada
    /// </summary>
    private async Task<string> PrepareContentForValidationAsync(
        string content,
        string questionText,
        string expectedAnswer)
    {
        if (string.IsNullOrWhiteSpace(content))
            return string.Empty;

        var contentLength = content.Length;

        // ✅ ESTRATEGIA 1: Contenido ya óptimo
        if (contentLength <= OPTIMAL_SIZE)
        {
            _logger.LogDebug("✅ Contenido óptimo ({Length} chars)", contentLength);
            return content;
        }

        // ✅ ESTRATEGIA 2: Extracción inteligente (rápido, sin API)
        if (contentLength <= MAX_SIZE_BEFORE_SUMMARY)
        {
            _logger.LogDebug("🎯 Aplicando extracción inteligente...");
            return ExtractRelevantContext(content, questionText, expectedAnswer);
        }

        // ✅ ESTRATEGIA 3: Resumen con Gemini (para casos extremos)
        if (_summarizer != null && contentLength > MAX_SIZE_BEFORE_SUMMARY)
        {
            _logger.LogInformation(
                "📝 Contenido muy grande ({Length} chars). Generando resumen inteligente...",
                contentLength);

            var questionContext = $"{questionText} | {expectedAnswer}";
            var summary = await _summarizer.SummarizeForValidationAsync(content, questionContext);

            // Si el resumen aún es grande, aplicar extracción
            if (summary.Length > OPTIMAL_SIZE)
            {
                return ExtractRelevantContext(summary, questionText, expectedAnswer);
            }

            return summary;
        }

        // ⚠️ FALLBACK: Truncar inteligentemente
        _logger.LogWarning(
            "⚠️ Usando fallback de truncamiento para {Length} chars",
            contentLength);
        return TruncateIntelligently(content, OPTIMAL_SIZE);
    }

    /// <summary>
    /// Extrae el contexto más relevante basándose en keywords
    /// </summary>
    private string ExtractRelevantContext(
        string content,
        string questionText,
        string expectedAnswer)
    {
        // Extraer keywords de la pregunta y respuesta
        var keywords = ExtractKeywords(questionText + " " + expectedAnswer);

        if (!keywords.Any())
        {
            _logger.LogDebug("⚠️ No se encontraron keywords. Usando inicio del documento.");
            return TruncateIntelligently(content, OPTIMAL_SIZE);
        }

        // Dividir en secciones (párrafos o chunks fijos)
        var sections = SplitIntoSections(content);

        // Puntuar cada sección por relevancia
        var scoredSections = sections
            .Select((section, index) => new
            {
                Section = section,
                Score = CalculateRelevanceScore(section, keywords),
                Index = index
            })
            .Where(x => x.Score > 0)
            .OrderByDescending(x => x.Score)
            .ToList();

        if (!scoredSections.Any())
        {
            _logger.LogDebug("⚠️ No se encontraron secciones relevantes.");
            return TruncateIntelligently(content, OPTIMAL_SIZE);
        }

        // Construir resultado con las secciones más relevantes
        var result = new StringBuilder();
        var addedIndices = new HashSet<int>();

        foreach (var item in scoredSections)
        {
            if (result.Length + item.Section.Length > OPTIMAL_SIZE)
                break;

            result.Append(item.Section).Append("\n\n");
            addedIndices.Add(item.Index);
        }

        // Agregar contexto adicional de secciones adyacentes si hay espacio
        if (result.Length < OPTIMAL_SIZE * 0.8 && scoredSections.Any())
        {
            var topIndex = scoredSections[0].Index;

            // Intentar agregar sección anterior
            if (topIndex > 0 && !addedIndices.Contains(topIndex - 1))
            {
                var prevSection = sections[topIndex - 1];
                if (result.Length + prevSection.Length <= OPTIMAL_SIZE)
                {
                    result.Insert(0, prevSection + "\n\n");
                }
            }

            // Intentar agregar sección siguiente
            if (topIndex < sections.Count - 1 && !addedIndices.Contains(topIndex + 1))
            {
                var nextSection = sections[topIndex + 1];
                if (result.Length + nextSection.Length <= OPTIMAL_SIZE)
                {
                    result.Append(nextSection).Append("\n\n");
                }
            }
        }

        return result.ToString().Trim();
    }

    private List<string> ExtractKeywords(string text)
    {
        var stopwords = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "el", "la", "los", "las", "un", "una", "de", "del", "al", "en", "por",
            "para", "con", "sin", "sobre", "qué", "cuál", "cómo", "es", "son",
            "está", "están", "que", "se", "su", "sus", "y", "o", "pero"
        };

        return text
            .Split(new[] { ' ', ',', '.', ';', ':', '?', '¿', '!', '¡', '\n' },
                   StringSplitOptions.RemoveEmptyEntries)
            .Where(w => w.Length >= 4 && !stopwords.Contains(w))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    private List<string> SplitIntoSections(string content)
    {
        // Intentar dividir por párrafos
        var paragraphs = content
            .Split(new[] { "\n\n", "\r\n\r\n" }, StringSplitOptions.RemoveEmptyEntries)
            .Where(p => p.Trim().Length > 50)
            .ToList();

        // Si hay pocos párrafos, dividir en chunks de tamaño fijo
        if (paragraphs.Count < 3)
        {
            var chunkSize = 1000;
            paragraphs.Clear();
            for (int i = 0; i < content.Length; i += chunkSize)
            {
                var length = Math.Min(chunkSize, content.Length - i);
                paragraphs.Add(content.Substring(i, length));
            }
        }

        return paragraphs;
    }

    private int CalculateRelevanceScore(string section, List<string> keywords)
    {
        var sectionLower = section.ToLowerInvariant();
        var score = 0;

        foreach (var keyword in keywords)
        {
            var keywordLower = keyword.ToLowerInvariant();
            var count = CountOccurrences(sectionLower, keywordLower);
            score += Math.Min(count * 10, 30); // Max 30 puntos por keyword
        }

        return score;
    }

    private int CountOccurrences(string text, string substring)
    {
        if (string.IsNullOrEmpty(text) || string.IsNullOrEmpty(substring))
            return 0;

        int count = 0;
        int index = 0;

        while ((index = text.IndexOf(substring, index, StringComparison.OrdinalIgnoreCase)) != -1)
        {
            count++;
            index += substring.Length;
        }

        return count;
    }

    private string TruncateIntelligently(string content, int maxLength)
    {
        if (content.Length <= maxLength)
            return content;

        var truncated = content.Substring(0, maxLength);

        // Buscar último punto para no cortar oraciones
        var lastPeriod = truncated.LastIndexOfAny(new[] { '.', '!', '?', '\n' });
        if (lastPeriod > maxLength / 2)
        {
            truncated = truncated.Substring(0, lastPeriod + 1);
        }

        return truncated + "\n\n[... contenido adicional omitido para optimizar procesamiento ...]";
    }

    private string BuildValidationPrompt(
        string content,
        string questionText,
        string expectedAnswer)
    {
        bool isTrueFalse = IsTrueFalseQuestion(expectedAnswer);

        var validation = isTrueFalse
            ? "Verdadero/Falso: verificar afirmación directamente en contenido"
            : "Múltiple: verificar respuesta correcta en contenido (distractores no necesitan estarlo)";

        return $@"CONTENIDO:
{content}

PREGUNTA: {questionText}
RESPUESTA: {expectedAnswer}

TIPO: {validation}

JSON minificado:
{{""is_valid"":bool,""scores"":{{""question_relevance"":0-1,""question_quality"":0-1,""answer_correctness"":0-1,""answer_coherence"":0-1,""overall_coherence"":0-1}},""issues"":[],""recommendations"":[],""feedback"":"""",""should_regenerate"":bool}}

Límites: issues/recommendations ≤2, feedback ≤150 chars.";
    }

    private bool IsTrueFalseQuestion(string answer)
    {
        var answerLower = answer?.ToLowerInvariant() ?? "";
        return answerLower == "verdadero" || answerLower == "falso" ||
               answerLower == "true" || answerLower == "false";
    }

    private async Task<string> CallGeminiWithRetryAsync(string prompt)
    {
        var url = $"https://generativelanguage.googleapis.com/v1/models/{_model}:generateContent?key={_apiKey}";

        var requestBody = new
        {
            contents = new[]
            {
                new
                {
                    parts = new[] { new { text = $"Responde SOLO JSON minificado:\n\n{prompt}" } }
                }
            },
            generationConfig = new
            {
                temperature = 0.2,
                maxOutputTokens = 1536,
                topP = 0.8,
                topK = 40
            }
        };

        const int MAX_RETRIES = 3;

        for (int attempt = 0; attempt <= MAX_RETRIES; attempt++)
        {
            try
            {
                await _rateLimiter.WaitIfNeededAsync();

                var json = JsonSerializer.Serialize(requestBody);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync(url, content);
                var responseContent = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    if ((int)response.StatusCode == 429 && attempt < MAX_RETRIES)
                    {
                        var delay = (int)Math.Pow(2, attempt + 1) * 1000;
                        _logger.LogWarning("⏳ Rate limit. Reintentando en {Delay}ms...", delay);
                        await Task.Delay(delay);
                        continue;
                    }

                    throw new HttpRequestException($"Error {response.StatusCode}: {responseContent}");
                }

                var jsonDoc = JsonDocument.Parse(responseContent);
                return ExtractGeminiText(jsonDoc.RootElement);
            }
            catch (TaskCanceledException) when (attempt < MAX_RETRIES)
            {
                var delay = (int)Math.Pow(2, attempt) * 500;
                _logger.LogWarning("⏳ Timeout. Reintentando en {Delay}ms...", delay);
                await Task.Delay(delay);
            }
        }

        throw new Exception("Max retries alcanzados");
    }

    private string ExtractGeminiText(JsonElement root)
    {
        if (root.TryGetProperty("candidates", out var candidates) &&
            candidates.ValueKind == JsonValueKind.Array &&
            candidates.GetArrayLength() > 0)
        {
            var first = candidates[0];
            if (first.TryGetProperty("content", out var content) &&
                content.TryGetProperty("parts", out var parts) &&
                parts.ValueKind == JsonValueKind.Array &&
                parts.GetArrayLength() > 0)
            {
                if (parts[0].TryGetProperty("text", out var text))
                    return text.GetString() ?? "";
            }
        }
        return "";
    }

    public ValidationResult ParseValidationResponse(string jsonResponse)
    {
        jsonResponse = CleanJsonFences(jsonResponse);

        if (string.IsNullOrWhiteSpace(jsonResponse))
            return CreateErrorResult("Respuesta vacía");

        if (!jsonResponse.TrimStart().StartsWith("{"))
            jsonResponse = ExtractJsonSubstring(jsonResponse);

        try
        {
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
                AllowTrailingCommas = true,
                Converters = { new JsonStringEnumConverter() }
            };

            var response = JsonSerializer.Deserialize<GeminiValidationResponse>(jsonResponse, options);

            if (response == null)
                return CreateErrorResult("Deserialización falló");

            return new ValidationResult
            {
                IsValid = response.IsValid,
                Scores = new ValidationScores
                {
                    QuestionRelevance = response.Scores?.QuestionRelevance ?? 0,
                    QuestionQuality = response.Scores?.QuestionQuality ?? 0,
                    AnswerCorrectness = response.Scores?.AnswerCorrectness ?? 0,
                    AnswerCoherence = response.Scores?.AnswerCoherence ?? 0,
                    OverallCoherence = response.Scores?.OverallCoherence ?? 0
                },
                Issues = response.Issues ?? new List<string>(),
                Recommendations = response.Recommendations ?? new List<string>(),
                Feedback = response.Feedback ?? "",
                ShouldRegenerate = response.ShouldRegenerate,
                ValidatedAt = DateTime.UtcNow
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error parseando JSON");
            return CreateErrorResult($"Parse error: {ex.Message}");
        }
    }

    private ValidationResult CreateErrorResult(string message)
    {
        return new ValidationResult
        {
            IsValid = false,
            Scores = new ValidationScores(),
            Issues = new List<string> { message },
            Recommendations = new List<string> { "Revisar manualmente" },
            Feedback = "Error de validación",
            ShouldRegenerate = true,
            ValidatedAt = DateTime.UtcNow
        };
    }

    private static string CleanJsonFences(string s)
    {
        return string.IsNullOrWhiteSpace(s) ? "" :
            s.Trim()
             .Replace("```json", "", StringComparison.OrdinalIgnoreCase)
             .Replace("```", "")
             .Trim();
    }

    private static string ExtractJsonSubstring(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return "";
        int start = s.IndexOf('{');
        int end = s.LastIndexOf('}');
        return (start >= 0 && end > start) ? s.Substring(start, end - start + 1) : "";
    }

    private class GeminiValidationResponse
    {
        [JsonPropertyName("is_valid")]
        public bool IsValid { get; set; }

        [JsonPropertyName("scores")]
        public GeminiScores? Scores { get; set; }

        [JsonPropertyName("issues")]
        public List<string>? Issues { get; set; }

        [JsonPropertyName("recommendations")]
        public List<string>? Recommendations { get; set; }

        [JsonPropertyName("feedback")]
        public string? Feedback { get; set; }

        [JsonPropertyName("should_regenerate")]
        public bool ShouldRegenerate { get; set; }
    }

    private class GeminiScores
    {
        [JsonPropertyName("question_relevance")]
        public decimal QuestionRelevance { get; set; }

        [JsonPropertyName("question_quality")]
        public decimal QuestionQuality { get; set; }

        [JsonPropertyName("answer_correctness")]
        public decimal AnswerCorrectness { get; set; }

        [JsonPropertyName("answer_coherence")]
        public decimal AnswerCoherence { get; set; }

        [JsonPropertyName("overall_coherence")]
        public decimal OverallCoherence { get; set; }
    }
}