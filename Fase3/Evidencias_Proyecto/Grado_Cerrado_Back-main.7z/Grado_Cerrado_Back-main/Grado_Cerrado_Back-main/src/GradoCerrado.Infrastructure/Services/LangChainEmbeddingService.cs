﻿// 📁 src/GradoCerrado.Infrastructure/Services/LangChainEmbeddingService.cs
// VERSIÓN OPTIMIZADA PARA DOCUMENTOS GRANDES

using GradoCerrado.Application.Interfaces;
using GradoCerrado.Infrastructure.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using LangChain.Providers.OpenAI;

namespace GradoCerrado.Infrastructure.Services;

public class LangChainEmbeddingService : IEmbeddingService
{
    private readonly OpenAiProvider _provider;
    private readonly OpenAISettings _settings;
    private readonly ILogger<LangChainEmbeddingService> _logger;
    private readonly IRateLimiter _rateLimiter;

    // 🎯 CONFIGURACIÓN OPTIMIZADA
    private const int OPTIMAL_BATCH_SIZE = 50;    // OpenAI soporta hasta 2048, pero 50 es más seguro
    private const int MAX_TOKENS_PER_REQUEST = 8000;
    private const int DELAY_BETWEEN_BATCHES_MS = 500; // Medio segundo entre lotes

    public LangChainEmbeddingService(
        IOptions<OpenAISettings> settings,
        ILogger<LangChainEmbeddingService> logger,
        IRateLimiter rateLimiter)
    {
        _settings = settings.Value;
        _logger = logger;
        _rateLimiter = rateLimiter;
        _provider = new OpenAiProvider(_settings.ApiKey);
    }

    public async Task<float[]> GenerateEmbeddingAsync(string text)
    {
        try
        {
            await _rateLimiter.WaitIfNeededAsync();

            var embeddingModel = new OpenAiEmbeddingModel(
                provider: _provider,
                id: "text-embedding-3-small"); // 🆕 Modelo más nuevo y barato

            var response = await embeddingModel.CreateEmbeddingsAsync(text);
            _rateLimiter.RecordRequest();

            return response.Values.First().ToArray();
        }
        catch (Exception ex)
        {
            _rateLimiter.RecordError();
            _logger.LogError(ex, "❌ Error generando embedding");
            throw;
        }
    }

    /// <summary>
    /// 🚀 MÉTODO OPTIMIZADO PARA DOCUMENTOS GRANDES
    /// Procesa cientos de chunks eficientemente
    /// </summary>
    public async Task<List<float[]>> GenerateEmbeddingsAsync(List<string> texts)
    {
        if (!texts.Any())
            return new List<float[]>();

        var startTime = DateTime.UtcNow;

        try
        {
            _logger.LogInformation(
                "🔢 INICIANDO vectorización de {Count} chunks...",
                texts.Count);

            // 🎯 ESTRATEGIA: Procesar en lotes inteligentes
            var batches = CreateOptimalBatches(texts);

            _logger.LogInformation(
                "📦 Dividido en {BatchCount} lotes (promedio: {Avg} chunks/lote)",
                batches.Count,
                texts.Count / Math.Max(batches.Count, 1));

            var allEmbeddings = new List<float[]>();
            var progressInterval = Math.Max(1, batches.Count / 10); // Log cada 10%

            for (int i = 0; i < batches.Count; i++)
            {
                var batch = batches[i];

                // ✅ Esperar slot disponible (rate limiting)
                await _rateLimiter.WaitIfNeededAsync();

                // 🚀 Procesar lote completo en UNA llamada
                var batchEmbeddings = await ProcessBatchAsync(batch, i + 1, batches.Count);

                allEmbeddings.AddRange(batchEmbeddings);

                _rateLimiter.RecordRequest();

                // 📊 Log de progreso
                if ((i + 1) % progressInterval == 0 || i == batches.Count - 1)
                {
                    var progress = (i + 1) * 100.0 / batches.Count;
                    var elapsed = (DateTime.UtcNow - startTime).TotalSeconds;
                    var eta = elapsed / (i + 1) * (batches.Count - i - 1);

                    _logger.LogInformation(
                        "⏳ Progreso: {Progress:F1}% ({Current}/{Total} lotes) - " +
                        "Embeddings: {Embeddings}/{Total} - ETA: {Eta:F0}s",
                        progress, i + 1, batches.Count,
                        allEmbeddings.Count, texts.Count, eta);
                }

                // ⏸️ Pausa entre lotes para evitar rate limits
                if (i < batches.Count - 1)
                {
                    await Task.Delay(DELAY_BETWEEN_BATCHES_MS);
                }
            }

            var totalTime = (DateTime.UtcNow - startTime).TotalSeconds;

            _logger.LogInformation(
                "✅ VECTORIZACIÓN COMPLETA: {Count} embeddings en {Time:F1}s " +
                "({Rate:F1} embeddings/seg)",
                allEmbeddings.Count, totalTime,
                allEmbeddings.Count / Math.Max(totalTime, 1));

            return allEmbeddings;
        }
        catch (Exception ex)
        {
            _rateLimiter.RecordError();
            _logger.LogError(ex, "❌ Error generando embeddings en lote");
            throw;
        }
    }

    /// <summary>
    /// Procesa un lote completo usando la API de OpenAI de forma óptima
    /// </summary>
    private async Task<List<float[]>> ProcessBatchAsync(
        List<string> batch,
        int batchNumber,
        int totalBatches)
    {
        try
        {
            var embeddingModel = new OpenAiEmbeddingModel(
                provider: _provider,
                id: "text-embedding-3-small"); // Más barato y rápido que ada-002

            _logger.LogDebug(
                "📦 Procesando lote {Current}/{Total} ({Count} textos)...",
                batchNumber, totalBatches, batch.Count);

            // 🚀 OPCIÓN 1: Si LangChain soporta batch nativo (IDEAL)
            // Intentar procesar todo el lote de una vez
            try
            {
                var batchText = string.Join("\n---\n", batch); // Concatenar
                var response = await embeddingModel.CreateEmbeddingsAsync(batchText);

                // Si solo devuelve 1 embedding, procesar individualmente
                if (response.Values.Count() == 1 && batch.Count > 1)
                {
                    return await ProcessBatchSequentiallyAsync(batch, embeddingModel);
                }

                return response.Values.Select(v => v.ToArray()).ToList();
            }
            catch
            {
                // Si falla el batch, procesar secuencialmente
                return await ProcessBatchSequentiallyAsync(batch, embeddingModel);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "❌ Error en lote {Batch}/{Total}",
                batchNumber, totalBatches);
            throw;
        }
    }

    /// <summary>
    /// Fallback: Procesa textos secuencialmente si batch falla
    /// </summary>
    private async Task<List<float[]>> ProcessBatchSequentiallyAsync(
        List<string> batch,
        OpenAiEmbeddingModel model)
    {
        var embeddings = new List<float[]>();

        foreach (var text in batch)
        {
            var response = await model.CreateEmbeddingsAsync(text);
            embeddings.Add(response.Values.First().ToArray());

            // Mini delay para no sobrecargar
            if (batch.Count > 1)
                await Task.Delay(100);
        }

        return embeddings;
    }

    /// <summary>
    /// 🎯 Crea lotes óptimos respetando límites de tokens y tamaño
    /// </summary>
    private List<List<string>> CreateOptimalBatches(List<string> texts)
    {
        var batches = new List<List<string>>();
        var currentBatch = new List<string>();
        var currentTokenCount = 0;

        foreach (var text in texts)
        {
            // Estimar tokens (1 token ≈ 4 caracteres para inglés/español)
            var estimatedTokens = EstimateTokens(text);

            // Verificar si agregar este texto excedería límites
            bool wouldExceedSize = currentBatch.Count >= OPTIMAL_BATCH_SIZE;
            bool wouldExceedTokens = currentTokenCount + estimatedTokens > MAX_TOKENS_PER_REQUEST;

            if (wouldExceedSize || wouldExceedTokens)
            {
                if (currentBatch.Any())
                {
                    batches.Add(currentBatch);
                    currentBatch = new List<string>();
                    currentTokenCount = 0;
                }
            }

            currentBatch.Add(text);
            currentTokenCount += estimatedTokens;
        }

        // Agregar último lote
        if (currentBatch.Any())
        {
            batches.Add(currentBatch);
        }

        return batches;
    }

    /// <summary>
    /// Estima tokens de forma conservadora
    /// </summary>
    private int EstimateTokens(string text)
    {
        if (string.IsNullOrEmpty(text))
            return 0;

        // Regla conservadora: 1 token ≈ 3.5 caracteres
        // (Es mejor subestimar para evitar errores)
        return (int)Math.Ceiling(text.Length / 3.5);
    }
}