﻿using GradoCerrado.Application.Interfaces;
using GradoCerrado.Domain.Entities;
using GradoCerrado.Domain.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Npgsql;
using System.Data;

namespace GradoCerrado.Infrastructure.Services;

public class QuestionPersistenceService : IQuestionPersistenceService
{
    private readonly GradocerradoContext _context;
    private readonly ILogger<QuestionPersistenceService> _logger;
    private readonly IContentClassifierService _contentClassifier;
    private readonly IVectorService _vectorService;

    public QuestionPersistenceService(
        GradocerradoContext context,
        ILogger<QuestionPersistenceService> logger,
        IContentClassifierService contentClassifier,
        IVectorService vectorService)
    {
        _context = context;
        _logger = logger;
        _contentClassifier = contentClassifier;
        _vectorService = vectorService;
    }

    /// <summary>
    /// 🆕 Guarda preguntas CLASIFICANDO cada una según sus fragmentos de contexto
    /// </summary>
    public async Task<List<int>> SaveQuestionsToDatabase(
        List<StudyQuestion> studyQuestions,
        int areaId,
        int? defaultTemaId = null,
        int? defaultSubtemaId = null,
        int modalidadId = 1,
        string creadaPor = "AI")
    {
        try
        {
            var savedIds = new List<int>();

            foreach (var question in studyQuestions)
            {
                // ═══════════════════════════════════════════════════════════
                // 🔍 CLASIFICAR LA PREGUNTA POR SUS FRAGMENTOS DE CONTEXTO
                // ═══════════════════════════════════════════════════════════

                int temaId = defaultTemaId ?? 0;
                int? subtemaId = defaultSubtemaId;

                // Si la pregunta tiene fragmentos de contexto, clasificarlos
                if (question.SourceChunkIds != null && question.SourceChunkIds.Any())
                {
                    try
                    {
                        // Obtener el contenido de los chunks
                        var chunkContents = await GetChunkContents(question.SourceChunkIds);

                        if (!string.IsNullOrWhiteSpace(chunkContents))
                        {
                            // Clasificar el contenido
                            var classifications = await _contentClassifier.ClassifyContentAsync(
                                chunkContents,
                                areaId);

                            if (classifications.Any())
                            {
                                // Tomar la clasificación con mayor confianza
                                var bestMatch = classifications
                                    .OrderByDescending(c => c.Confidence)
                                    .First();

                                temaId = bestMatch.TemaId;
                                subtemaId = bestMatch.SubtemaId;

                                _logger.LogInformation(
                                    "🎯 Pregunta clasificada: Tema={Tema}, Subtema={Subtema}, Confianza={Conf:P0}",
                                    bestMatch.TemaNombre,
                                    bestMatch.SubtemaNombre ?? "N/A",
                                    bestMatch.Confidence);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex,
                            "⚠️ No se pudo clasificar pregunta, usando valores por defecto");
                    }
                }

                // Si no se pudo clasificar y no hay tema por defecto, saltar
                // Si no se pudo clasificar y no hay tema/subtema válido, saltar
                if (temaId == 0 || !subtemaId.HasValue)
                {
                    _logger.LogWarning(
                        "⚠️ Pregunta sin tema/subtema válido, no se guardará: Tema={TemaId}, Subtema={SubtemaId}, Texto={Text}",
                        temaId,
                        subtemaId?.ToString() ?? "NULL",
                        question.QuestionText.Substring(0, Math.Min(50, question.QuestionText.Length)));
                    continue;
                }

                // ═══════════════════════════════════════════════════════════
                // 💾 GUARDAR LA PREGUNTA
                // ═══════════════════════════════════════════════════════════

                var tipoPregunta = question.Type switch
                {
                    QuestionType.MultipleChoice => TipoPregunta.seleccion_multiple,
                    QuestionType.TrueFalse => TipoPregunta.verdadero_falso,
                    QuestionType.OpenEnded => TipoPregunta.desarrollo,
                    _ => TipoPregunta.seleccion_multiple
                };

                var nivelDificultad = question.Difficulty switch
                {
                    DifficultyLevel.Basic => NivelDificultad.basico,
                    DifficultyLevel.Intermediate => NivelDificultad.intermedio,
                    DifficultyLevel.Advanced => NivelDificultad.avanzado,
                    _ => NivelDificultad.intermedio
                };

                int modalidadFinal = question.Type == QuestionType.OpenEnded ? 2 : 1;

                // 🔧 DETERMINAR RESPUESTA MODELO según el tipo de pregunta
                string? respuestaModelo = question.Type switch
                {
                    // Para OpenEnded: usar CorrectAnswer directamente
                    QuestionType.OpenEnded => question.CorrectAnswer,

                    // Para TrueFalse: usar "Verdadero" o "Falso"
                    QuestionType.TrueFalse => question.IsTrue.HasValue
                        ? (question.IsTrue.Value ? "Verdadero" : "Falso")
                        : null,

                    // Para MultipleChoice: obtener el TEXTO de la opción correcta
                    QuestionType.MultipleChoice => question.Options?
                        .FirstOrDefault(o => o.IsCorrect)?.Text,

                    // Fallback
                    _ => null
                };

                var connection = _context.Database.GetDbConnection();
                if (connection.State != ConnectionState.Open)
                    await connection.OpenAsync();

                using var command = connection.CreateCommand();

                command.CommandText = @"
                INSERT INTO preguntas_generadas (
                    tema_id, area_id, subtema_id, modalidad_id, tipo,
                    texto_pregunta, respuesta_correcta_opcion, respuesta_correcta_boolean,
                    respuesta_modelo, explicacion, nivel, activa, creada_por,
                    fecha_creacion, veces_utilizada, veces_correcta, contexto_fragmentos
                ) VALUES (
                    $1, $2, $3, $4, $5::tipo_pregunta, 
                    $6, $7, $8, $9, $10, $11::nivel_dificultad, 
                    $12, $13, $14, $15, $16, $17
                ) RETURNING id";

                command.Parameters.Add(new NpgsqlParameter { Value = temaId });
                command.Parameters.Add(new NpgsqlParameter { Value = areaId });
                command.Parameters.Add(new NpgsqlParameter { Value = (object?)subtemaId ?? DBNull.Value });
                command.Parameters.Add(new NpgsqlParameter { Value = modalidadFinal });
                command.Parameters.Add(new NpgsqlParameter
                {
                    Value = tipoPregunta.ToString(),
                    NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Unknown
                });
                command.Parameters.Add(new NpgsqlParameter { Value = question.QuestionText });
                command.Parameters.Add(new NpgsqlParameter { Value = (object?)GetCorrectOptionLetter(question) ?? DBNull.Value });
                command.Parameters.Add(new NpgsqlParameter { Value = (object?)question.IsTrue ?? DBNull.Value });
                command.Parameters.Add(new NpgsqlParameter { Value = (object?)respuestaModelo ?? DBNull.Value });
                command.Parameters.Add(new NpgsqlParameter { Value = question.Explanation ?? "Sin explicación" });
                command.Parameters.Add(new NpgsqlParameter
                {
                    Value = nivelDificultad.ToString(),
                    NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Unknown
                });
                command.Parameters.Add(new NpgsqlParameter { Value = question.IsActive });
                command.Parameters.Add(new NpgsqlParameter { Value = creadaPor });
                command.Parameters.Add(new NpgsqlParameter { Value = DateTime.UtcNow });
                command.Parameters.Add(new NpgsqlParameter { Value = 0 });
                command.Parameters.Add(new NpgsqlParameter { Value = 0 });
                command.Parameters.Add(new NpgsqlParameter
                {
                    Value = question.SourceChunkIds != null && question.SourceChunkIds.Any()
                        ? question.SourceChunkIds.ToArray()
                        : (object)DBNull.Value,
                    NpgsqlDbType = NpgsqlTypes.NpgsqlDbType.Array | NpgsqlTypes.NpgsqlDbType.Text
                });

                var result = await command.ExecuteScalarAsync();
                var preguntaId = Convert.ToInt32(result);

                // Guardar opciones
                if (question.Type == QuestionType.MultipleChoice && question.Options != null && question.Options.Any())
                {
                    await SaveMultipleChoiceOptions(preguntaId, question.Options);
                }
                else if (question.Type == QuestionType.TrueFalse)
                {
                    await SaveTrueFalseOptions(preguntaId, question.IsTrue ?? false);
                }

                savedIds.Add(preguntaId);

                _logger.LogInformation(
                    "✅ Pregunta guardada: ID={Id}, Área={AreaId}, Tema={TemaId}, Subtema={SubtemaId}",
                    preguntaId, areaId, temaId, subtemaId?.ToString() ?? "N/A");
            }

            _logger.LogInformation(
                "✅ Total guardado: {Saved}/{Total} preguntas",
                savedIds.Count, studyQuestions.Count);

            return savedIds;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error guardando preguntas en base de datos");
            throw;
        }
    }

    /// <summary>
    /// 🆕 Obtiene el contenido de los chunks desde Qdrant para clasificación
    /// </summary>
    private async Task<string> GetChunkContents(List<string> chunkIds)
    {
        try
        {
            if (chunkIds == null || !chunkIds.Any())
            {
                return string.Empty;
            }

            // Tomar solo los primeros 3 chunks para clasificación
            var idsToRetrieve = chunkIds.Take(3).ToList();

            _logger.LogDebug(
                "🔍 Recuperando {Count} chunks de Qdrant para clasificación",
                idsToRetrieve.Count);

            // Buscar en Qdrant usando el nuevo método
            var results = await _vectorService.GetPointsByIdsAsync(idsToRetrieve);

            if (!results.Any())
            {
                _logger.LogWarning(
                    "⚠️ No se encontraron chunks en Qdrant para los IDs: {Ids}",
                    string.Join(", ", idsToRetrieve));
                return string.Empty;
            }

            // Concatenar el contenido de los chunks encontrados
            var chunkContents = results
                .Where(r => !string.IsNullOrWhiteSpace(r.Content))
                .Select(r => r.Content)
                .ToList();

            var combinedContent = string.Join("\n\n", chunkContents);

            _logger.LogInformation(
                "✅ Recuperados {Found}/{Total} chunks de Qdrant ({Length} caracteres)",
                chunkContents.Count, idsToRetrieve.Count, combinedContent.Length);

            return combinedContent;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "⚠️ Error obteniendo contenido de chunks desde Qdrant");
            return string.Empty;
        }
    }

    private async Task SaveMultipleChoiceOptions(int preguntaId, List<QuestionOption> options)
    {
        var opciones = new List<PreguntaOpcione>();
        char[] letras = { 'A', 'B', 'C' };

        for (int i = 0; i < Math.Min(options.Count, 3); i++)
        {
            opciones.Add(new PreguntaOpcione
            {
                PreguntaGeneradaId = preguntaId,
                Opcion = letras[i],
                TextoOpcion = options[i].Text,
                EsCorrecta = options[i].IsCorrect
            });
        }

        _context.AddRange(opciones);
        await _context.SaveChangesAsync();
    }

    private async Task SaveTrueFalseOptions(int preguntaId, bool isTrue)
    {
        var opciones = new List<PreguntaOpcione>
        {
            new PreguntaOpcione
            {
                PreguntaGeneradaId = preguntaId,
                Opcion = 'A',
                TextoOpcion = "Verdadero",
                EsCorrecta = isTrue
            },
            new PreguntaOpcione
            {
                PreguntaGeneradaId = preguntaId,
                Opcion = 'B',
                TextoOpcion = "Falso",
                EsCorrecta = !isTrue
            }
        };

        _context.AddRange(opciones);
        await _context.SaveChangesAsync();
    }

    private char? GetCorrectOptionLetter(StudyQuestion question)
    {
        if (question.Options == null || !question.Options.Any())
            return null;

        var correctOption = question.Options.FirstOrDefault(o => o.IsCorrect);
        if (correctOption == null)
            return null;

        var index = question.Options.IndexOf(correctOption);
        return (char)('A' + index);
    }

    public async Task<int> GetOrCreateTemaId(string temaName, int areaId)
    {
        var tema = await _context.Temas
            .FirstOrDefaultAsync(t => t.Nombre == temaName && t.AreaId == areaId);

        if (tema == null)
        {
            tema = new Tema
            {
                Nombre = temaName,
                AreaId = areaId,
                Activo = true,
                FechaCreacion = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified)
            };

            _context.Temas.Add(tema);
            await _context.SaveChangesAsync();

            _logger.LogInformation("✅ Tema creado: {Nombre} (ID={Id}) en Área={AreaId}",
                tema.Nombre, tema.Id, areaId);
        }

        return tema.Id;
    }

    public async Task<int> GetAreaIdByName(string areaName)
    {
        var area = await _context.Areas
            .FirstOrDefaultAsync(a => a.Nombre.ToLower().Contains(areaName.ToLower()));

        if (area == null)
        {
            area = new Area
            {
                Nombre = areaName,
                Activo = true,
                FechaCreacion = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified)
            };

            _context.Areas.Add(area);
            await _context.SaveChangesAsync();

            _logger.LogInformation("✅ Área creada: {Nombre} (ID={Id})", area.Nombre, area.Id);
        }

        return area.Id;
    }
}