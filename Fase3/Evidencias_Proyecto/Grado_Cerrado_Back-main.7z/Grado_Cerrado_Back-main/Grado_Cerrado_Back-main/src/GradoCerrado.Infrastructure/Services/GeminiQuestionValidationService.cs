﻿// src/GradoCerrado.Infrastructure/Services/GeminiQuestionValidationService.cs
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using GradoCerrado.Application.DTOs;
using GradoCerrado.Application.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace GradoCerrado.Infrastructure.Services;

public class GeminiQuestionValidationService : IQuestionValidationService
{
    private readonly HttpClient _httpClient;
    private readonly ILogger<GeminiQuestionValidationService> _logger;
    private readonly string _apiKey;
    private readonly string _model;
    private readonly GeminiRateLimiter _rateLimiter; // 🆕 AGREGADO

    public GeminiQuestionValidationService(
        HttpClient httpClient,
        IConfiguration configuration,
        ILogger<GeminiQuestionValidationService> logger,
        GeminiRateLimiter rateLimiter) // 🆕 AGREGADO
    {
        _httpClient = httpClient;
        _logger = logger;
        _rateLimiter = rateLimiter; // 🆕 AGREGADO

        // Leer configuración
        _apiKey = configuration["Gemini:ApiKey"]
            ?? throw new InvalidOperationException("Gemini API Key no configurada en appsettings.json");
        _model = configuration["Gemini:Model"] ?? "gemini-1.5-pro";

        _logger.LogInformation("🔧 Gemini Validation Service inicializado con modelo: {Model}", _model);
    }

    public async Task<ValidationResult> ValidateQuestionAsync(
        string chunkContent,
        string questionText,
        string expectedAnswer)
    {
        try
        {
            _logger.LogDebug("🔍 Validando pregunta con Gemini: {Question}",
                questionText.Substring(0, Math.Min(50, questionText.Length)));

            // A) Truncar chunk para evitar MAX_TOKENS
            var maxChunk = 7000;
            var shortChunk = string.IsNullOrWhiteSpace(chunkContent)
                ? string.Empty
                : (chunkContent.Length > maxChunk ? chunkContent[..maxChunk] : chunkContent);

            // Prompt compacto
            var prompt = BuildValidationPrompt(shortChunk, questionText, expectedAnswer, compact: true);

            // B) Primer intento: JSON minificado + maxOutputTokens=1536
            var geminiResponse = await CallGeminiApiAsync(prompt, maxOutputTokensOverride: 1536, compactJson: true);

            // C) Si vacío o cortado, reintentar con aún más compacto + 3072 tokens
            if (string.IsNullOrWhiteSpace(geminiResponse))
            {
                _logger.LogWarning("⚠️ Respuesta vacía/cortada. Reintentando con prompt más compacto y más tokens...");
                var compactPrompt = BuildValidationPrompt(shortChunk, questionText, expectedAnswer, compact: true, ultraTerse: true);
                geminiResponse = await CallGeminiApiAsync(compactPrompt, maxOutputTokensOverride: 3072, compactJson: true);
            }

            var result = ParseValidationResponse(geminiResponse);

            _logger.LogDebug(
                "✅ Validación completada - Válida: {IsValid}, Relevancia: {Relevance:F2}",
                result.IsValid, result.Scores.QuestionRelevance);

            return result;
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "❌ Error de red al validar con Gemini");
            return CreateErrorValidationResult($"Error de conexión: {ex.Message}");
        }
        catch (JsonException ex)
        {
            _logger.LogError(ex, "❌ Error parseando respuesta de Gemini");
            return CreateErrorValidationResult($"Error parseando respuesta: {ex.Message}");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error inesperado al validar con Gemini");
            return CreateErrorValidationResult($"Error inesperado: {ex.Message}");
        }
    }

    // Prompt compacto con límites de longitud
    private string BuildValidationPrompt(
        string chunkContent,
        string questionText,
        string expectedAnswer,
        bool compact = false,
        bool ultraTerse = false)
    {
        var limits = ultraTerse
            ? @"issues≤1 (≤80 chars), recommendations≤1 (≤80 chars), feedback≤120 chars."
            : @"issues≤3 (≤80 chars c/u), recommendations≤3 (≤80 chars c/u), feedback≤200 chars.";

        // 🔍 DETECTAR TIPO DE PREGUNTA
        bool isTrueFalse = expectedAnswer?.Equals("Verdadero", StringComparison.OrdinalIgnoreCase) == true ||
                           expectedAnswer?.Equals("Falso", StringComparison.OrdinalIgnoreCase) == true ||
                           expectedAnswer?.Equals("True", StringComparison.OrdinalIgnoreCase) == true ||
                           expectedAnswer?.Equals("False", StringComparison.OrdinalIgnoreCase) == true;

        string validationInstructions = isTrueFalse
            ? @"
TIPO: Verdadero/Falso
VALIDACIÓN ESTRICTA:
- La afirmación de la pregunta debe ser verificable DIRECTAMENTE en el CONTENIDO
- Si es verdadera, debe estar explícitamente respaldada por el texto
- Si es falsa, el contenido debe contradecir o no respaldar la afirmación
- Rechaza si la pregunta no puede ser verificada con el contenido proporcionado"
            : @"
TIPO: Selección Múltiple
VALIDACIÓN DIFERENCIADA:
- SOLO la opción CORRECTA (respuesta esperada) debe estar verificable en el CONTENIDO
- Las opciones incorrectas (distractores) NO necesitan estar en el texto
- Los distractores están diseñados para confundir, pero deben ser plausibles
- Valida que la respuesta correcta esté CLARAMENTE respaldada por el contenido
- Rechaza si la respuesta correcta NO puede verificarse con el contenido proporcionado";

        return $@"
CONTENIDO:
{chunkContent}

PREGUNTA: {questionText}
RESPUESTA_ESPERADA: {expectedAnswer}

{validationInstructions}

Valida contra CONTENIDO. Devuelve SOLO JSON MINIFICADO con claves exactas:
{{""is_valid"":bool,""scores"":{{""question_relevance"":number,""question_quality"":number,""answer_correctness"":number,""answer_coherence"":number,""overall_coherence"":number}},""issues"":[string],""recommendations"":[string],""feedback"":""string"",""should_regenerate"":bool}}

Criterios: relevancia, calidad de la pregunta, corrección y coherencia de la respuesta, coherencia general.

Límites: {limits} Sin texto extra fuera del JSON.";
    }

    private async Task<string> CallGeminiApiAsync(string prompt, int? maxOutputTokensOverride = null, bool compactJson = false)
    {
        var url = $"https://generativelanguage.googleapis.com/v1/models/{_model}:generateContent?key={_apiKey}";

        var requestBody = new
        {
            contents = new[]
            {
                new
                {
                    parts = new[]
                    {
                        new
                        {
                            text = compactJson
                                ? $"Responde SOLO con JSON minificado (sin espacios ni saltos). No agregues comentarios ni texto fuera del JSON.\n\n{prompt}"
                                : prompt
                        }
                    }
                }
            },
            generationConfig = new
            {
                temperature = 0.2,
                maxOutputTokens = maxOutputTokensOverride ?? 1536,
                topP = 0.8,
                topK = 40
            }
        };

        var json = JsonSerializer.Serialize(requestBody);
        var content = new StringContent(json, Encoding.UTF8, "application/json");

        const int MAX_RETRIES = 3;
        int attempt = 0;

        while (true)
        {
            HttpResponseMessage? response = null;
            string responseContent = string.Empty;

            try
            {
                // 🆕 ESPERAR SI ES NECESARIO POR RATE LIMITING
                await _rateLimiter.WaitIfNeededAsync();

                _logger.LogDebug("🌐 Llamando a Gemini API (intento {Attempt}/{Max})...", attempt + 1, MAX_RETRIES + 1);
                response = await _httpClient.PostAsync(url, content);

                responseContent = await response.Content.ReadAsStringAsync();

                if (!response.IsSuccessStatusCode)
                {
                    // Reintentos en 429/5xx con delays MÁS LARGOS
                    if ((int)response.StatusCode == 429 || (int)response.StatusCode >= 500)
                    {
                        attempt++;
                        if (attempt > MAX_RETRIES)
                        {
                            _logger.LogError("❌ Gemini API tras reintentos: {Code} - {Body}", response.StatusCode, responseContent);
                            throw new HttpRequestException($"Gemini API error: {response.StatusCode} - {responseContent}");
                        }

                        // 🆕 DELAYS MÁS LARGOS: 1s, 2s, 4s en lugar de 400ms, 800ms, 1600ms
                        var delayMs = (int)(Math.Pow(2, attempt) * 1000 + Random.Shared.Next(0, 500));
                        _logger.LogWarning("⏳ Gemini {Code}. Reintentando en {Delay} ms...", response.StatusCode, delayMs);
                        await Task.Delay(delayMs);
                        continue;
                    }

                    _logger.LogError("❌ Error en Gemini API: {StatusCode} - {Error}", response.StatusCode, responseContent);
                    throw new HttpRequestException($"Gemini API error: {response.StatusCode} - {responseContent}");
                }

                // Parseo DEFENSIVO del payload
                using var doc = JsonDocument.Parse(responseContent, new JsonDocumentOptions { AllowTrailingCommas = true });
                var root = doc.RootElement;

                // Si viene un bloque de error embebido
                if (root.TryGetProperty("error", out var err))
                {
                    var code = err.TryGetProperty("code", out var ec) ? ec.ToString() : "?";
                    var msg = err.TryGetProperty("message", out var em) ? em.ToString() : "Unknown error";
                    var status = err.TryGetProperty("status", out var es) ? es.ToString() : "";
                    _logger.LogError("❌ Gemini devolvió error: code={Code}, status={Status}, message={Message}", code, status, msg);
                    return string.Empty;
                }

                // Extrae el texto + detecta finishReason
                string? finishReason = null;
                var text = ExtractGeminiTextSafely(root, _logger, out finishReason);

                if (string.Equals(finishReason, "MAX_TOKENS", StringComparison.OrdinalIgnoreCase) &&
                    string.IsNullOrWhiteSpace(text))
                {
                    _logger.LogWarning("Gemini finishReason=MAX_TOKENS sin texto utilizable.");
                    return string.Empty;
                }

                return text ?? string.Empty;
            }
            catch (TaskCanceledException ex) // timeouts
            {
                attempt++;
                if (attempt > MAX_RETRIES)
                {
                    _logger.LogError(ex, "❌ Timeout llamando a Gemini tras reintentos.");
                    throw;
                }
                var delayMs = (int)(Math.Pow(2, attempt) * 500 + Random.Shared.Next(0, 300));
                _logger.LogWarning("⏳ Timeout Gemini. Reintentando en {Delay} ms...", delayMs);
                await Task.Delay(delayMs);
            }
        }
    }

    public ValidationResult ParseValidationResponse(string jsonResponse)
    {
        // Limpia fences y extrae sólo el JSON si vino con texto alrededor
        jsonResponse = CleanModelJsonFences(jsonResponse);

        if (string.IsNullOrWhiteSpace(jsonResponse))
        {
            _logger.LogWarning("Validación Gemini vacía.");
            return CreateErrorValidationResult("Respuesta vacía de Gemini");
        }

        // Intenta recortar al primer '{' y último '}' por si vinieron restos
        if (!jsonResponse.TrimStart().StartsWith("{"))
        {
            jsonResponse = TryExtractJsonSubstring(jsonResponse);
            if (string.IsNullOrWhiteSpace(jsonResponse))
            {
                _logger.LogWarning("No se pudo extraer JSON de la respuesta de Gemini.");
                return CreateErrorValidationResult("No se pudo extraer JSON de Gemini");
            }
        }

        _logger.LogDebug("📝 JSON de Gemini (primeros 200 chars): {Json}",
            jsonResponse.Substring(0, Math.Min(200, jsonResponse.Length)));

        try
        {
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true,
#if NET8_0_OR_GREATER
                PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseLower,
#endif
                AllowTrailingCommas = true,
                Converters = { new JsonStringEnumConverter() }
            };

            var geminiResponse = JsonSerializer.Deserialize<GeminiValidationResponse>(jsonResponse, options);

            if (geminiResponse == null)
                return CreateErrorValidationResult("No se pudo deserializar la respuesta de Gemini");

            return new ValidationResult
            {
                IsValid = geminiResponse.IsValid,
                Scores = new ValidationScores
                {
                    QuestionRelevance = geminiResponse.Scores?.QuestionRelevance ?? 0,
                    QuestionQuality = geminiResponse.Scores?.QuestionQuality ?? 0,
                    AnswerCorrectness = geminiResponse.Scores?.AnswerCorrectness ?? 0,
                    AnswerCoherence = geminiResponse.Scores?.AnswerCoherence ?? 0,
                    OverallCoherence = geminiResponse.Scores?.OverallCoherence ?? 0
                },
                Issues = geminiResponse.Issues ?? new List<string>(),
                Recommendations = geminiResponse.Recommendations ?? new List<string>(),
                Feedback = geminiResponse.Feedback ?? string.Empty,
                ShouldRegenerate = geminiResponse.ShouldRegenerate,
                ValidatedAt = DateTime.UtcNow
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error parseando JSON de Gemini");
            return CreateErrorValidationResult($"Error parseando respuesta: {ex.Message}");
        }
    }

    private ValidationResult CreateErrorValidationResult(string errorMessage)
    {
        return new ValidationResult
        {
            IsValid = false,
            Scores = new ValidationScores(),
            Issues = new List<string> { errorMessage },
            Recommendations = new List<string> { "Revisar manualmente esta pregunta" },
            Feedback = "Error al comunicarse con el servicio de validación",
            ShouldRegenerate = true,
            ValidatedAt = DateTime.UtcNow
        };
    }

    // ════════════════════════════════════════════════════════════════
    // CLASES INTERNAS PARA DESERIALIZACIÓN
    // ════════════════════════════════════════════════════════════════

    private class GeminiValidationResponse
    {
        [JsonPropertyName("is_valid")]
        public bool IsValid { get; set; }

        [JsonPropertyName("scores")]
        public GeminiScores? Scores { get; set; }

        [JsonPropertyName("issues")]
        public List<string>? Issues { get; set; }

        [JsonPropertyName("recommendations")]
        public List<string>? Recommendations { get; set; }

        [JsonPropertyName("feedback")]
        public string? Feedback { get; set; }

        [JsonPropertyName("should_regenerate")]
        public bool ShouldRegenerate { get; set; }
    }

    private class GeminiScores
    {
        [JsonPropertyName("question_relevance")]
        public decimal QuestionRelevance { get; set; }

        [JsonPropertyName("question_quality")]
        public decimal QuestionQuality { get; set; }

        [JsonPropertyName("answer_correctness")]
        public decimal AnswerCorrectness { get; set; }

        [JsonPropertyName("answer_coherence")]
        public decimal AnswerCoherence { get; set; }

        [JsonPropertyName("overall_coherence")]
        public decimal OverallCoherence { get; set; }
    }

    // Helpers
    private static string ExtractGeminiTextSafely(JsonElement root, ILogger logger, out string? finishReason)
    {
        finishReason = null;

        // 1) candidates[0].content.parts[0].text
        if (root.TryGetProperty("candidates", out var cands) &&
            cands.ValueKind == JsonValueKind.Array &&
            cands.GetArrayLength() > 0)
        {
            var first = cands[0];

            if (first.TryGetProperty("finishReason", out var fr))
                finishReason = fr.GetString();

            if (first.TryGetProperty("content", out var content) &&
                content.TryGetProperty("parts", out var parts) &&
                parts.ValueKind == JsonValueKind.Array &&
                parts.GetArrayLength() > 0)
            {
                var p0 = parts[0];
                if (p0.ValueKind == JsonValueKind.Object &&
                    p0.TryGetProperty("text", out var t))
                {
                    return t.GetString() ?? string.Empty;
                }
            }

            // 2) output_text (algunos SDKs)
            if (first.TryGetProperty("output_text", out var ot))
                return ot.GetString() ?? string.Empty;

            // 3) finishReason sin texto utilizable
            if (!string.IsNullOrEmpty(finishReason))
                logger.LogWarning("Gemini finishReason={FinishReason} sin texto utilizable.", finishReason);
        }

        // 4) Fallback directo
        if (root.TryGetProperty("text", out var directText))
            return directText.GetString() ?? string.Empty;

        return string.Empty;
    }

    private static string CleanModelJsonFences(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return string.Empty;
        s = s.Trim();
        // quita ```json ... ```
        s = s.Replace("```json", "", StringComparison.OrdinalIgnoreCase)
             .Replace("```", "", StringComparison.OrdinalIgnoreCase)
             .Trim();
        return s;
    }

    private static string TryExtractJsonSubstring(string s)
    {
        if (string.IsNullOrWhiteSpace(s)) return string.Empty;
        int start = s.IndexOf('{');
        int end = s.LastIndexOf('}');
        if (start >= 0 && end > start)
            return s.Substring(start, end - start + 1);
        return string.Empty;
    }
}