export const environment = {
  production: true,
  apiUrl: 'https://gradocerrado-api-linux-agejfxg9d2ahgvgh.brazilsouth-01.azurewebsites.net/api'
};